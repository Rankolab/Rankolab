import React, { useState } from 'react';
import { View, StyleSheet, Image, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { TextInput, Button, Text, Surface, HelperText } from 'react-native-paper';
import { spacing, shadows } from '../../utils/theme';
import AuthService from '../../services/AuthService';

const ForgotPasswordScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const validateEmail = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      setEmailError('Email is required');
      return false;
    } else if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    } else {
      setEmailError('');
      return true;
    }
  };

  const handleResetPassword = async () => {
    if (validateEmail()) {
      setIsLoading(true);
      setMessage('');
      
      try {
        // In a real implementation, this would call an API endpoint
        // For now, we'll simulate a successful response
        setTimeout(() => {
          setIsLoading(false);
          setIsSuccess(true);
          setMessage('Password reset instructions have been sent to your email.');
        }, 1500);
        
        // Actual implementation would be:
        // const response = await AuthService.resetPassword(email);
        // setIsLoading(false);
        // if (response.success) {
        //   setIsSuccess(true);
        //   setMessage(response.message);
        // } else {
        //   setIsSuccess(false);
        //   setMessage(response.message);
        // }
      } catch (error) {
        setIsLoading(false);
        setIsSuccess(false);
        setMessage('An error occurred. Please try again later.');
        console.error('Reset password error:', error);
      }
    }
  };

  const navigateToLogin = () => {
    navigation.navigate('Login');
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.logoContainer}>
          <Image
            source={require('../../assets/logo.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>

        <Surface style={styles.formContainer}>
          <Text style={styles.title}>Forgot Password</Text>
          <Text style={styles.subtitle}>Enter your email to reset your password</Text>

          {message ? (
            <HelperText type={isSuccess ? 'info' : 'error'} visible={true} style={isSuccess ? styles.successMessage : styles.errorMessage}>
              {message}
            </HelperText>
          ) : null}

          <TextInput
            label="Email"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
            keyboardType="email-address"
            autoCapitalize="none"
            error={!!emailError}
            disabled={isLoading || isSuccess}
          />
          {emailError ? (
            <HelperText type="error" visible={!!emailError}>
              {emailError}
            </HelperText>
          ) : null}

          <Button
            mode="contained"
            onPress={handleResetPassword}
            style={styles.resetButton}
            loading={isLoading}
            disabled={isLoading || isSuccess}
          >
            Reset Password
          </Button>

          <Button
            mode="text"
            onPress={navigateToLogin}
            style={styles.backButton}
          >
            Back to Login
          </Button>
        </Surface>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: spacing.lg,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  logo: {
    width: 150,
    height: 150,
  },
  formContainer: {
    padding: spacing.lg,
    borderRadius: 8,
    ...shadows.medium,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: spacing.xs,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  input: {
    marginBottom: spacing.md,
  },
  resetButton: {
    marginBottom: spacing.md,
  },
  backButton: {
    marginBottom: spacing.sm,
  },
  successMessage: {
    color: '#4CAF50',
    marginBottom: spacing.md,
  },
  errorMessage: {
    color: '#D32F2F',
    marginBottom: spacing.md,
  },
});

export default ForgotPasswordScreen;
