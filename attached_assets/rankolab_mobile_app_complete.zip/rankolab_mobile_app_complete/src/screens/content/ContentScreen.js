import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { Surface, Text, Card, Title, Paragraph, Button, Chip, Searchbar, Divider, ActivityIndicator, useTheme } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { spacing, shadows } from '../../utils/theme';

// Placeholder for content actions
// import { fetchPosts, fetchContentStats } from '../../store/actions/contentActions';

const ContentScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [posts, setPosts] = useState([
    {
      id: 1,
      title: 'How to Improve Your Website SEO in 2025',
      excerpt: 'Learn the latest SEO techniques to boost your website ranking in search engines.',
      date: '2025-04-10T10:30:00Z',
      author: 'John Smith',
      categories: ['SEO', 'Marketing'],
      status: 'published',
      featured: true
    },
    {
      id: 2,
      title: 'The Ultimate Guide to Content Marketing',
      excerpt: 'Discover how content marketing can drive traffic and increase conversions for your business.',
      date: '2025-04-08T14:15:00Z',
      author: 'Jane Doe',
      categories: ['Content', 'Marketing'],
      status: 'published',
      featured: false
    },
    {
      id: 3,
      title: 'WordPress Security Best Practices',
      excerpt: 'Protect your WordPress website from hackers with these essential security measures.',
      date: '2025-04-05T09:45:00Z',
      author: 'Mike Johnson',
      categories: ['WordPress', 'Security'],
      status: 'published',
      featured: false
    },
    {
      id: 4,
      title: 'Upcoming Features in WordPress 6.5',
      excerpt: 'A sneak peek at the exciting new features coming in WordPress 6.5.',
      date: '2025-04-02T16:20:00Z',
      author: 'Sarah Williams',
      categories: ['WordPress', 'News'],
      status: 'draft',
      featured: false
    },
    {
      id: 5,
      title: 'How to Speed Up Your WordPress Website',
      excerpt: 'Optimize your WordPress website for maximum performance with these tips.',
      date: '2025-03-28T11:10:00Z',
      author: 'John Smith',
      categories: ['WordPress', 'Performance'],
      status: 'published',
      featured: true
    }
  ]);
  
  const [contentStats, setContentStats] = useState({
    totalPosts: 87,
    publishedPosts: 75,
    draftPosts: 12,
    categories: 8,
    tags: 45,
    authors: 3
  });

  useEffect(() => {
    // In a real implementation, this would fetch data from the API
    // dispatch(fetchPosts());
    // dispatch(fetchContentStats());
    
    // For now, we'll use the static data defined above
  }, [dispatch]);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    
    // Simulate API call
    setTimeout(() => {
      // In a real implementation, this would fetch fresh data
      // dispatch(fetchPosts());
      // dispatch(fetchContentStats());
      setRefreshing(false);
    }, 2000);
  }, [dispatch]);

  const onChangeSearch = query => {
    setSearchQuery(query);
  };

  const filterPosts = () => {
    let filteredPosts = [...posts];
    
    // Apply search filter
    if (searchQuery) {
      filteredPosts = filteredPosts.filter(post => 
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.categories.some(category => category.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    // Apply status filter
    if (activeFilter !== 'all') {
      filteredPosts = filteredPosts.filter(post => post.status === activeFilter);
    }
    
    return filteredPosts;
  };

  const renderPostItem = ({ item }) => (
    <Card style={styles.postCard}>
      {item.featured && (
        <View style={styles.featuredBadge}>
          <Text style={styles.featuredText}>Featured</Text>
        </View>
      )}
      <Card.Content>
        <Title>{item.title}</Title>
        <Paragraph>{item.excerpt}</Paragraph>
        <View style={styles.postMeta}>
          <Text style={styles.metaText}>By {item.author} • {new Date(item.date).toLocaleDateString()}</Text>
          {item.status === 'draft' && (
            <Chip style={styles.draftChip}>Draft</Chip>
          )}
        </View>
        <View style={styles.categoriesContainer}>
          {item.categories.map((category, index) => (
            <Chip key={index} style={styles.categoryChip} textStyle={styles.categoryChipText}>
              {category}
            </Chip>
          ))}
        </View>
      </Card.Content>
      <Card.Actions style={styles.cardActions}>
        <Button mode="text" onPress={() => {}}>Edit</Button>
        <Button mode="text" onPress={() => {}}>View</Button>
        <Button mode="text" onPress={() => {}}>Stats</Button>
      </Card.Actions>
    </Card>
  );

  return (
    <View style={styles.container}>
      {/* Content Stats */}
      <Surface style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{contentStats.totalPosts}</Text>
          <Text style={styles.statLabel}>Total Posts</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{contentStats.publishedPosts}</Text>
          <Text style={styles.statLabel}>Published</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{contentStats.draftPosts}</Text>
          <Text style={styles.statLabel}>Drafts</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{contentStats.categories}</Text>
          <Text style={styles.statLabel}>Categories</Text>
        </View>
      </Surface>

      {/* Search and Filters */}
      <View style={styles.searchContainer}>
        <Searchbar
          placeholder="Search posts"
          onChangeText={onChangeSearch}
          value={searchQuery}
          style={styles.searchbar}
        />
      </View>
      
      <View style={styles.filtersContainer}>
        <TouchableOpacity
          style={[
            styles.filterButton,
            activeFilter === 'all' && { backgroundColor: theme.colors.primary }
          ]}
          onPress={() => setActiveFilter('all')}
        >
          <Text style={[
            styles.filterText,
            activeFilter === 'all' && { color: 'white' }
          ]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.filterButton,
            activeFilter === 'published' && { backgroundColor: theme.colors.primary }
          ]}
          onPress={() => setActiveFilter('published')}
        >
          <Text style={[
            styles.filterText,
            activeFilter === 'published' && { color: 'white' }
          ]}>Published</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.filterButton,
            activeFilter === 'draft' && { backgroundColor: theme.colors.primary }
          ]}
          onPress={() => setActiveFilter('draft')}
        >
          <Text style={[
            styles.filterText,
            activeFilter === 'draft' && { color: 'white' }
          ]}>Drafts</Text>
        </TouchableOpacity>
      </View>

      {/* Posts List */}
      <FlatList
        data={filterPosts()}
        renderItem={renderPostItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2E7D32']} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No posts found</Text>
          </View>
        }
      />

      {/* Floating Action Button */}
      <TouchableOpacity style={styles.fab} onPress={() => {}}>
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: spacing.xs,
  },
  searchContainer: {
    padding: spacing.md,
  },
  searchbar: {
    elevation: 2,
  },
  filtersContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  filterButton: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    marginRight: spacing.sm,
    borderRadius: 20,
    backgroundColor: '#E0E0E0',
  },
  filterText: {
    fontSize: 14,
    color: '#333',
  },
  listContainer: {
    padding: spacing.md,
    paddingTop: 0,
  },
  postCard: {
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
    position: 'relative',
    overflow: 'hidden',
  },
  featuredBadge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF6F00',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs / 2,
    borderBottomLeftRadius: 8,
    zIndex: 1,
  },
  featuredText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  postMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.sm,
  },
  metaText: {
    fontSize: 12,
    color: '#666',
  },
  draftChip: {
    backgroundColor: '#FFC107',
    height: 24,
  },
  categoriesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: spacing.xs,
  },
  categoryChip: {
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
    backgroundColor: '#E8F5E9',
    height: 24,
  },
  categoryChipText: {
    fontSize: 12,
    color: '#2E7D32',
  },
  cardActions: {
    justifyContent: 'flex-end',
  },
  emptyContainer: {
    padding: spacing.xl,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
  },
  fab: {
    position: 'absolute',
    width: 56,
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    right: 20,
    bottom: 20,
    backgroundColor: '#2E7D32',
    borderRadius: 28,
    elevation: 8,
  },
  fabText: {
    fontSize: 24,
    color: 'white',
  },
});

export default ContentScreen;
