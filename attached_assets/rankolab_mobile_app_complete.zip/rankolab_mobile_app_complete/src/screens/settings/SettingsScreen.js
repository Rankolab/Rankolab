import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Switch, Alert } from 'react-native';
import { Surface, Text, Card, Title, Paragraph, Button, List, Divider, useTheme } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { spacing, shadows } from '../../utils/theme';
import OfflineManager from '../../utils/OfflineManager';

const SettingsScreen = () => {
  const theme = useTheme();
  const [settings, setSettings] = useState({
    notifications: {
      enabled: true,
      trafficAlerts: true,
      seoAlerts: true,
      contentAlerts: true,
      performanceAlerts: true,
      systemAlerts: true
    },
    offlineMode: {
      enabled: true,
      syncOnWifiOnly: false,
      autoSyncInterval: 60, // minutes
      maxStorageSize: 100 // MB
    },
    appearance: {
      darkMode: false,
      compactView: false
    },
    dataUsage: {
      reducedDataMode: false,
      preloadImages: true
    }
  });
  
  const [offlineStats, setOfflineStats] = useState({
    lastSyncTime: null,
    cachedDataSize: 0,
    pendingActions: 0
  });

  useEffect(() => {
    // Load saved settings
    loadSettings();
    // Load offline stats
    loadOfflineStats();
  }, []);

  const loadSettings = async () => {
    try {
      const savedSettings = await AsyncStorage.getItem('user_settings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const loadOfflineStats = async () => {
    try {
      // Get last sync time
      const lastSyncTime = await OfflineManager.getLastSyncTimestamp('all');
      
      // Get pending actions
      const pendingActions = await OfflineManager.getQueuedActions();
      
      // Calculate cached data size (this is a simplified approach)
      const cachedDataSize = await calculateCachedDataSize();
      
      setOfflineStats({
        lastSyncTime,
        cachedDataSize,
        pendingActions: pendingActions.length
      });
    } catch (error) {
      console.error('Error loading offline stats:', error);
    }
  };

  const calculateCachedDataSize = async () => {
    // This is a simplified approach to estimate cache size
    // In a real app, you would track the size of cached data more accurately
    try {
      const keys = await AsyncStorage.getAllKeys();
      let totalSize = 0;
      
      for (const key of keys) {
        if (key.startsWith('cache_')) {
          const value = await AsyncStorage.getItem(key);
          if (value) {
            totalSize += value.length;
          }
        }
      }
      
      // Convert bytes to MB
      return Math.round((totalSize / (1024 * 1024)) * 100) / 100;
    } catch (error) {
      console.error('Error calculating cached data size:', error);
      return 0;
    }
  };

  const saveSettings = async (newSettings) => {
    try {
      await AsyncStorage.setItem('user_settings', JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', 'Failed to save settings. Please try again.');
    }
  };

  const handleToggleSetting = (section, setting) => {
    const newSettings = { ...settings };
    newSettings[section][setting] = !newSettings[section][setting];
    saveSettings(newSettings);
  };

  const handleSyncNow = async () => {
    try {
      Alert.alert('Sync', 'Syncing data with server...');
      
      // Check if online
      const isOnline = await OfflineManager.isOnline();
      if (!isOnline) {
        Alert.alert('Error', 'Cannot sync while offline. Please check your internet connection.');
        return;
      }
      
      // Sync queued actions
      const syncResult = await OfflineManager.syncQueuedActions(async (action) => {
        // This is a placeholder for the actual implementation
        // In a real app, you would process each action based on its type
        console.log('Processing action:', action);
        return { success: true };
      });
      
      // Update last sync timestamp
      await OfflineManager.updateLastSyncTimestamp('all');
      
      // Reload offline stats
      await loadOfflineStats();
      
      Alert.alert('Sync Complete', syncResult.message);
    } catch (error) {
      console.error('Error syncing data:', error);
      Alert.alert('Error', 'Failed to sync data. Please try again.');
    }
  };

  const handleClearCache = async () => {
    Alert.alert(
      'Clear Cache',
      'Are you sure you want to clear all cached data? This will remove all offline content.',
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            try {
              // Get all keys
              const keys = await AsyncStorage.getAllKeys();
              
              // Filter cache keys
              const cacheKeys = keys.filter(key => key.startsWith('cache_'));
              
              // Remove all cache items
              if (cacheKeys.length > 0) {
                await AsyncStorage.multiRemove(cacheKeys);
              }
              
              // Reload offline stats
              await loadOfflineStats();
              
              Alert.alert('Success', 'Cache cleared successfully.');
            } catch (error) {
              console.error('Error clearing cache:', error);
              Alert.alert('Error', 'Failed to clear cache. Please try again.');
            }
          }
        }
      ]
    );
  };

  const formatLastSyncTime = (timestamp) => {
    if (!timestamp) return 'Never';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    
    if (diffMinutes < 1) {
      return 'Just now';
    } else if (diffMinutes < 60) {
      return `${diffMinutes} minute${diffMinutes === 1 ? '' : 's'} ago`;
    } else if (diffMinutes < 1440) {
      const hours = Math.floor(diffMinutes / 60);
      return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    } else {
      return date.toLocaleString();
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {/* Notifications Settings */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Notifications</Title>
          <List.Item
            title="Enable Notifications"
            right={() => (
              <Switch
                value={settings.notifications.enabled}
                onValueChange={() => handleToggleSetting('notifications', 'enabled')}
                color={theme.colors.primary}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Traffic Alerts"
            description="Receive alerts about traffic changes"
            right={() => (
              <Switch
                value={settings.notifications.trafficAlerts}
                onValueChange={() => handleToggleSetting('notifications', 'trafficAlerts')}
                color={theme.colors.primary}
                disabled={!settings.notifications.enabled}
              />
            )}
          />
          <Divider />
          <List.Item
            title="SEO Alerts"
            description="Receive alerts about SEO changes"
            right={() => (
              <Switch
                value={settings.notifications.seoAlerts}
                onValueChange={() => handleToggleSetting('notifications', 'seoAlerts')}
                color={theme.colors.primary}
                disabled={!settings.notifications.enabled}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Content Alerts"
            description="Receive alerts about content updates"
            right={() => (
              <Switch
                value={settings.notifications.contentAlerts}
                onValueChange={() => handleToggleSetting('notifications', 'contentAlerts')}
                color={theme.colors.primary}
                disabled={!settings.notifications.enabled}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Performance Alerts"
            description="Receive alerts about performance issues"
            right={() => (
              <Switch
                value={settings.notifications.performanceAlerts}
                onValueChange={() => handleToggleSetting('notifications', 'performanceAlerts')}
                color={theme.colors.primary}
                disabled={!settings.notifications.enabled}
              />
            )}
          />
          <Divider />
          <List.Item
            title="System Alerts"
            description="Receive alerts about system updates"
            right={() => (
              <Switch
                value={settings.notifications.systemAlerts}
                onValueChange={() => handleToggleSetting('notifications', 'systemAlerts')}
                color={theme.colors.primary}
                disabled={!settings.notifications.enabled}
              />
            )}
          />
        </Card.Content>
      </Card>

      {/* Offline Mode Settings */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Offline Mode</Title>
          <List.Item
            title="Enable Offline Mode"
            description="Cache data for offline use"
            right={() => (
              <Switch
                value={settings.offlineMode.enabled}
                onValueChange={() => handleToggleSetting('offlineMode', 'enabled')}
                color={theme.colors.primary}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Sync on Wi-Fi Only"
            description="Only sync data when connected to Wi-Fi"
            right={() => (
              <Switch
                value={settings.offlineMode.syncOnWifiOnly}
                onValueChange={() => handleToggleSetting('offlineMode', 'syncOnWifiOnly')}
                color={theme.colors.primary}
                disabled={!settings.offlineMode.enabled}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Last Synced"
            description={formatLastSyncTime(offlineStats.lastSyncTime)}
          />
          <Divider />
          <List.Item
            title="Cached Data"
            description={`${offlineStats.cachedDataSize} MB used`}
          />
          <Divider />
          <List.Item
            title="Pending Actions"
            description={`${offlineStats.pendingActions} action${offlineStats.pendingActions === 1 ? '' : 's'} queued`}
          />
          <View style={styles.buttonContainer}>
            <Button
              mode="contained"
              onPress={handleSyncNow}
              style={styles.button}
              disabled={!settings.offlineMode.enabled}
            >
              Sync Now
            </Button>
            <Button
              mode="outlined"
              onPress={handleClearCache}
              style={styles.button}
              disabled={!settings.offlineMode.enabled || offlineStats.cachedDataSize === 0}
            >
              Clear Cache
            </Button>
          </View>
        </Card.Content>
      </Card>

      {/* Appearance Settings */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Appearance</Title>
          <List.Item
            title="Dark Mode"
            description="Use dark theme throughout the app"
            right={() => (
              <Switch
                value={settings.appearance.darkMode}
                onValueChange={() => handleToggleSetting('appearance', 'darkMode')}
                color={theme.colors.primary}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Compact View"
            description="Show more content with less spacing"
            right={() => (
              <Switch
                value={settings.appearance.compactView}
                onValueChange={() => handleToggleSetting('appearance', 'compactView')}
                color={theme.colors.primary}
              />
            )}
          />
        </Card.Content>
      </Card>

      {/* Data Usage Settings */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Data Usage</Title>
          <List.Item
            title="Reduced Data Mode"
            description="Minimize data usage when on cellular networks"
            right={() => (
              <Switch
                value={settings.dataUsage.reducedDataMode}
                onValueChange={() => handleToggleSetting('dataUsage', 'reducedDataMode')}
                color={theme.colors.primary}
              />
            )}
          />
          <Divider />
          <List.Item
            title="Preload Images"
            description="Download images in advance for faster viewing"
            right={() => (
              <Switch
                value={settings.dataUsage.preloadImages}
                onValueChange={() => handleToggleSetting('dataUsage', 'preloadImages')}
                color={theme.colors.primary}
                disabled={settings.dataUsage.reducedDataMode}
              />
            )}
          />
        </Card.Content>
      </Card>

      {/* About */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>About</Title>
          <Paragraph>Rankolab Mobile App</Paragraph>
          <Paragraph>Version 1.0.0</Paragraph>
          <Paragraph>© 2025 Rankolab</Paragraph>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: spacing.md,
  },
  card: {
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: spacing.md,
  },
  button: {
    flex: 1,
    marginHorizontal: spacing.xs,
  },
});

export default SettingsScreen;
