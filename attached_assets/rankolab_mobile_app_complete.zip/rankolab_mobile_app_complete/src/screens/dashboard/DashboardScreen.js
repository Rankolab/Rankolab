import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, RefreshControl, Dimensions } from 'react-native';
import { Surface, Text, Card, Title, Paragraph, Button, ActivityIndicator, useTheme } from 'react-native-paper';
import { LineChart, BarChart, PieChart } from 'react-native-chart-kit';
import { useSelector, useDispatch } from 'react-redux';
import { spacing, shadows } from '../../utils/theme';

// Placeholder for dashboard actions
// import { fetchDashboardData } from '../../store/actions/dashboardActions';

const DashboardScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = useState(false);
  const [dashboardData, setDashboardData] = useState({
    traffic: {
      visitors: 1245,
      pageViews: 3567,
      bounceRate: 42.5,
      averageSessionDuration: 125
    },
    seo: {
      score: 78,
      keywordsRanked: 32,
      backlinks: 156
    },
    content: {
      totalPosts: 87,
      publishedPosts: 75,
      draftPosts: 12,
      categories: 8
    },
    performance: {
      loadTime: 2.3,
      serverResponse: 0.8,
      pageSize: 1.2
    }
  });

  // Sample data for charts
  const trafficData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        data: [20, 45, 28, 80, 99, 43, 50],
        color: (opacity = 1) => `rgba(46, 125, 50, ${opacity})`,
        strokeWidth: 2
      }
    ],
    legend: ['Visitors']
  };

  const keywordData = {
    labels: ['1-3', '4-10', '11-20', '21-50', '51+'],
    datasets: [
      {
        data: [12, 8, 6, 4, 2],
      }
    ]
  };

  const contentDistribution = [
    {
      name: 'Published',
      population: dashboardData.content.publishedPosts,
      color: '#4CAF50',
      legendFontColor: '#7F7F7F',
      legendFontSize: 12
    },
    {
      name: 'Drafts',
      population: dashboardData.content.draftPosts,
      color: '#FFC107',
      legendFontColor: '#7F7F7F',
      legendFontSize: 12
    }
  ];

  const screenWidth = Dimensions.get('window').width - 32;

  const chartConfig = {
    backgroundGradientFrom: '#ffffff',
    backgroundGradientTo: '#ffffff',
    color: (opacity = 1) => `rgba(46, 125, 50, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.5,
    useShadowColorFromDataset: false
  };

  useEffect(() => {
    // In a real implementation, this would fetch data from the API
    // dispatch(fetchDashboardData());
    
    // For now, we'll use the static data defined above
  }, [dispatch]);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    
    // Simulate API call
    setTimeout(() => {
      // In a real implementation, this would fetch fresh data
      // dispatch(fetchDashboardData());
      setRefreshing(false);
    }, 2000);
  }, [dispatch]);

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2E7D32']} />
      }
    >
      {/* Overview Cards */}
      <View style={styles.overviewContainer}>
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.primary }]}>
          <Text style={styles.overviewValue}>{dashboardData.traffic.visitors}</Text>
          <Text style={styles.overviewLabel}>Visitors</Text>
        </Surface>
        
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.accent }]}>
          <Text style={styles.overviewValue}>{dashboardData.traffic.pageViews}</Text>
          <Text style={styles.overviewLabel}>Page Views</Text>
        </Surface>
        
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.notification }]}>
          <Text style={styles.overviewValue}>{dashboardData.seo.score}</Text>
          <Text style={styles.overviewLabel}>SEO Score</Text>
        </Surface>
        
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.success }]}>
          <Text style={styles.overviewValue}>{dashboardData.content.totalPosts}</Text>
          <Text style={styles.overviewLabel}>Posts</Text>
        </Surface>
      </View>

      {/* Traffic Chart */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Traffic Overview</Title>
          <Paragraph>Last 7 days visitor statistics</Paragraph>
          <View style={styles.chartContainer}>
            <LineChart
              data={trafficData}
              width={screenWidth}
              height={220}
              chartConfig={chartConfig}
              bezier
              style={styles.chart}
            />
          </View>
        </Card.Content>
      </Card>

      {/* SEO Stats */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>SEO Performance</Title>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{dashboardData.seo.score}</Text>
              <Text style={styles.statLabel}>SEO Score</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{dashboardData.seo.keywordsRanked}</Text>
              <Text style={styles.statLabel}>Keywords Ranked</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{dashboardData.seo.backlinks}</Text>
              <Text style={styles.statLabel}>Backlinks</Text>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Keyword Rankings */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Keyword Rankings</Title>
          <Paragraph>Distribution by position</Paragraph>
          <View style={styles.chartContainer}>
            <BarChart
              data={keywordData}
              width={screenWidth}
              height={220}
              chartConfig={chartConfig}
              style={styles.chart}
              verticalLabelRotation={0}
            />
          </View>
        </Card.Content>
      </Card>

      {/* Content Distribution */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Content Status</Title>
          <Paragraph>Published vs Draft posts</Paragraph>
          <View style={styles.chartContainer}>
            <PieChart
              data={contentDistribution}
              width={screenWidth}
              height={220}
              chartConfig={chartConfig}
              accessor="population"
              backgroundColor="transparent"
              paddingLeft="15"
              absolute
            />
          </View>
        </Card.Content>
      </Card>

      {/* Performance Metrics */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Website Performance</Title>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{dashboardData.performance.loadTime}s</Text>
              <Text style={styles.statLabel}>Load Time</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{dashboardData.performance.serverResponse}s</Text>
              <Text style={styles.statLabel}>Server Response</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{dashboardData.performance.pageSize}MB</Text>
              <Text style={styles.statLabel}>Page Size</Text>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Quick Actions */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Quick Actions</Title>
          <View style={styles.actionsContainer}>
            <Button 
              mode="contained" 
              style={styles.actionButton}
              icon="file-document"
              onPress={() => {}}
            >
              New Post
            </Button>
            <Button 
              mode="contained" 
              style={styles.actionButton}
              icon="refresh"
              onPress={onRefresh}
            >
              Refresh Data
            </Button>
            <Button 
              mode="contained" 
              style={styles.actionButton}
              icon="chart-box"
              onPress={() => {}}
            >
              Full Report
            </Button>
          </View>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: spacing.md,
  },
  overviewContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  overviewCard: {
    width: '48%',
    padding: spacing.md,
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  overviewValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  overviewLabel: {
    fontSize: 14,
    color: 'white',
    marginTop: spacing.xs,
  },
  card: {
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  chartContainer: {
    alignItems: 'center',
    marginTop: spacing.md,
  },
  chart: {
    borderRadius: 8,
    marginVertical: spacing.sm,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: spacing.md,
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: spacing.xs,
  },
  actionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: spacing.md,
  },
  actionButton: {
    marginBottom: spacing.sm,
    width: '48%',
  },
});

export default DashboardScreen;
