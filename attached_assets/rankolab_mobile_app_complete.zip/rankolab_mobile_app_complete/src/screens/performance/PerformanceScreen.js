import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, RefreshControl, Dimensions } from 'react-native';
import { Surface, Text, Card, Title, Paragraph, Button, ActivityIndicator, useTheme, DataTable } from 'react-native-paper';
import { LineChart, BarChart } from 'react-native-chart-kit';
import { useSelector, useDispatch } from 'react-redux';
import { spacing, shadows } from '../../utils/theme';

// Placeholder for performance actions
// import { fetchPerformanceMetrics } from '../../store/actions/performanceActions';

const PerformanceScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = useState(false);
  const [performanceData, setPerformanceData] = useState({
    seo: {
      score: 78,
      keywordsRanked: 32,
      backlinks: 156,
      organicTraffic: 1245
    },
    speed: {
      loadTime: 2.3,
      serverResponse: 0.8,
      pageSize: 1.2,
      score: 85
    },
    traffic: {
      visitors: {
        current: 1245,
        previous: 980,
        change: 27
      },
      pageViews: {
        current: 3567,
        previous: 2890,
        change: 23
      },
      bounceRate: {
        current: 42.5,
        previous: 48.2,
        change: -12
      },
      averageSessionDuration: {
        current: 125,
        previous: 110,
        change: 14
      }
    },
    keywords: [
      { keyword: 'wordpress seo plugin', position: 3, volume: 5400, change: 2 },
      { keyword: 'best wordpress plugins', position: 5, volume: 8200, change: -1 },
      { keyword: 'website automation tools', position: 2, volume: 3100, change: 4 },
      { keyword: 'content creation ai', position: 7, volume: 6700, change: 0 },
      { keyword: 'wordpress security', position: 4, volume: 4900, change: 1 }
    ]
  });

  // Sample data for charts
  const trafficTrendData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        data: [1020, 1150, 980, 1300, 1100, 1245],
        color: (opacity = 1) => `rgba(46, 125, 50, ${opacity})`,
        strokeWidth: 2
      }
    ],
    legend: ['Monthly Visitors']
  };

  const keywordPositionsData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        data: [12, 10, 8, 6, 5, 3],
        color: (opacity = 1) => `rgba(255, 111, 0, ${opacity})`,
        strokeWidth: 2
      }
    ],
    legend: ['Avg. Keyword Position']
  };

  const screenWidth = Dimensions.get('window').width - 32;

  const chartConfig = {
    backgroundGradientFrom: '#ffffff',
    backgroundGradientTo: '#ffffff',
    color: (opacity = 1) => `rgba(46, 125, 50, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.5,
    useShadowColorFromDataset: false
  };

  useEffect(() => {
    // In a real implementation, this would fetch data from the API
    // dispatch(fetchPerformanceMetrics());
    
    // For now, we'll use the static data defined above
  }, [dispatch]);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    
    // Simulate API call
    setTimeout(() => {
      // In a real implementation, this would fetch fresh data
      // dispatch(fetchPerformanceMetrics());
      setRefreshing(false);
    }, 2000);
  }, [dispatch]);

  const renderChangeIndicator = (change) => {
    if (change > 0) {
      return <Text style={styles.positiveChange}>+{change}%</Text>;
    } else if (change < 0) {
      return <Text style={styles.negativeChange}>{change}%</Text>;
    } else {
      return <Text style={styles.neutralChange}>{change}%</Text>;
    }
  };

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2E7D32']} />
      }
    >
      {/* Performance Overview */}
      <View style={styles.overviewContainer}>
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.primary }]}>
          <Text style={styles.overviewValue}>{performanceData.seo.score}</Text>
          <Text style={styles.overviewLabel}>SEO Score</Text>
        </Surface>
        
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.accent }]}>
          <Text style={styles.overviewValue}>{performanceData.speed.score}</Text>
          <Text style={styles.overviewLabel}>Speed Score</Text>
        </Surface>
        
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.notification }]}>
          <Text style={styles.overviewValue}>{performanceData.seo.keywordsRanked}</Text>
          <Text style={styles.overviewLabel}>Keywords</Text>
        </Surface>
        
        <Surface style={[styles.overviewCard, { backgroundColor: theme.colors.success }]}>
          <Text style={styles.overviewValue}>{performanceData.seo.backlinks}</Text>
          <Text style={styles.overviewLabel}>Backlinks</Text>
        </Surface>
      </View>

      {/* Traffic Metrics */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Traffic Metrics</Title>
          <View style={styles.metricsContainer}>
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Visitors</Text>
              <Text style={styles.metricValue}>{performanceData.traffic.visitors.current}</Text>
              {renderChangeIndicator(performanceData.traffic.visitors.change)}
            </View>
            
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Page Views</Text>
              <Text style={styles.metricValue}>{performanceData.traffic.pageViews.current}</Text>
              {renderChangeIndicator(performanceData.traffic.pageViews.change)}
            </View>
            
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Bounce Rate</Text>
              <Text style={styles.metricValue}>{performanceData.traffic.bounceRate.current}%</Text>
              {renderChangeIndicator(performanceData.traffic.bounceRate.change)}
            </View>
            
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Avg. Session</Text>
              <Text style={styles.metricValue}>{performanceData.traffic.averageSessionDuration.current}s</Text>
              {renderChangeIndicator(performanceData.traffic.averageSessionDuration.change)}
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Traffic Trend Chart */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Traffic Trend</Title>
          <Paragraph>Last 6 months visitor statistics</Paragraph>
          <View style={styles.chartContainer}>
            <LineChart
              data={trafficTrendData}
              width={screenWidth}
              height={220}
              chartConfig={chartConfig}
              bezier
              style={styles.chart}
            />
          </View>
        </Card.Content>
      </Card>

      {/* Keyword Positions Chart */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Keyword Positions</Title>
          <Paragraph>Average position over time</Paragraph>
          <View style={styles.chartContainer}>
            <LineChart
              data={keywordPositionsData}
              width={screenWidth}
              height={220}
              chartConfig={{
                ...chartConfig,
                color: (opacity = 1) => `rgba(255, 111, 0, ${opacity})`,
              }}
              bezier
              style={styles.chart}
            />
          </View>
        </Card.Content>
      </Card>

      {/* Top Keywords */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Top Keywords</Title>
          <DataTable>
            <DataTable.Header>
              <DataTable.Title>Keyword</DataTable.Title>
              <DataTable.Title numeric>Position</DataTable.Title>
              <DataTable.Title numeric>Volume</DataTable.Title>
              <DataTable.Title numeric>Change</DataTable.Title>
            </DataTable.Header>

            {performanceData.keywords.map((item, index) => (
              <DataTable.Row key={index}>
                <DataTable.Cell>{item.keyword}</DataTable.Cell>
                <DataTable.Cell numeric>{item.position}</DataTable.Cell>
                <DataTable.Cell numeric>{item.volume}</DataTable.Cell>
                <DataTable.Cell numeric>
                  <Text style={
                    item.change > 0 
                      ? styles.positiveChange 
                      : item.change < 0 
                        ? styles.negativeChange 
                        : styles.neutralChange
                  }>
                    {item.change > 0 ? '+' : ''}{item.change}
                  </Text>
                </DataTable.Cell>
              </DataTable.Row>
            ))}
          </DataTable>
        </Card.Content>
      </Card>

      {/* Page Speed */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Page Speed</Title>
          <View style={styles.speedContainer}>
            <View style={styles.speedItem}>
              <Text style={styles.speedLabel}>Load Time</Text>
              <Text style={styles.speedValue}>{performanceData.speed.loadTime}s</Text>
            </View>
            
            <View style={styles.speedItem}>
              <Text style={styles.speedLabel}>Server Response</Text>
              <Text style={styles.speedValue}>{performanceData.speed.serverResponse}s</Text>
            </View>
            
            <View style={styles.speedItem}>
              <Text style={styles.speedLabel}>Page Size</Text>
              <Text style={styles.speedValue}>{performanceData.speed.pageSize}MB</Text>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Actions */}
      <Card style={styles.card}>
        <Card.Content>
          <Title>Performance Actions</Title>
          <View style={styles.actionsContainer}>
            <Button 
              mode="contained" 
              style={styles.actionButton}
              icon="refresh"
              onPress={onRefresh}
            >
              Refresh Data
            </Button>
            <Button 
              mode="contained" 
              style={styles.actionButton}
              icon="file-download"
              onPress={() => {}}
            >
              Export Report
            </Button>
          </View>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: spacing.md,
  },
  overviewContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  overviewCard: {
    width: '48%',
    padding: spacing.md,
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  overviewValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  overviewLabel: {
    fontSize: 14,
    color: 'white',
    marginTop: spacing.xs,
  },
  card: {
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  metricsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: spacing.md,
  },
  metricItem: {
    width: '48%',
    padding: spacing.md,
    marginBottom: spacing.md,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    ...shadows.small,
  },
  metricLabel: {
    fontSize: 14,
    color: '#666',
  },
  metricValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginTop: spacing.xs,
  },
  positiveChange: {
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  negativeChange: {
    color: '#F44336',
    fontWeight: 'bold',
  },
  neutralChange: {
    color: '#9E9E9E',
    fontWeight: 'bold',
  },
  chartContainer: {
    alignItems: 'center',
    marginTop: spacing.md,
  },
  chart: {
    borderRadius: 8,
    marginVertical: spacing.sm,
  },
  speedContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: spacing.md,
  },
  speedItem: {
    alignItems: 'center',
    flex: 1,
  },
  speedLabel: {
    fontSize: 14,
    color: '#666',
  },
  speedValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginTop: spacing.xs,
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: spacing.md,
  },
  actionButton: {
    flex: 1,
    marginHorizontal: spacing.xs,
  },
});

export default PerformanceScreen;
