import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { Surface, Text, Card, Title, Paragraph, Button, Avatar, Badge, Divider, IconButton, useTheme } from 'react-native-paper';
import { useSelector, useDispatch } from 'react-redux';
import { spacing, shadows } from '../../utils/theme';

// Placeholder for notification actions
// import { fetchNotifications, markNotificationAsRead } from '../../store/actions/notificationActions';

const NotificationsScreen = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = useState(false);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'Traffic Spike Detected',
      message: 'Your website traffic has increased by 35% in the last 24 hours.',
      date: '2025-04-15T08:30:00Z',
      type: 'traffic',
      read: false,
      priority: 'high'
    },
    {
      id: 2,
      title: 'New Backlink Detected',
      message: 'Your website received a new backlink from example.com with DA 65.',
      date: '2025-04-14T16:45:00Z',
      type: 'seo',
      read: false,
      priority: 'medium'
    },
    {
      id: 3,
      title: 'Content Update Required',
      message: 'Your post "WordPress Security Best Practices" needs updating based on recent changes.',
      date: '2025-04-13T11:20:00Z',
      type: 'content',
      read: true,
      priority: 'medium'
    },
    {
      id: 4,
      title: 'Keyword Ranking Improved',
      message: 'Your keyword "wordpress seo plugin" has moved up from position 5 to position 3.',
      date: '2025-04-12T09:15:00Z',
      type: 'seo',
      read: true,
      priority: 'medium'
    },
    {
      id: 5,
      title: 'Page Speed Alert',
      message: 'Your homepage load time has increased to 3.5s, which may affect user experience.',
      date: '2025-04-11T14:30:00Z',
      type: 'performance',
      read: true,
      priority: 'high'
    },
    {
      id: 6,
      title: 'Plugin Update Available',
      message: 'A new version of Rankolab plugin (v2.3.1) is available for installation.',
      date: '2025-04-10T10:45:00Z',
      type: 'system',
      read: true,
      priority: 'low'
    }
  ]);
  
  const [activeFilter, setActiveFilter] = useState('all');

  useEffect(() => {
    // In a real implementation, this would fetch data from the API
    // dispatch(fetchNotifications());
    
    // For now, we'll use the static data defined above
  }, [dispatch]);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    
    // Simulate API call
    setTimeout(() => {
      // In a real implementation, this would fetch fresh data
      // dispatch(fetchNotifications());
      setRefreshing(false);
    }, 2000);
  }, [dispatch]);

  const handleMarkAsRead = (id) => {
    // In a real implementation, this would call an API
    // dispatch(markNotificationAsRead(id));
    
    // For now, we'll update the local state
    setNotifications(prevNotifications => 
      prevNotifications.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const handleMarkAllAsRead = () => {
    // In a real implementation, this would call an API
    // dispatch(markAllNotificationsAsRead());
    
    // For now, we'll update the local state
    setNotifications(prevNotifications => 
      prevNotifications.map(notification => ({ ...notification, read: true }))
    );
  };

  const filterNotifications = () => {
    if (activeFilter === 'all') {
      return notifications;
    } else if (activeFilter === 'unread') {
      return notifications.filter(notification => !notification.read);
    } else {
      return notifications.filter(notification => notification.type === activeFilter);
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'traffic':
        return 'trending-up';
      case 'seo':
        return 'magnify';
      case 'content':
        return 'file-document';
      case 'performance':
        return 'speedometer';
      case 'system':
        return 'cog';
      default:
        return 'bell';
    }
  };

  const getNotificationColor = (priority) => {
    switch (priority) {
      case 'high':
        return '#F44336';
      case 'medium':
        return '#FF9800';
      case 'low':
        return '#4CAF50';
      default:
        return '#2196F3';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const renderNotificationItem = ({ item }) => (
    <Card 
      style={[
        styles.notificationCard, 
        !item.read && styles.unreadCard
      ]}
      onPress={() => handleMarkAsRead(item.id)}
    >
      <Card.Content style={styles.cardContent}>
        <View style={styles.iconContainer}>
          <Avatar.Icon 
            size={40} 
            icon={getNotificationIcon(item.type)} 
            style={{ backgroundColor: getNotificationColor(item.priority) }} 
          />
          {!item.read && (
            <Badge style={styles.unreadBadge} />
          )}
        </View>
        <View style={styles.contentContainer}>
          <Title style={styles.notificationTitle}>{item.title}</Title>
          <Paragraph style={styles.notificationMessage}>{item.message}</Paragraph>
          <Text style={styles.notificationDate}>{formatDate(item.date)}</Text>
        </View>
      </Card.Content>
    </Card>
  );

  const unreadCount = notifications.filter(notification => !notification.read).length;

  return (
    <View style={styles.container}>
      {/* Notification Summary */}
      <Surface style={styles.summaryContainer}>
        <View style={styles.summaryContent}>
          <Text style={styles.summaryTitle}>Notifications</Text>
          <Text style={styles.summaryCount}>{unreadCount} unread</Text>
        </View>
        <Button 
          mode="text" 
          onPress={handleMarkAllAsRead}
          disabled={unreadCount === 0}
        >
          Mark All Read
        </Button>
      </Surface>

      {/* Filters */}
      <View style={styles.filtersContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filtersScrollContent}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'all' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('all')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'all' && { color: 'white' }
            ]}>All</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'unread' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('unread')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'unread' && { color: 'white' }
            ]}>Unread</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'traffic' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('traffic')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'traffic' && { color: 'white' }
            ]}>Traffic</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'seo' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('seo')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'seo' && { color: 'white' }
            ]}>SEO</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'content' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('content')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'content' && { color: 'white' }
            ]}>Content</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'performance' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('performance')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'performance' && { color: 'white' }
            ]}>Performance</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.filterButton,
              activeFilter === 'system' && { backgroundColor: theme.colors.primary }
            ]}
            onPress={() => setActiveFilter('system')}
          >
            <Text style={[
              styles.filterText,
              activeFilter === 'system' && { color: 'white' }
            ]}>System</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      {/* Notifications List */}
      <FlatList
        data={filterNotifications()}
        renderItem={renderNotificationItem}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#2E7D32']} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No notifications found</Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  summaryContent: {
    flexDirection: 'column',
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  summaryCount: {
    fontSize: 14,
    color: '#666',
  },
  filtersContainer: {
    padding: spacing.md,
  },
  filtersScrollContent: {
    paddingRight: spacing.md,
  },
  filterButton: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    marginRight: spacing.sm,
    borderRadius: 20,
    backgroundColor: '#E0E0E0',
  },
  filterText: {
    fontSize: 14,
    color: '#333',
  },
  listContainer: {
    padding: spacing.md,
    paddingTop: 0,
  },
  notificationCard: {
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  unreadCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#2E7D32',
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconContainer: {
    marginRight: spacing.md,
    position: 'relative',
  },
  unreadBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#2E7D32',
  },
  contentContainer: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 16,
    marginBottom: spacing.xs,
  },
  notificationMessage: {
    fontSize: 14,
    color: '#666',
    marginBottom: spacing.xs,
  },
  notificationDate: {
    fontSize: 12,
    color: '#999',
  },
  emptyContainer: {
    padding: spacing.xl,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
  },
});

export default NotificationsScreen;
