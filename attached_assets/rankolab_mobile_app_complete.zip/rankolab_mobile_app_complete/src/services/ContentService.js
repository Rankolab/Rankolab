import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';

class ContentService {
  /**
   * Get content statistics
   * @returns {Promise} - Response from API
   */
  static async getContentStats() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/content/stats`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch content statistics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching content statistics'
        };
      }
    }
  }

  /**
   * Get posts with pagination and filters
   * @param {number} page - Page number
   * @param {number} perPage - Items per page
   * @param {Object} filters - Filter options
   * @returns {Promise} - Response from API
   */
  static async getPosts(page = 1, perPage = 10, filters = {}) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/content/posts`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
        params: {
          page,
          per_page: perPage,
          ...filters
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch posts'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching posts'
        };
      }
    }
  }

  /**
   * Get post details
   * @param {number} postId - Post ID
   * @returns {Promise} - Response from API
   */
  static async getPostDetails(postId) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/content/posts/${postId}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch post details'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching post details'
        };
      }
    }
  }

  /**
   * Create new post
   * @param {Object} postData - Post data
   * @returns {Promise} - Response from API
   */
  static async createPost(postData) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.post(`${API_BASE_URL}/rankolab/v1/content/posts`, postData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to create post'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while creating post'
        };
      }
    }
  }

  /**
   * Update existing post
   * @param {number} postId - Post ID
   * @param {Object} postData - Post data
   * @returns {Promise} - Response from API
   */
  static async updatePost(postId, postData) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.put(`${API_BASE_URL}/rankolab/v1/content/posts/${postId}`, postData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to update post'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while updating post'
        };
      }
    }
  }

  /**
   * Delete post
   * @param {number} postId - Post ID
   * @returns {Promise} - Response from API
   */
  static async deletePost(postId) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.delete(`${API_BASE_URL}/rankolab/v1/content/posts/${postId}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to delete post'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while deleting post'
        };
      }
    }
  }

  /**
   * Get mock content data for offline/development use
   * @returns {Object} - Mock content data
   */
  static getMockContentData() {
    return {
      success: true,
      data: {
        stats: {
          totalPosts: 87,
          publishedPosts: 75,
          draftPosts: 12,
          categories: 8,
          tags: 45,
          authors: 3
        },
        posts: [
          {
            id: 1,
            title: 'How to Improve Your Website SEO in 2025',
            excerpt: 'Learn the latest SEO techniques to boost your website ranking in search engines.',
            date: '2025-04-10T10:30:00Z',
            author: 'John Smith',
            categories: ['SEO', 'Marketing'],
            status: 'published',
            featured: true
          },
          {
            id: 2,
            title: 'The Ultimate Guide to Content Marketing',
            excerpt: 'Discover how content marketing can drive traffic and increase conversions for your business.',
            date: '2025-04-08T14:15:00Z',
            author: 'Jane Doe',
            categories: ['Content', 'Marketing'],
            status: 'published',
            featured: false
          },
          {
            id: 3,
            title: 'WordPress Security Best Practices',
            excerpt: 'Protect your WordPress website from hackers with these essential security measures.',
            date: '2025-04-05T09:45:00Z',
            author: 'Mike Johnson',
            categories: ['WordPress', 'Security'],
            status: 'published',
            featured: false
          },
          {
            id: 4,
            title: 'Upcoming Features in WordPress 6.5',
            excerpt: 'A sneak peek at the exciting new features coming in WordPress 6.5.',
            date: '2025-04-02T16:20:00Z',
            author: 'Sarah Williams',
            categories: ['WordPress', 'News'],
            status: 'draft',
            featured: false
          },
          {
            id: 5,
            title: 'How to Speed Up Your WordPress Website',
            excerpt: 'Optimize your WordPress website for maximum performance with these tips.',
            date: '2025-03-28T11:10:00Z',
            author: 'John Smith',
            categories: ['WordPress', 'Performance'],
            status: 'published',
            featured: true
          }
        ],
        pagination: {
          currentPage: 1,
          totalPages: 18,
          totalItems: 87,
          perPage: 5
        }
      }
    };
  }
}

export default ContentService;
