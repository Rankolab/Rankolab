import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';

class WordPressApiService {
  /**
   * Initialize the API service with the WordPress site URL and API key
   * @param {string} siteUrl - WordPress site URL
   * @param {string} apiKey - API key for authentication
   * @returns {Promise} - Response indicating success or failure
   */
  static async initialize(siteUrl, apiKey) {
    try {
      // Store the site URL and API key for future use
      await AsyncStorage.setItem('wp_site_url', siteUrl);
      await AsyncStorage.setItem('wp_api_key', apiKey);
      
      // Test the connection to verify credentials
      const testResponse = await this.testConnection();
      
      return testResponse;
    } catch (error) {
      return {
        success: false,
        message: error.message || 'Failed to initialize WordPress API service'
      };
    }
  }

  /**
   * Test the connection to the WordPress site
   * @returns {Promise} - Response indicating success or failure
   */
  static async testConnection() {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/test-connection`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to connect to WordPress site'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check the URL and your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while testing connection'
        };
      }
    }
  }

  /**
   * Get WordPress site information
   * @returns {Promise} - Response with site information
   */
  static async getSiteInfo() {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/site-info`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get site information'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting site information'
        };
      }
    }
  }

  /**
   * Get WordPress plugin status
   * @returns {Promise} - Response with plugin status
   */
  static async getPluginStatus() {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/plugin-status`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get plugin status'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting plugin status'
        };
      }
    }
  }

  /**
   * Get WordPress content statistics
   * @returns {Promise} - Response with content statistics
   */
  static async getContentStats() {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/content/stats`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get content statistics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting content statistics'
        };
      }
    }
  }

  /**
   * Get WordPress posts
   * @param {number} page - Page number
   * @param {number} perPage - Items per page
   * @param {Object} filters - Filter options
   * @returns {Promise} - Response with posts
   */
  static async getPosts(page = 1, perPage = 10, filters = {}) {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/content/posts`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        },
        params: {
          page,
          per_page: perPage,
          ...filters
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get posts'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting posts'
        };
      }
    }
  }

  /**
   * Get WordPress performance metrics
   * @returns {Promise} - Response with performance metrics
   */
  static async getPerformanceMetrics() {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/performance/metrics`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get performance metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting performance metrics'
        };
      }
    }
  }

  /**
   * Get WordPress SEO metrics
   * @returns {Promise} - Response with SEO metrics
   */
  static async getSeoMetrics() {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/performance/seo`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get SEO metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting SEO metrics'
        };
      }
    }
  }

  /**
   * Create a new WordPress post
   * @param {Object} postData - Post data
   * @returns {Promise} - Response with created post
   */
  static async createPost(postData) {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.post(`${siteUrl}/wp-json/rankolab/v1/content/posts`, postData, {
        headers: {
          'X-Rankolab-API-Key': apiKey,
          'Content-Type': 'application/json'
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to create post'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while creating post'
        };
      }
    }
  }

  /**
   * Get WordPress notifications
   * @param {number} page - Page number
   * @param {number} perPage - Items per page
   * @returns {Promise} - Response with notifications
   */
  static async getNotifications(page = 1, perPage = 20) {
    try {
      const siteUrl = await AsyncStorage.getItem('wp_site_url');
      const apiKey = await AsyncStorage.getItem('wp_api_key');
      
      if (!siteUrl || !apiKey) {
        return {
          success: false,
          message: 'WordPress site URL or API key not found'
        };
      }
      
      const response = await axios.get(`${siteUrl}/wp-json/rankolab/v1/notifications`, {
        headers: {
          'X-Rankolab-API-Key': apiKey
        },
        params: {
          page,
          per_page: perPage
        }
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to get notifications'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from WordPress site. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while getting notifications'
        };
      }
    }
  }
}

export default WordPressApiService;
