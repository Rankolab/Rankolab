import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';

class AuthService {
  /**
   * Login user
   * @param {string} username - Username
   * @param {string} password - Password
   * @returns {Promise} - Response from API
   */
  static async login(username, password) {
    try {
      const response = await axios.post(`${API_BASE_URL}/rankolab/v1/auth/login`, {
        username,
        password
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        return {
          success: false,
          message: error.response.data.message || 'Login failed'
        };
      } else if (error.request) {
        // The request was made but no response was received
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        // Something happened in setting up the request that triggered an Error
        return {
          success: false,
          message: error.message || 'An error occurred during login'
        };
      }
    }
  }

  /**
   * Register user
   * @param {string} username - Username
   * @param {string} email - Email
   * @param {string} password - Password
   * @returns {Promise} - Response from API
   */
  static async register(username, email, password) {
    try {
      const response = await axios.post(`${API_BASE_URL}/rankolab/v1/auth/register`, {
        username,
        email,
        password
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Registration failed'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred during registration'
        };
      }
    }
  }

  /**
   * Validate token
   * @param {string} token - JWT token
   * @returns {Promise} - Response from API
   */
  static async validateToken(token) {
    try {
      const response = await axios.post(`${API_BASE_URL}/rankolab/v1/auth/validate`, {
        token
      });
      
      return response.data;
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Token validation failed'
      };
    }
  }

  /**
   * Set auth token for all future requests
   * @param {string} token - JWT token
   */
  static setAuthToken(token) {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
      delete axios.defaults.headers.common['Authorization'];
    }
  }
}

export default AuthService;
