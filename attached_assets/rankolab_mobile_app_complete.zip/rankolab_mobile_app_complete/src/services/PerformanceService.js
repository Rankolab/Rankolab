import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';

class PerformanceService {
  /**
   * Get all performance metrics
   * @returns {Promise} - Response from API
   */
  static async getPerformanceMetrics() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance/metrics`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch performance metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching performance metrics'
        };
      }
    }
  }

  /**
   * Get traffic metrics
   * @param {string} period - Time period (day, week, month, year)
   * @returns {Promise} - Response from API
   */
  static async getTrafficMetrics(period = 'month') {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance/traffic`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
        params: {
          period
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch traffic metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching traffic metrics'
        };
      }
    }
  }

  /**
   * Get SEO metrics
   * @returns {Promise} - Response from API
   */
  static async getSeoMetrics() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance/seo`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch SEO metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching SEO metrics'
        };
      }
    }
  }

  /**
   * Get keyword rankings
   * @returns {Promise} - Response from API
   */
  static async getKeywordRankings() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance/keywords`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch keyword rankings'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching keyword rankings'
        };
      }
    }
  }

  /**
   * Get page speed metrics
   * @returns {Promise} - Response from API
   */
  static async getPageSpeedMetrics() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance/speed`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch page speed metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching page speed metrics'
        };
      }
    }
  }

  /**
   * Get mock performance data for offline/development use
   * @returns {Object} - Mock performance data
   */
  static getMockPerformanceData() {
    return {
      success: true,
      data: {
        seo: {
          score: 78,
          keywordsRanked: 32,
          backlinks: 156,
          organicTraffic: 1245
        },
        speed: {
          loadTime: 2.3,
          serverResponse: 0.8,
          pageSize: 1.2,
          score: 85
        },
        traffic: {
          visitors: {
            current: 1245,
            previous: 980,
            change: 27
          },
          pageViews: {
            current: 3567,
            previous: 2890,
            change: 23
          },
          bounceRate: {
            current: 42.5,
            previous: 48.2,
            change: -12
          },
          averageSessionDuration: {
            current: 125,
            previous: 110,
            change: 14
          },
          trend: [1020, 1150, 980, 1300, 1100, 1245]
        },
        keywords: [
          { keyword: 'wordpress seo plugin', position: 3, volume: 5400, change: 2 },
          { keyword: 'best wordpress plugins', position: 5, volume: 8200, change: -1 },
          { keyword: 'website automation tools', position: 2, volume: 3100, change: 4 },
          { keyword: 'content creation ai', position: 7, volume: 6700, change: 0 },
          { keyword: 'wordpress security', position: 4, volume: 4900, change: 1 }
        ],
        keywordPositions: [12, 10, 8, 6, 5, 3]
      }
    };
  }
}

export default PerformanceService;
