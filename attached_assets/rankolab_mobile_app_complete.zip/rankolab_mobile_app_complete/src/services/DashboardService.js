import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';

class DashboardService {
  /**
   * Get dashboard data
   * @returns {Promise} - Response from API
   */
  static async getDashboardData() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/dashboard`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch dashboard data'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching dashboard data'
        };
      }
    }
  }

  /**
   * Get traffic data for specific date range
   * @param {string} startDate - Start date in YYYY-MM-DD format
   * @param {string} endDate - End date in YYYY-MM-DD format
   * @returns {Promise} - Response from API
   */
  static async getTrafficData(startDate, endDate) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
        params: {
          start_date: startDate,
          end_date: endDate
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch traffic data'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching traffic data'
        };
      }
    }
  }

  /**
   * Get SEO data
   * @returns {Promise} - Response from API
   */
  static async getSeoData() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/seo`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch SEO data'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching SEO data'
        };
      }
    }
  }

  /**
   * Get content statistics
   * @returns {Promise} - Response from API
   */
  static async getContentStats() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/content`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch content statistics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching content statistics'
        };
      }
    }
  }

  /**
   * Get performance metrics
   * @returns {Promise} - Response from API
   */
  static async getPerformanceMetrics() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/performance`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch performance metrics'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching performance metrics'
        };
      }
    }
  }

  /**
   * Get mock dashboard data for offline/development use
   * @returns {Object} - Mock dashboard data
   */
  static getMockDashboardData() {
    return {
      success: true,
      data: {
        traffic: {
          visitors: 1245,
          pageViews: 3567,
          bounceRate: 42.5,
          averageSessionDuration: 125,
          trend: [20, 45, 28, 80, 99, 43, 50]
        },
        seo: {
          score: 78,
          keywordsRanked: 32,
          backlinks: 156,
          keywordRankings: [12, 8, 6, 4, 2]
        },
        content: {
          totalPosts: 87,
          publishedPosts: 75,
          draftPosts: 12,
          categories: 8
        },
        performance: {
          loadTime: 2.3,
          serverResponse: 0.8,
          pageSize: 1.2
        }
      }
    };
  }
}

export default DashboardService;
