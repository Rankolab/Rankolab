import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';

class NotificationService {
  /**
   * Get notifications with pagination
   * @param {number} page - Page number
   * @param {number} perPage - Items per page
   * @returns {Promise} - Response from API
   */
  static async getNotifications(page = 1, perPage = 20) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.get(`${API_BASE_URL}/rankolab/v1/notifications`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
        params: {
          page,
          per_page: perPage
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to fetch notifications'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while fetching notifications'
        };
      }
    }
  }

  /**
   * Mark notification as read
   * @param {number} notificationId - Notification ID
   * @returns {Promise} - Response from API
   */
  static async markAsRead(notificationId) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.put(`${API_BASE_URL}/rankolab/v1/notifications/${notificationId}/read`, {}, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to mark notification as read'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while marking notification as read'
        };
      }
    }
  }

  /**
   * Mark all notifications as read
   * @returns {Promise} - Response from API
   */
  static async markAllAsRead() {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.put(`${API_BASE_URL}/rankolab/v1/notifications/read-all`, {}, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to mark all notifications as read'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while marking all notifications as read'
        };
      }
    }
  }

  /**
   * Register device for push notifications
   * @param {string} deviceToken - Device token
   * @param {string} deviceType - Device type (ios, android)
   * @returns {Promise} - Response from API
   */
  static async registerDevice(deviceToken, deviceType) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.post(`${API_BASE_URL}/rankolab/v1/notifications/register-device`, {
        device_token: deviceToken,
        device_type: deviceType
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to register device'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while registering device'
        };
      }
    }
  }

  /**
   * Update notification preferences
   * @param {Object} preferences - Notification preferences
   * @returns {Promise} - Response from API
   */
  static async updatePreferences(preferences) {
    try {
      const token = await AsyncStorage.getItem('token');
      
      if (!token) {
        return {
          success: false,
          message: 'Authentication token not found'
        };
      }
      
      const response = await axios.put(`${API_BASE_URL}/rankolab/v1/notifications/preferences`, preferences, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        return {
          success: false,
          message: error.response.data.message || 'Failed to update notification preferences'
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'No response from server. Please check your internet connection.'
        };
      } else {
        return {
          success: false,
          message: error.message || 'An error occurred while updating notification preferences'
        };
      }
    }
  }

  /**
   * Get mock notification data for offline/development use
   * @returns {Object} - Mock notification data
   */
  static getMockNotificationData() {
    return {
      success: true,
      data: {
        notifications: [
          {
            id: 1,
            title: 'Traffic Spike Detected',
            message: 'Your website traffic has increased by 35% in the last 24 hours.',
            date: '2025-04-15T08:30:00Z',
            type: 'traffic',
            read: false,
            priority: 'high'
          },
          {
            id: 2,
            title: 'New Backlink Detected',
            message: 'Your website received a new backlink from example.com with DA 65.',
            date: '2025-04-14T16:45:00Z',
            type: 'seo',
            read: false,
            priority: 'medium'
          },
          {
            id: 3,
            title: 'Content Update Required',
            message: 'Your post "WordPress Security Best Practices" needs updating based on recent changes.',
            date: '2025-04-13T11:20:00Z',
            type: 'content',
            read: true,
            priority: 'medium'
          },
          {
            id: 4,
            title: 'Keyword Ranking Improved',
            message: 'Your keyword "wordpress seo plugin" has moved up from position 5 to position 3.',
            date: '2025-04-12T09:15:00Z',
            type: 'seo',
            read: true,
            priority: 'medium'
          },
          {
            id: 5,
            title: 'Page Speed Alert',
            message: 'Your homepage load time has increased to 3.5s, which may affect user experience.',
            date: '2025-04-11T14:30:00Z',
            type: 'performance',
            read: true,
            priority: 'high'
          },
          {
            id: 6,
            title: 'Plugin Update Available',
            message: 'A new version of Rankolab plugin (v2.3.1) is available for installation.',
            date: '2025-04-10T10:45:00Z',
            type: 'system',
            read: true,
            priority: 'low'
          }
        ],
        pagination: {
          currentPage: 1,
          totalPages: 1,
          totalItems: 6,
          perPage: 20
        }
      }
    };
  }
}

export default NotificationService;
