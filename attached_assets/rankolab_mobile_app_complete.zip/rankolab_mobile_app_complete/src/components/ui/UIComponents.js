import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, Card, Title, Paragraph, useTheme } from 'react-native-paper';
import { spacing, shadows } from '../../utils/theme';

/**
 * A reusable card component with consistent styling across the app
 * 
 * @param {Object} props - Component props
 * @param {string} props.title - Card title
 * @param {string} props.subtitle - Optional card subtitle
 * @param {React.ReactNode} props.children - Card content
 * @param {Object} props.style - Additional styles for the card
 * @param {Function} props.onPress - Function to call when card is pressed
 * @param {boolean} props.elevated - Whether to show elevated shadow
 * @param {React.ReactNode} props.rightContent - Optional content to show on the right side of the header
 * @param {React.ReactNode} props.actions - Optional actions to show at the bottom of the card
 * @returns {React.ReactNode}
 */
const AppCard = ({
  title,
  subtitle,
  children,
  style,
  onPress,
  elevated = true,
  rightContent,
  actions
}) => {
  const theme = useTheme();
  
  return (
    <Card 
      style={[
        styles.card, 
        elevated && styles.elevated,
        style
      ]}
      onPress={onPress}
    >
      {title && (
        <Card.Title
          title={title}
          subtitle={subtitle}
          right={() => rightContent}
        />
      )}
      <Card.Content>
        {children}
      </Card.Content>
      {actions && (
        <Card.Actions>
          {actions}
        </Card.Actions>
      )}
    </Card>
  );
};

/**
 * A reusable metric card component for displaying statistics
 * 
 * @param {Object} props - Component props
 * @param {string} props.title - Metric title
 * @param {string|number} props.value - Metric value
 * @param {string} props.unit - Optional unit for the value
 * @param {number} props.change - Optional percentage change
 * @param {Object} props.style - Additional styles for the card
 * @param {Function} props.onPress - Function to call when card is pressed
 * @param {string} props.icon - Optional icon name
 * @returns {React.ReactNode}
 */
const MetricCard = ({
  title,
  value,
  unit,
  change,
  style,
  onPress,
  icon
}) => {
  const theme = useTheme();
  
  const getChangeColor = () => {
    if (change > 0) return '#4CAF50';
    if (change < 0) return '#F44336';
    return '#9E9E9E';
  };
  
  const formatChange = () => {
    if (change === undefined || change === null) return null;
    return `${change > 0 ? '+' : ''}${change}%`;
  };
  
  return (
    <Card 
      style={[styles.metricCard, style]}
      onPress={onPress}
    >
      <Card.Content style={styles.metricContent}>
        <Title style={styles.metricTitle}>{title}</Title>
        <View style={styles.metricValueContainer}>
          <Paragraph style={styles.metricValue}>
            {value}
            {unit && <Paragraph style={styles.metricUnit}>{unit}</Paragraph>}
          </Paragraph>
          {change !== undefined && change !== null && (
            <Paragraph style={[styles.metricChange, { color: getChangeColor() }]}>
              {formatChange()}
            </Paragraph>
          )}
        </View>
      </Card.Content>
    </Card>
  );
};

/**
 * A reusable button component with consistent styling
 * 
 * @param {Object} props - Component props
 * @param {string} props.label - Button label
 * @param {Function} props.onPress - Function to call when button is pressed
 * @param {string} props.mode - Button mode (contained, outlined, text)
 * @param {boolean} props.loading - Whether to show loading indicator
 * @param {boolean} props.disabled - Whether button is disabled
 * @param {string} props.icon - Optional icon name
 * @param {Object} props.style - Additional styles for the button
 * @returns {React.ReactNode}
 */
const AppButton = ({
  label,
  onPress,
  mode = 'contained',
  loading = false,
  disabled = false,
  icon,
  style
}) => {
  return (
    <Button
      mode={mode}
      onPress={onPress}
      loading={loading}
      disabled={disabled}
      icon={icon}
      style={[styles.button, style]}
    >
      {label}
    </Button>
  );
};

/**
 * A reusable empty state component
 * 
 * @param {Object} props - Component props
 * @param {string} props.title - Empty state title
 * @param {string} props.message - Empty state message
 * @param {string} props.buttonLabel - Optional button label
 * @param {Function} props.onButtonPress - Function to call when button is pressed
 * @param {string} props.icon - Optional icon name
 * @param {Object} props.style - Additional styles for the container
 * @returns {React.ReactNode}
 */
const EmptyState = ({
  title,
  message,
  buttonLabel,
  onButtonPress,
  icon,
  style
}) => {
  return (
    <View style={[styles.emptyContainer, style]}>
      {icon && <Icon name={icon} size={64} color="#BDBDBD" />}
      <Title style={styles.emptyTitle}>{title}</Title>
      <Paragraph style={styles.emptyMessage}>{message}</Paragraph>
      {buttonLabel && onButtonPress && (
        <Button
          mode="contained"
          onPress={onButtonPress}
          style={styles.emptyButton}
        >
          {buttonLabel}
        </Button>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing.md,
    borderRadius: 8,
  },
  elevated: {
    ...shadows.small,
  },
  metricCard: {
    marginBottom: spacing.md,
    borderRadius: 8,
    ...shadows.small,
  },
  metricContent: {
    padding: spacing.sm,
  },
  metricTitle: {
    fontSize: 14,
    marginBottom: spacing.xs,
  },
  metricValueContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
  },
  metricValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  metricUnit: {
    fontSize: 14,
    marginLeft: spacing.xs,
  },
  metricChange: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  button: {
    borderRadius: 4,
    marginVertical: spacing.xs,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  emptyTitle: {
    marginTop: spacing.md,
    textAlign: 'center',
  },
  emptyMessage: {
    textAlign: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.md,
    color: '#757575',
  },
  emptyButton: {
    marginTop: spacing.md,
  },
});

export { AppCard, MetricCard, AppButton, EmptyState };
