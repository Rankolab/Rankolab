import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { TextInput, HelperText, useTheme } from 'react-native-paper';
import { spacing } from '../../utils/theme';

/**
 * A reusable form input component with consistent styling and validation
 * 
 * @param {Object} props - Component props
 * @param {string} props.label - Input label
 * @param {string} props.value - Input value
 * @param {Function} props.onChangeText - Function to call when text changes
 * @param {string} props.placeholder - Input placeholder
 * @param {string} props.error - Error message to display
 * @param {boolean} props.secureTextEntry - Whether to hide text entry
 * @param {string} props.keyboardType - Keyboard type
 * @param {boolean} props.multiline - Whether input is multiline
 * @param {number} props.numberOfLines - Number of lines for multiline input
 * @param {Object} props.style - Additional styles for the input
 * @param {boolean} props.disabled - Whether input is disabled
 * @param {string} props.mode - Input mode (flat, outlined)
 * @param {string} props.leftIcon - Name of icon to display on the left
 * @param {string} props.rightIcon - Name of icon to display on the right
 * @param {Function} props.onRightIconPress - Function to call when right icon is pressed
 * @returns {React.ReactNode}
 */
const FormInput = ({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  secureTextEntry = false,
  keyboardType = 'default',
  multiline = false,
  numberOfLines = 1,
  style,
  disabled = false,
  mode = 'outlined',
  leftIcon,
  rightIcon,
  onRightIconPress,
  ...rest
}) => {
  const theme = useTheme();
  
  return (
    <View style={[styles.inputContainer, style]}>
      <TextInput
        label={label}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        multiline={multiline}
        numberOfLines={numberOfLines}
        disabled={disabled}
        mode={mode}
        error={!!error}
        left={leftIcon ? <TextInput.Icon icon={leftIcon} /> : null}
        right={rightIcon ? (
          <TextInput.Icon 
            icon={rightIcon} 
            onPress={onRightIconPress}
          />
        ) : null}
        style={[
          styles.input,
          multiline && styles.multilineInput,
          Platform.OS === 'ios' ? styles.iosInput : styles.androidInput
        ]}
        {...rest}
      />
      {error ? (
        <HelperText type="error" visible={!!error}>
          {error}
        </HelperText>
      ) : null}
    </View>
  );
};

/**
 * A reusable form section component for grouping related inputs
 * 
 * @param {Object} props - Component props
 * @param {string} props.title - Section title
 * @param {React.ReactNode} props.children - Section content
 * @param {Object} props.style - Additional styles for the section
 * @returns {React.ReactNode}
 */
const FormSection = ({
  title,
  children,
  style
}) => {
  const theme = useTheme();
  
  return (
    <View style={[styles.sectionContainer, style]}>
      {title && (
        <View style={styles.sectionTitleContainer}>
          <View style={styles.sectionTitleLine} />
          <View style={styles.sectionTitleTextContainer}>
            <HelperText style={[styles.sectionTitle, { color: theme.colors.primary }]}>
              {title.toUpperCase()}
            </HelperText>
          </View>
          <View style={styles.sectionTitleLine} />
        </View>
      )}
      <View style={styles.sectionContent}>
        {children}
      </View>
    </View>
  );
};

/**
 * A reusable form component that handles form state and validation
 * 
 * @param {Object} props - Component props
 * @param {React.ReactNode} props.children - Form content
 * @param {Function} props.onSubmit - Function to call when form is submitted
 * @param {Object} props.style - Additional styles for the form
 * @returns {React.ReactNode}
 */
const Form = ({
  children,
  onSubmit,
  style
}) => {
  return (
    <View style={[styles.formContainer, style]}>
      {children}
    </View>
  );
};

/**
 * A reusable error message component
 * 
 * @param {Object} props - Component props
 * @param {string} props.message - Error message
 * @param {Object} props.style - Additional styles for the error
 * @returns {React.ReactNode}
 */
const ErrorMessage = ({
  message,
  style
}) => {
  if (!message) return null;
  
  return (
    <HelperText type="error" visible={!!message} style={[styles.errorMessage, style]}>
      {message}
    </HelperText>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    marginBottom: spacing.md,
  },
  input: {
    backgroundColor: 'transparent',
  },
  multilineInput: {
    minHeight: 100,
  },
  iosInput: {
    // iOS specific styles
    paddingVertical: Platform.OS === 'ios' ? 12 : 0,
  },
  androidInput: {
    // Android specific styles
  },
  formContainer: {
    width: '100%',
  },
  sectionContainer: {
    marginBottom: spacing.lg,
  },
  sectionTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionTitleLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E0E0E0',
  },
  sectionTitleTextContainer: {
    paddingHorizontal: spacing.sm,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  sectionContent: {
    
  },
  errorMessage: {
    marginBottom: spacing.md,
    fontSize: 14,
  },
});

export { FormInput, FormSection, Form, ErrorMessage };
