// API base URL
export const API_BASE_URL = 'https://api.rankolab.com';

// App constants
export const APP_NAME = 'Rankolab';
export const APP_VERSION = '1.0.0';

// Storage keys
export const STORAGE_KEYS = {
  TOKEN: 'rankolab_token',
  USER: 'rankolab_user',
  THEME: 'rankolab_theme',
  NOTIFICATION_SETTINGS: 'rankolab_notification_settings',
  OFFLINE_DATA: 'rankolab_offline_data',
  OFFLINE_ACTIONS: 'rankolab_offline_actions'
};

// Dashboard refresh intervals (in milliseconds)
export const REFRESH_INTERVALS = {
  DASHBOARD: 5 * 60 * 1000, // 5 minutes
  NOTIFICATIONS: 2 * 60 * 1000, // 2 minutes
  CONTENT: 10 * 60 * 1000 // 10 minutes
};

// Pagination defaults
export const PAGINATION = {
  POSTS_PER_PAGE: 10,
  NOTIFICATIONS_PER_PAGE: 20
};

// Error messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your internet connection.',
  SERVER_ERROR: 'Server error. Please try again later.',
  AUTH_ERROR: 'Authentication error. Please log in again.',
  VALIDATION_ERROR: 'Please check your input and try again.'
};

// Success messages
export const SUCCESS_MESSAGES = {
  LOGIN_SUCCESS: 'Login successful',
  REGISTER_SUCCESS: 'Registration successful',
  LOGOUT_SUCCESS: 'Logout successful',
  SETTINGS_UPDATED: 'Settings updated successfully'
};
