import { DefaultTheme, DarkTheme } from 'react-native-paper';

// Light theme
export const lightTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#2E7D32', // Rankolab green
    accent: '#FF6F00', // Orange accent
    background: '#F5F5F5',
    surface: '#FFFFFF',
    text: '#212121',
    error: '#D32F2F',
    notification: '#2196F3',
    success: '#4CAF50',
    warning: '#FFC107',
    info: '#2196F3',
    card: '#FFFFFF',
    border: '#E0E0E0'
  }
};

// Dark theme
export const darkTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    primary: '#4CAF50', // Lighter green for dark theme
    accent: '#FFB74D', // Lighter orange for dark theme
    background: '#121212',
    surface: '#1E1E1E',
    text: '#FFFFFF',
    error: '#EF5350',
    notification: '#42A5F5',
    success: '#66BB6A',
    warning: '#FFCA28',
    info: '#42A5F5',
    card: '#1E1E1E',
    border: '#333333'
  }
};

// Default theme
export const theme = lightTheme;

// Font configuration
export const fonts = {
  regular: {
    fontFamily: 'System',
    fontWeight: 'normal',
  },
  medium: {
    fontFamily: 'System',
    fontWeight: '500',
  },
  light: {
    fontFamily: 'System',
    fontWeight: '300',
  },
  thin: {
    fontFamily: 'System',
    fontWeight: '100',
  },
};

// Spacing constants
export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48
};

// Border radius constants
export const borderRadius = {
  xs: 2,
  sm: 4,
  md: 8,
  lg: 16,
  xl: 24,
  round: 9999
};

// Shadow styles
export const shadows = {
  small: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  large: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 8,
  }
};
