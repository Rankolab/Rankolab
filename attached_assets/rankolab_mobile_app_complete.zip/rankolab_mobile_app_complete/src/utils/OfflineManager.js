import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';

class OfflineManager {
  /**
   * Check if the device is currently online
   * @returns {Promise<boolean>} - True if online, false if offline
   */
  static async isOnline() {
    const netInfo = await NetInfo.fetch();
    return netInfo.isConnected && netInfo.isInternetReachable;
  }

  /**
   * Cache data for offline use
   * @param {string} key - Storage key
   * @param {any} data - Data to cache
   * @param {number} expiryTime - Expiry time in milliseconds (default: 24 hours)
   * @returns {Promise<boolean>} - True if successful, false otherwise
   */
  static async cacheData(key, data, expiryTime = 24 * 60 * 60 * 1000) {
    try {
      const item = {
        data,
        timestamp: Date.now(),
        expiry: Date.now() + expiryTime
      };
      
      await AsyncStorage.setItem(key, JSON.stringify(item));
      return true;
    } catch (error) {
      console.error('Error caching data:', error);
      return false;
    }
  }

  /**
   * Get cached data
   * @param {string} key - Storage key
   * @param {boolean} ignoreExpiry - Whether to ignore expiry time (default: false)
   * @returns {Promise<any>} - Cached data or null if not found or expired
   */
  static async getCachedData(key, ignoreExpiry = false) {
    try {
      const jsonValue = await AsyncStorage.getItem(key);
      
      if (!jsonValue) {
        return null;
      }
      
      const item = JSON.parse(jsonValue);
      
      if (!ignoreExpiry && item.expiry < Date.now()) {
        // Data has expired, remove it
        await AsyncStorage.removeItem(key);
        return null;
      }
      
      return item.data;
    } catch (error) {
      console.error('Error getting cached data:', error);
      return null;
    }
  }

  /**
   * Queue an action for later execution when online
   * @param {string} actionType - Type of action
   * @param {any} actionData - Action data
   * @returns {Promise<boolean>} - True if successful, false otherwise
   */
  static async queueAction(actionType, actionData) {
    try {
      // Get existing queue
      const queueJson = await AsyncStorage.getItem('offline_action_queue');
      const queue = queueJson ? JSON.parse(queueJson) : [];
      
      // Add new action to queue
      queue.push({
        id: Date.now().toString(),
        type: actionType,
        data: actionData,
        timestamp: Date.now()
      });
      
      // Save updated queue
      await AsyncStorage.setItem('offline_action_queue', JSON.stringify(queue));
      return true;
    } catch (error) {
      console.error('Error queuing action:', error);
      return false;
    }
  }

  /**
   * Get all queued actions
   * @returns {Promise<Array>} - Array of queued actions
   */
  static async getQueuedActions() {
    try {
      const queueJson = await AsyncStorage.getItem('offline_action_queue');
      return queueJson ? JSON.parse(queueJson) : [];
    } catch (error) {
      console.error('Error getting queued actions:', error);
      return [];
    }
  }

  /**
   * Remove an action from the queue
   * @param {string} actionId - Action ID
   * @returns {Promise<boolean>} - True if successful, false otherwise
   */
  static async removeQueuedAction(actionId) {
    try {
      // Get existing queue
      const queueJson = await AsyncStorage.getItem('offline_action_queue');
      const queue = queueJson ? JSON.parse(queueJson) : [];
      
      // Remove action from queue
      const updatedQueue = queue.filter(action => action.id !== actionId);
      
      // Save updated queue
      await AsyncStorage.setItem('offline_action_queue', JSON.stringify(updatedQueue));
      return true;
    } catch (error) {
      console.error('Error removing queued action:', error);
      return false;
    }
  }

  /**
   * Clear all queued actions
   * @returns {Promise<boolean>} - True if successful, false otherwise
   */
  static async clearActionQueue() {
    try {
      await AsyncStorage.removeItem('offline_action_queue');
      return true;
    } catch (error) {
      console.error('Error clearing action queue:', error);
      return false;
    }
  }

  /**
   * Sync all queued actions with the server
   * @param {Function} processAction - Function to process each action
   * @returns {Promise<Object>} - Result of sync operation
   */
  static async syncQueuedActions(processAction) {
    try {
      const isConnected = await this.isOnline();
      
      if (!isConnected) {
        return {
          success: false,
          message: 'Device is offline. Cannot sync actions.',
          synced: 0,
          failed: 0,
          remaining: 0
        };
      }
      
      const queue = await this.getQueuedActions();
      
      if (queue.length === 0) {
        return {
          success: true,
          message: 'No actions to sync.',
          synced: 0,
          failed: 0,
          remaining: 0
        };
      }
      
      let synced = 0;
      let failed = 0;
      
      for (const action of queue) {
        try {
          // Process the action
          const result = await processAction(action);
          
          if (result.success) {
            // Remove the action from the queue
            await this.removeQueuedAction(action.id);
            synced++;
          } else {
            failed++;
          }
        } catch (error) {
          console.error('Error processing action:', error);
          failed++;
        }
      }
      
      // Get remaining actions
      const remainingQueue = await this.getQueuedActions();
      
      return {
        success: failed === 0,
        message: `Synced ${synced} actions, failed ${failed} actions.`,
        synced,
        failed,
        remaining: remainingQueue.length
      };
    } catch (error) {
      console.error('Error syncing queued actions:', error);
      return {
        success: false,
        message: error.message || 'An error occurred while syncing actions.',
        synced: 0,
        failed: 0,
        remaining: 0
      };
    }
  }

  /**
   * Initialize offline data
   * This should be called when the app starts or when user logs in
   * @returns {Promise<boolean>} - True if successful, false otherwise
   */
  static async initializeOfflineData() {
    try {
      const isConnected = await this.isOnline();
      
      if (!isConnected) {
        console.log('Device is offline. Using cached data.');
        return false;
      }
      
      // Here you would fetch and cache essential data
      // This is just a placeholder for the actual implementation
      console.log('Initializing offline data...');
      
      return true;
    } catch (error) {
      console.error('Error initializing offline data:', error);
      return false;
    }
  }

  /**
   * Get the timestamp of when data was last synced
   * @param {string} dataType - Type of data
   * @returns {Promise<number|null>} - Timestamp or null if never synced
   */
  static async getLastSyncTimestamp(dataType) {
    try {
      const key = `last_sync_${dataType}`;
      const value = await AsyncStorage.getItem(key);
      return value ? parseInt(value, 10) : null;
    } catch (error) {
      console.error('Error getting last sync timestamp:', error);
      return null;
    }
  }

  /**
   * Update the timestamp of when data was last synced
   * @param {string} dataType - Type of data
   * @returns {Promise<boolean>} - True if successful, false otherwise
   */
  static async updateLastSyncTimestamp(dataType) {
    try {
      const key = `last_sync_${dataType}`;
      await AsyncStorage.setItem(key, Date.now().toString());
      return true;
    } catch (error) {
      console.error('Error updating last sync timestamp:', error);
      return false;
    }
  }
}

export default OfflineManager;
