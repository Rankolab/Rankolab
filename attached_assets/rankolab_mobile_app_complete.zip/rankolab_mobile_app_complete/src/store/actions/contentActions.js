import {
  FETCH_CONTENT_STATS_REQUEST,
  FETCH_CONTENT_STATS_SUCCESS,
  FETCH_CONTENT_STATS_FAILURE,
  FETCH_POSTS_REQUEST,
  FETCH_POSTS_SUCCESS,
  FETCH_POSTS_FAILURE,
  FETCH_POST_DETAILS_REQUEST,
  FETCH_POST_DETAILS_SUCCESS,
  FETCH_POST_DETAILS_FAILURE
} from '../actionTypes';
import ContentService from '../../services/ContentService';

// Fetch content statistics
export const fetchContentStats = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_CONTENT_STATS_REQUEST });
    
    try {
      const response = await ContentService.getContentStats();
      
      if (response.success) {
        dispatch({
          type: FETCH_CONTENT_STATS_SUCCESS,
          payload: response.data
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_CONTENT_STATS_FAILURE,
          payload: response.message || 'Failed to fetch content statistics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_CONTENT_STATS_FAILURE,
        payload: error.message || 'An error occurred while fetching content statistics'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch posts with pagination and filters
export const fetchPosts = (page = 1, perPage = 10, filters = {}) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_POSTS_REQUEST });
    
    try {
      const response = await ContentService.getPosts(page, perPage, filters);
      
      if (response.success) {
        dispatch({
          type: FETCH_POSTS_SUCCESS,
          payload: {
            posts: response.data.posts,
            currentPage: response.data.currentPage,
            totalPages: response.data.totalPages,
            totalItems: response.data.totalItems,
            perPage: response.data.perPage
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_POSTS_FAILURE,
          payload: response.message || 'Failed to fetch posts'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_POSTS_FAILURE,
        payload: error.message || 'An error occurred while fetching posts'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch post details
export const fetchPostDetails = (postId) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_POST_DETAILS_REQUEST });
    
    try {
      const response = await ContentService.getPostDetails(postId);
      
      if (response.success) {
        dispatch({
          type: FETCH_POST_DETAILS_SUCCESS,
          payload: response.data
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_POST_DETAILS_FAILURE,
          payload: response.message || 'Failed to fetch post details'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_POST_DETAILS_FAILURE,
        payload: error.message || 'An error occurred while fetching post details'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Create new post
export const createPost = (postData) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_POSTS_REQUEST });
    
    try {
      const response = await ContentService.createPost(postData);
      
      if (response.success) {
        // Refresh posts list after creating a new post
        dispatch(fetchPosts());
        
        return response;
      } else {
        dispatch({
          type: FETCH_POSTS_FAILURE,
          payload: response.message || 'Failed to create post'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_POSTS_FAILURE,
        payload: error.message || 'An error occurred while creating post'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Update existing post
export const updatePost = (postId, postData) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_POSTS_REQUEST });
    
    try {
      const response = await ContentService.updatePost(postId, postData);
      
      if (response.success) {
        // Refresh posts list after updating a post
        dispatch(fetchPosts());
        
        return response;
      } else {
        dispatch({
          type: FETCH_POSTS_FAILURE,
          payload: response.message || 'Failed to update post'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_POSTS_FAILURE,
        payload: error.message || 'An error occurred while updating post'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Delete post
export const deletePost = (postId) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_POSTS_REQUEST });
    
    try {
      const response = await ContentService.deletePost(postId);
      
      if (response.success) {
        // Refresh posts list after deleting a post
        dispatch(fetchPosts());
        
        return response;
      } else {
        dispatch({
          type: FETCH_POSTS_FAILURE,
          payload: response.message || 'Failed to delete post'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_POSTS_FAILURE,
        payload: error.message || 'An error occurred while deleting post'
      });
      
      return { success: false, message: error.message };
    }
  };
};
