import {
  FETCH_DASHBOARD_REQUEST,
  FETCH_DASHBOARD_SUCCESS,
  FETCH_DASHBOARD_FAILURE
} from '../actionTypes';
import DashboardService from '../../services/DashboardService';

// Fetch dashboard data
export const fetchDashboardData = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_DASHBOARD_REQUEST });
    
    try {
      const response = await DashboardService.getDashboardData();
      
      if (response.success) {
        dispatch({
          type: FETCH_DASHBOARD_SUCCESS,
          payload: response.data
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_DASHBOARD_FAILURE,
          payload: response.message || 'Failed to fetch dashboard data'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_DASHBOARD_FAILURE,
        payload: error.message || 'An error occurred while fetching dashboard data'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch traffic data for specific date range
export const fetchTrafficData = (startDate, endDate) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_DASHBOARD_REQUEST });
    
    try {
      const response = await DashboardService.getTrafficData(startDate, endDate);
      
      if (response.success) {
        // Update only the traffic part of the dashboard data
        dispatch({
          type: FETCH_DASHBOARD_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_DASHBOARD_FAILURE,
          payload: response.message || 'Failed to fetch traffic data'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_DASHBOARD_FAILURE,
        payload: error.message || 'An error occurred while fetching traffic data'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch SEO data
export const fetchSeoData = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_DASHBOARD_REQUEST });
    
    try {
      const response = await DashboardService.getSeoData();
      
      if (response.success) {
        // Update only the SEO part of the dashboard data
        dispatch({
          type: FETCH_DASHBOARD_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_DASHBOARD_FAILURE,
          payload: response.message || 'Failed to fetch SEO data'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_DASHBOARD_FAILURE,
        payload: error.message || 'An error occurred while fetching SEO data'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch content statistics
export const fetchContentStats = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_DASHBOARD_REQUEST });
    
    try {
      const response = await DashboardService.getContentStats();
      
      if (response.success) {
        // Update only the content part of the dashboard data
        dispatch({
          type: FETCH_DASHBOARD_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_DASHBOARD_FAILURE,
          payload: response.message || 'Failed to fetch content statistics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_DASHBOARD_FAILURE,
        payload: error.message || 'An error occurred while fetching content statistics'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch performance metrics
export const fetchPerformanceMetrics = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_DASHBOARD_REQUEST });
    
    try {
      const response = await DashboardService.getPerformanceMetrics();
      
      if (response.success) {
        // Update only the performance part of the dashboard data
        dispatch({
          type: FETCH_DASHBOARD_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_DASHBOARD_FAILURE,
          payload: response.message || 'Failed to fetch performance metrics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_DASHBOARD_FAILURE,
        payload: error.message || 'An error occurred while fetching performance metrics'
      });
      
      return { success: false, message: error.message };
    }
  };
};
