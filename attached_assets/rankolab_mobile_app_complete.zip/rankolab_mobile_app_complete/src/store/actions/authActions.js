import {
  LOGIN_REQUEST,
  LOGIN_SUCCESS,
  LOGIN_FAILURE,
  LOGOUT,
  REGISTER_REQUEST,
  REGISTER_SUCCESS,
  REGISTER_FAILURE,
  RESET_AUTH_ERROR
} from '../actionTypes';
import AuthService from '../../services/AuthService';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Login action
export const login = (username, password) => {
  return async (dispatch) => {
    dispatch({ type: LOGIN_REQUEST });
    
    try {
      const response = await AuthService.login(username, password);
      
      if (response.success) {
        // Store token in AsyncStorage for persistence
        await AsyncStorage.setItem('token', response.token);
        await AsyncStorage.setItem('user', JSON.stringify(response.user));
        
        dispatch({
          type: LOGIN_SUCCESS,
          payload: {
            user: response.user,
            token: response.token
          }
        });
        
        return response;
      } else {
        dispatch({
          type: LOGIN_FAILURE,
          payload: response.message || 'Login failed'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: LOGIN_FAILURE,
        payload: error.message || 'An error occurred during login'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Register action
export const register = (username, email, password) => {
  return async (dispatch) => {
    dispatch({ type: REGISTER_REQUEST });
    
    try {
      const response = await AuthService.register(username, email, password);
      
      if (response.success) {
        // Store token in AsyncStorage for persistence
        await AsyncStorage.setItem('token', response.token);
        await AsyncStorage.setItem('user', JSON.stringify(response.user));
        
        dispatch({
          type: REGISTER_SUCCESS,
          payload: {
            user: response.user,
            token: response.token
          }
        });
        
        return response;
      } else {
        dispatch({
          type: REGISTER_FAILURE,
          payload: response.message || 'Registration failed'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: REGISTER_FAILURE,
        payload: error.message || 'An error occurred during registration'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Logout action
export const logout = () => {
  return async (dispatch) => {
    // Remove token and user from AsyncStorage
    await AsyncStorage.removeItem('token');
    await AsyncStorage.removeItem('user');
    
    dispatch({ type: LOGOUT });
  };
};

// Check if user is already logged in
export const checkAuthState = () => {
  return async (dispatch) => {
    try {
      const token = await AsyncStorage.getItem('token');
      const userString = await AsyncStorage.getItem('user');
      
      if (token && userString) {
        const user = JSON.parse(userString);
        
        // Validate token with the server
        const isValid = await AuthService.validateToken(token);
        
        if (isValid.success) {
          dispatch({
            type: LOGIN_SUCCESS,
            payload: {
              user,
              token
            }
          });
        } else {
          // Token is invalid, logout
          dispatch(logout());
        }
      }
    } catch (error) {
      console.error('Error checking auth state:', error);
      dispatch(logout());
    }
  };
};

// Reset auth error
export const resetAuthError = () => {
  return {
    type: RESET_AUTH_ERROR
  };
};
