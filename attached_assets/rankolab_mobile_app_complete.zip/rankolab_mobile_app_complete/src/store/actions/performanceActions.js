import {
  FETCH_PERFORMANCE_METRICS_REQUEST,
  FETCH_PERFORMANCE_METRICS_SUCCESS,
  FETCH_PERFORMANCE_METRICS_FAILURE
} from '../actionTypes';
import PerformanceService from '../../services/PerformanceService';

// Fetch performance metrics
export const fetchPerformanceMetrics = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_PERFORMANCE_METRICS_REQUEST });
    
    try {
      const response = await PerformanceService.getPerformanceMetrics();
      
      if (response.success) {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_SUCCESS,
          payload: response.data
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_FAILURE,
          payload: response.message || 'Failed to fetch performance metrics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_PERFORMANCE_METRICS_FAILURE,
        payload: error.message || 'An error occurred while fetching performance metrics'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch traffic metrics
export const fetchTrafficMetrics = (period = 'month') => {
  return async (dispatch) => {
    dispatch({ type: FETCH_PERFORMANCE_METRICS_REQUEST });
    
    try {
      const response = await PerformanceService.getTrafficMetrics(period);
      
      if (response.success) {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_FAILURE,
          payload: response.message || 'Failed to fetch traffic metrics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_PERFORMANCE_METRICS_FAILURE,
        payload: error.message || 'An error occurred while fetching traffic metrics'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch SEO metrics
export const fetchSeoMetrics = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_PERFORMANCE_METRICS_REQUEST });
    
    try {
      const response = await PerformanceService.getSeoMetrics();
      
      if (response.success) {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_FAILURE,
          payload: response.message || 'Failed to fetch SEO metrics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_PERFORMANCE_METRICS_FAILURE,
        payload: error.message || 'An error occurred while fetching SEO metrics'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch keyword rankings
export const fetchKeywordRankings = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_PERFORMANCE_METRICS_REQUEST });
    
    try {
      const response = await PerformanceService.getKeywordRankings();
      
      if (response.success) {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_FAILURE,
          payload: response.message || 'Failed to fetch keyword rankings'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_PERFORMANCE_METRICS_FAILURE,
        payload: error.message || 'An error occurred while fetching keyword rankings'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Fetch page speed metrics
export const fetchPageSpeedMetrics = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_PERFORMANCE_METRICS_REQUEST });
    
    try {
      const response = await PerformanceService.getPageSpeedMetrics();
      
      if (response.success) {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_SUCCESS,
          payload: {
            ...response.data
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_PERFORMANCE_METRICS_FAILURE,
          payload: response.message || 'Failed to fetch page speed metrics'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_PERFORMANCE_METRICS_FAILURE,
        payload: error.message || 'An error occurred while fetching page speed metrics'
      });
      
      return { success: false, message: error.message };
    }
  };
};
