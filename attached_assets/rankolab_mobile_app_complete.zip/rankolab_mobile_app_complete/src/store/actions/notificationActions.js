import {
  FETCH_NOTIFICATIONS_REQUEST,
  FETCH_NOTIFICATIONS_SUCCESS,
  FETCH_NOTIFICATIONS_FAILURE,
  MARK_NOTIFICATION_READ,
  REGISTER_DEVICE_REQUEST,
  REGISTER_DEVICE_SUCCESS,
  REGISTER_DEVICE_FAILURE
} from '../actionTypes';
import NotificationService from '../../services/NotificationService';

// Fetch notifications
export const fetchNotifications = (page = 1, perPage = 20) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_NOTIFICATIONS_REQUEST });
    
    try {
      const response = await NotificationService.getNotifications(page, perPage);
      
      if (response.success) {
        dispatch({
          type: FETCH_NOTIFICATIONS_SUCCESS,
          payload: {
            notifications: response.data.notifications,
            currentPage: response.data.currentPage,
            totalPages: response.data.totalPages,
            totalItems: response.data.totalItems,
            perPage: response.data.perPage
          }
        });
        
        return response;
      } else {
        dispatch({
          type: FETCH_NOTIFICATIONS_FAILURE,
          payload: response.message || 'Failed to fetch notifications'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: FETCH_NOTIFICATIONS_FAILURE,
        payload: error.message || 'An error occurred while fetching notifications'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Mark notification as read
export const markNotificationAsRead = (notificationId) => {
  return async (dispatch) => {
    try {
      const response = await NotificationService.markAsRead(notificationId);
      
      if (response.success) {
        dispatch({
          type: MARK_NOTIFICATION_READ,
          payload: notificationId
        });
        
        return response;
      } else {
        return response;
      }
    } catch (error) {
      return { success: false, message: error.message };
    }
  };
};

// Mark all notifications as read
export const markAllNotificationsAsRead = () => {
  return async (dispatch, getState) => {
    try {
      const response = await NotificationService.markAllAsRead();
      
      if (response.success) {
        // Re-fetch notifications to get updated list
        dispatch(fetchNotifications());
        
        return response;
      } else {
        return response;
      }
    } catch (error) {
      return { success: false, message: error.message };
    }
  };
};

// Register device for push notifications
export const registerDevice = (deviceToken, deviceType) => {
  return async (dispatch) => {
    dispatch({ type: REGISTER_DEVICE_REQUEST });
    
    try {
      const response = await NotificationService.registerDevice(deviceToken, deviceType);
      
      if (response.success) {
        dispatch({
          type: REGISTER_DEVICE_SUCCESS,
          payload: {
            deviceToken
          }
        });
        
        return response;
      } else {
        dispatch({
          type: REGISTER_DEVICE_FAILURE,
          payload: response.message || 'Failed to register device'
        });
        
        return response;
      }
    } catch (error) {
      dispatch({
        type: REGISTER_DEVICE_FAILURE,
        payload: error.message || 'An error occurred while registering device'
      });
      
      return { success: false, message: error.message };
    }
  };
};

// Update notification preferences
export const updateNotificationPreferences = (preferences) => {
  return async (dispatch) => {
    try {
      const response = await NotificationService.updatePreferences(preferences);
      
      if (response.success) {
        // No need to update state here as this affects server-side settings
        return response;
      } else {
        return response;
      }
    } catch (error) {
      return { success: false, message: error.message };
    }
  };
};
