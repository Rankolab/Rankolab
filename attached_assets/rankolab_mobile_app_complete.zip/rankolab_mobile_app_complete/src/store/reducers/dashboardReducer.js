import { 
  FETCH_DASHBOARD_REQUEST, 
  FETCH_DASHBOARD_SUCCESS, 
  FETCH_DASHBOARD_FAILURE 
} from '../actionTypes';

const initialState = {
  data: {
    traffic: {
      visitors: 0,
      pageViews: 0,
      bounceRate: 0,
      averageSessionDuration: 0
    },
    seo: {
      score: 0,
      keywordsRanked: 0,
      backlinks: 0
    },
    content: {
      totalPosts: 0,
      publishedPosts: 0,
      draftPosts: 0,
      categories: 0
    },
    performance: {
      loadTime: 0,
      serverResponse: 0,
      pageSize: 0
    },
    trafficTrend: [],
    keywordRankings: [],
    contentDistribution: []
  },
  isLoading: false,
  error: null,
  lastUpdated: null
};

const dashboardReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_DASHBOARD_REQUEST:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case FETCH_DASHBOARD_SUCCESS:
      return {
        ...state,
        isLoading: false,
        data: action.payload,
        lastUpdated: new Date().toISOString(),
        error: null
      };
    case FETCH_DASHBOARD_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    default:
      return state;
  }
};

export default dashboardReducer;
