import {
  FETCH_CONTENT_STATS_REQUEST,
  FETCH_CONTENT_STATS_SUCCESS,
  FETCH_CONTENT_STATS_FAILURE,
  FETCH_POSTS_REQUEST,
  FETCH_POSTS_SUCCESS,
  FETCH_POSTS_FAILURE,
  FETCH_POST_DETAILS_REQUEST,
  FETCH_POST_DETAILS_SUCCESS,
  FETCH_POST_DETAILS_FAILURE
} from '../actionTypes';

const initialState = {
  stats: {
    totalPosts: 0,
    publishedPosts: 0,
    draftPosts: 0,
    categories: 0,
    tags: 0,
    authors: 0
  },
  posts: [],
  currentPost: null,
  isLoadingStats: false,
  isLoadingPosts: false,
  isLoadingPostDetails: false,
  error: null,
  lastUpdated: null,
  pagination: {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    perPage: 10
  }
};

const contentReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_CONTENT_STATS_REQUEST:
      return {
        ...state,
        isLoadingStats: true,
        error: null
      };
    case FETCH_CONTENT_STATS_SUCCESS:
      return {
        ...state,
        isLoadingStats: false,
        stats: action.payload,
        lastUpdated: new Date().toISOString(),
        error: null
      };
    case FETCH_CONTENT_STATS_FAILURE:
      return {
        ...state,
        isLoadingStats: false,
        error: action.payload
      };
    case FETCH_POSTS_REQUEST:
      return {
        ...state,
        isLoadingPosts: true,
        error: null
      };
    case FETCH_POSTS_SUCCESS:
      return {
        ...state,
        isLoadingPosts: false,
        posts: action.payload.posts,
        pagination: {
          currentPage: action.payload.currentPage,
          totalPages: action.payload.totalPages,
          totalItems: action.payload.totalItems,
          perPage: action.payload.perPage
        },
        lastUpdated: new Date().toISOString(),
        error: null
      };
    case FETCH_POSTS_FAILURE:
      return {
        ...state,
        isLoadingPosts: false,
        error: action.payload
      };
    case FETCH_POST_DETAILS_REQUEST:
      return {
        ...state,
        isLoadingPostDetails: true,
        error: null
      };
    case FETCH_POST_DETAILS_SUCCESS:
      return {
        ...state,
        isLoadingPostDetails: false,
        currentPost: action.payload,
        error: null
      };
    case FETCH_POST_DETAILS_FAILURE:
      return {
        ...state,
        isLoadingPostDetails: false,
        error: action.payload
      };
    default:
      return state;
  }
};

export default contentReducer;
