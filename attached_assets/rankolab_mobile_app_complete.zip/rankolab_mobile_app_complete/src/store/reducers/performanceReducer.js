import {
  FETCH_PERFORMANCE_METRICS_REQUEST,
  FETCH_PERFORMANCE_METRICS_SUCCESS,
  FETCH_PERFORMANCE_METRICS_FAILURE
} from '../actionTypes';

const initialState = {
  metrics: {
    seo: {
      score: 0,
      keywordsRanked: 0,
      backlinks: 0,
      organicTraffic: 0
    },
    speed: {
      loadTime: 0,
      serverResponse: 0,
      pageSize: 0,
      score: 0
    },
    traffic: {
      visitors: {
        current: 0,
        previous: 0,
        change: 0
      },
      pageViews: {
        current: 0,
        previous: 0,
        change: 0
      },
      bounceRate: {
        current: 0,
        previous: 0,
        change: 0
      },
      averageSessionDuration: {
        current: 0,
        previous: 0,
        change: 0
      }
    },
    keywords: [],
    trafficTrend: [],
    keywordPositions: []
  },
  isLoading: false,
  error: null,
  lastUpdated: null
};

const performanceReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_PERFORMANCE_METRICS_REQUEST:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case FETCH_PERFORMANCE_METRICS_SUCCESS:
      return {
        ...state,
        isLoading: false,
        metrics: action.payload,
        lastUpdated: new Date().toISOString(),
        error: null
      };
    case FETCH_PERFORMANCE_METRICS_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    default:
      return state;
  }
};

export default performanceReducer;
