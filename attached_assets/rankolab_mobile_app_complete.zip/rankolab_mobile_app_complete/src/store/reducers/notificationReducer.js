import {
  FETCH_NOTIFICATIONS_REQUEST,
  FETCH_NOTIFICATIONS_SUCCESS,
  FETCH_NOTIFICATIONS_FAILURE,
  MARK_NOTIFICATION_READ,
  REGISTER_DEVICE_REQUEST,
  REGISTER_DEVICE_SUCCESS,
  REGISTER_DEVICE_FAILURE
} from '../actionTypes';

const initialState = {
  notifications: [],
  isLoading: false,
  error: null,
  lastUpdated: null,
  deviceRegistered: false,
  deviceToken: null,
  pagination: {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    perPage: 20
  }
};

const notificationReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_NOTIFICATIONS_REQUEST:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case FETCH_NOTIFICATIONS_SUCCESS:
      return {
        ...state,
        isLoading: false,
        notifications: action.payload.notifications,
        pagination: {
          currentPage: action.payload.currentPage,
          totalPages: action.payload.totalPages,
          totalItems: action.payload.totalItems,
          perPage: action.payload.perPage
        },
        lastUpdated: new Date().toISOString(),
        error: null
      };
    case FETCH_NOTIFICATIONS_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    case MARK_NOTIFICATION_READ:
      return {
        ...state,
        notifications: state.notifications.map(notification =>
          notification.id === action.payload
            ? { ...notification, read: true }
            : notification
        )
      };
    case REGISTER_DEVICE_REQUEST:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case REGISTER_DEVICE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        deviceRegistered: true,
        deviceToken: action.payload.deviceToken,
        error: null
      };
    case REGISTER_DEVICE_FAILURE:
      return {
        ...state,
        isLoading: false,
        deviceRegistered: false,
        error: action.payload
      };
    default:
      return state;
  }
};

export default notificationReducer;
