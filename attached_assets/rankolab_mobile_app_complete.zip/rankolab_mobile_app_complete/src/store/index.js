import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import authReducer from './reducers/authReducer';
import dashboardReducer from './reducers/dashboardReducer';
import contentReducer from './reducers/contentReducer';
import notificationReducer from './reducers/notificationReducer';
import settingsReducer from './reducers/settingsReducer';

const rootReducer = combineReducers({
  auth: authReducer,
  dashboard: dashboardReducer,
  content: contentReducer,
  notifications: notificationReducer,
  settings: settingsReducer
});

const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;
