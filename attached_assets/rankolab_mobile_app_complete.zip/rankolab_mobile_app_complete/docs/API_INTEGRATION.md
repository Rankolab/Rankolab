# API Integration Guide

This document provides detailed information about integrating the Rankolab Mobile App with the Rankolab backend API.

## API Overview

The Rankolab Mobile App communicates with two main API endpoints:

1. **WordPress Plugin API** (`/rankolab/v1/` endpoints)
2. **Backend Website API** (`/api/v1/` endpoints)

All API requests require authentication using JWT tokens, which are obtained during the login process.

## Authentication

### Obtaining a Token

To authenticate with the API, you need to obtain a JWT token by sending a login request:

```javascript
// Example using Axios
import axios from 'axios';

const login = async (username, password) => {
  try {
    const response = await axios.post('https://api.rankolab.com/rankolab/v1/auth/login', {
      username,
      password
    });
    
    if (response.data.success) {
      // Store the token for future requests
      const token = response.data.token;
      return { success: true, token };
    } else {
      return { success: false, message: response.data.message };
    }
  } catch (error) {
    return { success: false, message: error.message };
  }
};
```

### Using the Token

Once you have a token, include it in the `Authorization` header of all subsequent requests:

```javascript
// Example using Axios
import axios from 'axios';

const fetchData = async (token) => {
  try {
    const response = await axios.get('https://api.rankolab.com/rankolab/v1/dashboard', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    
    return response.data;
  } catch (error) {
    return { success: false, message: error.message };
  }
};
```

### Token Validation

To validate a token, use the validate endpoint:

```javascript
// Example using Axios
import axios from 'axios';

const validateToken = async (token) => {
  try {
    const response = await axios.post('https://api.rankolab.com/rankolab/v1/auth/validate', {
      token
    });
    
    return response.data;
  } catch (error) {
    return { success: false, message: error.message };
  }
};
```

## API Endpoints

### Authentication Endpoints

| Endpoint | Method | Description | Request Body | Response |
|----------|--------|-------------|--------------|----------|
| `/rankolab/v1/auth/login` | POST | User login | `{ username, password }` | `{ success, token, user }` |
| `/rankolab/v1/auth/register` | POST | User registration | `{ username, email, password }` | `{ success, token, user }` |
| `/rankolab/v1/auth/validate` | POST | Token validation | `{ token }` | `{ success, valid }` |

### Dashboard Endpoints

| Endpoint | Method | Description | Query Parameters | Response |
|----------|--------|-------------|-----------------|----------|
| `/rankolab/v1/dashboard` | GET | Get dashboard data | None | `{ success, data }` |
| `/rankolab/v1/performance` | GET | Get performance metrics | `start_date, end_date` | `{ success, data }` |
| `/rankolab/v1/seo` | GET | Get SEO metrics | None | `{ success, data }` |

### Content Endpoints

| Endpoint | Method | Description | Query/Body Parameters | Response |
|----------|--------|-------------|----------------------|----------|
| `/rankolab/v1/content/stats` | GET | Get content statistics | None | `{ success, data }` |
| `/rankolab/v1/content/posts` | GET | List posts | `page, per_page, status, search` | `{ success, data, pagination }` |
| `/rankolab/v1/content/posts/{id}` | GET | Get post details | `id` (path) | `{ success, data }` |
| `/rankolab/v1/content/posts` | POST | Create post | Post data | `{ success, data }` |
| `/rankolab/v1/content/posts/{id}` | PUT | Update post | `id` (path), Post data | `{ success, data }` |
| `/rankolab/v1/content/posts/{id}` | DELETE | Delete post | `id` (path) | `{ success, message }` |

### Performance Endpoints

| Endpoint | Method | Description | Query Parameters | Response |
|----------|--------|-------------|-----------------|----------|
| `/rankolab/v1/performance/metrics` | GET | Get all performance metrics | None | `{ success, data }` |
| `/rankolab/v1/performance/traffic` | GET | Get traffic metrics | `period` | `{ success, data }` |
| `/rankolab/v1/performance/seo` | GET | Get SEO metrics | None | `{ success, data }` |
| `/rankolab/v1/performance/keywords` | GET | Get keyword rankings | None | `{ success, data }` |
| `/rankolab/v1/performance/speed` | GET | Get page speed metrics | None | `{ success, data }` |

### Notification Endpoints

| Endpoint | Method | Description | Query/Body Parameters | Response |
|----------|--------|-------------|----------------------|----------|
| `/rankolab/v1/notifications` | GET | Get notifications | `page, per_page` | `{ success, data, pagination }` |
| `/rankolab/v1/notifications/{id}/read` | PUT | Mark notification as read | `id` (path) | `{ success, message }` |
| `/rankolab/v1/notifications/read-all` | PUT | Mark all notifications as read | None | `{ success, message }` |
| `/rankolab/v1/notifications/register-device` | POST | Register device for push notifications | `{ device_token, device_type }` | `{ success, message }` |
| `/rankolab/v1/notifications/preferences` | PUT | Update notification preferences | Preference data | `{ success, data }` |

## Data Models

### User Model

```javascript
{
  id: number,
  username: string,
  email: string,
  displayName: string,
  avatar: string,
  role: string,
  createdAt: string,
  updatedAt: string
}
```

### Dashboard Data Model

```javascript
{
  traffic: {
    visitors: number,
    pageViews: number,
    bounceRate: number,
    averageSessionDuration: number,
    trend: number[]
  },
  seo: {
    score: number,
    keywordsRanked: number,
    backlinks: number,
    keywordRankings: number[]
  },
  content: {
    totalPosts: number,
    publishedPosts: number,
    draftPosts: number,
    categories: number
  },
  performance: {
    loadTime: number,
    serverResponse: number,
    pageSize: number
  }
}
```

### Post Model

```javascript
{
  id: number,
  title: string,
  excerpt: string,
  content: string,
  date: string,
  modified: string,
  author: string,
  featuredImage: string,
  categories: string[],
  tags: string[],
  status: string,
  featured: boolean,
  commentCount: number,
  permalink: string
}
```

### Performance Metrics Model

```javascript
{
  seo: {
    score: number,
    keywordsRanked: number,
    backlinks: number,
    organicTraffic: number
  },
  speed: {
    loadTime: number,
    serverResponse: number,
    pageSize: number,
    score: number
  },
  traffic: {
    visitors: {
      current: number,
      previous: number,
      change: number
    },
    pageViews: {
      current: number,
      previous: number,
      change: number
    },
    bounceRate: {
      current: number,
      previous: number,
      change: number
    },
    averageSessionDuration: {
      current: number,
      previous: number,
      change: number
    },
    trend: number[]
  },
  keywords: [
    {
      keyword: string,
      position: number,
      volume: number,
      change: number
    }
  ],
  keywordPositions: number[]
}
```

### Notification Model

```javascript
{
  id: number,
  title: string,
  message: string,
  date: string,
  type: string,
  read: boolean,
  priority: string,
  data: object
}
```

## Error Handling

The API returns standardized error responses with the following structure:

```javascript
{
  success: false,
  message: string,
  errors: object // Optional, contains field-specific errors
}
```

Common error scenarios:

1. **Authentication Errors**:
   - 401 Unauthorized: Invalid or expired token
   - 403 Forbidden: Insufficient permissions

2. **Validation Errors**:
   - 400 Bad Request: Invalid input data

3. **Resource Errors**:
   - 404 Not Found: Resource not found
   - 409 Conflict: Resource already exists

4. **Server Errors**:
   - 500 Internal Server Error: Unexpected server error

Example error handling:

```javascript
try {
  const response = await api.get('/endpoint');
  // Handle success
} catch (error) {
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    const { status, data } = error.response;
    
    if (status === 401) {
      // Handle authentication error
    } else if (status === 400) {
      // Handle validation error
    } else if (status === 404) {
      // Handle not found error
    } else {
      // Handle other errors
    }
  } else if (error.request) {
    // The request was made but no response was received
    // Handle network error
  } else {
    // Something happened in setting up the request that triggered an Error
    // Handle unexpected error
  }
}
```

## Rate Limiting

The API implements rate limiting to prevent abuse. The current limits are:

- 100 requests per minute for authenticated users
- 20 requests per minute for unauthenticated users

Rate limit information is included in the response headers:

- `X-RateLimit-Limit`: Maximum number of requests allowed per minute
- `X-RateLimit-Remaining`: Number of requests remaining in the current window
- `X-RateLimit-Reset`: Time (in seconds) until the rate limit resets

If you exceed the rate limit, you'll receive a 429 Too Many Requests response.

## Pagination

Endpoints that return lists of items support pagination using the following query parameters:

- `page`: Page number (default: 1)
- `per_page`: Number of items per page (default varies by endpoint)

Pagination information is included in the response:

```javascript
{
  success: true,
  data: [...],
  pagination: {
    currentPage: number,
    totalPages: number,
    totalItems: number,
    perPage: number
  }
}
```

## Offline Support

For offline support, consider implementing the following strategies:

1. **Cache API responses** using AsyncStorage or another storage solution
2. **Queue API requests** made while offline and sync when online
3. **Implement optimistic UI updates** to provide immediate feedback

Example offline queue implementation:

```javascript
const queueAction = async (action) => {
  try {
    // Get existing queue
    const queueJson = await AsyncStorage.getItem('offline_action_queue');
    const queue = queueJson ? JSON.parse(queueJson) : [];
    
    // Add new action to queue
    queue.push({
      id: Date.now().toString(),
      ...action,
      timestamp: Date.now()
    });
    
    // Save updated queue
    await AsyncStorage.setItem('offline_action_queue', JSON.stringify(queue));
    return true;
  } catch (error) {
    console.error('Error queuing action:', error);
    return false;
  }
};

const syncQueuedActions = async () => {
  try {
    // Get queued actions
    const queueJson = await AsyncStorage.getItem('offline_action_queue');
    const queue = queueJson ? JSON.parse(queueJson) : [];
    
    if (queue.length === 0) {
      return { success: true, message: 'No actions to sync' };
    }
    
    // Process each action
    for (const action of queue) {
      try {
        // Process the action based on its type
        switch (action.type) {
          case 'mark_notification_read':
            await api.put(`/notifications/${action.data.id}/read`);
            break;
          case 'update_post':
            await api.put(`/content/posts/${action.data.id}`, action.data);
            break;
          // Add other action types as needed
        }
        
        // Remove the action from the queue
        const updatedQueue = queue.filter(a => a.id !== action.id);
        await AsyncStorage.setItem('offline_action_queue', JSON.stringify(updatedQueue));
      } catch (error) {
        console.error('Error processing action:', error);
      }
    }
    
    return { success: true, message: 'Actions synced successfully' };
  } catch (error) {
    console.error('Error syncing actions:', error);
    return { success: false, message: error.message };
  }
};
```

## Security Best Practices

1. **Never store sensitive information** (like passwords) in plain text
2. **Securely store tokens** using AsyncStorage or a more secure alternative
3. **Implement token refresh** to handle token expiration
4. **Validate all user inputs** before sending to the API
5. **Implement certificate pinning** to prevent man-in-the-middle attacks

## API Versioning

The API uses versioning in the URL path (e.g., `/v1/`). When a new version is released, both versions will be supported for a transition period.

## Support

For API support, please contact:

- Email: api-support@rankolab.com
- Documentation: https://api.rankolab.com/docs
- Status: https://status.rankolab.com
