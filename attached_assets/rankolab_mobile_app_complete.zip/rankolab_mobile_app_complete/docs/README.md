# Rankolab Mobile App Documentation

## Overview

The Rankolab Mobile App is a companion application for the Rankolab WordPress plugin system. It provides users with on-the-go access to their website performance metrics, content management capabilities, and notifications. This document provides comprehensive information about the app's installation, usage, and integration with the Rankolab backend systems.

## Table of Contents

1. [Installation](#installation)
2. [Features](#features)
3. [Architecture](#architecture)
4. [Authentication](#authentication)
5. [Dashboard](#dashboard)
6. [Content Management](#content-management)
7. [Performance Tracking](#performance-tracking)
8. [Notifications](#notifications)
9. [Offline Capabilities](#offline-capabilities)
10. [API Integration](#api-integration)
11. [Troubleshooting](#troubleshooting)

## Installation

### Prerequisites

- Node.js (v16 or higher)
- npm (v8 or higher)
- React Native CLI
- Android Studio (for Android development)
- Xcode (for iOS development)

### Development Setup

1. Clone the repository:
   ```
   git clone https://github.com/rankolab/mobile-app.git
   cd rankolab_mobile_app
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Configure environment variables:
   - Create a `.env` file in the project root
   - Add the following variables:
     ```
     API_BASE_URL=https://api.rankolab.com
     ```

4. Run the app:
   - For Android:
     ```
     npx react-native run-android
     ```
   - For iOS:
     ```
     npx react-native run-ios
     ```

### Production Build

#### Android

1. Generate a signed APK:
   ```
   cd android
   ./gradlew assembleRelease
   ```

2. The APK will be available at:
   ```
   android/app/build/outputs/apk/release/app-release.apk
   ```

#### iOS

1. Open the project in Xcode:
   ```
   open ios/RankolabMobileApp.xcworkspace
   ```

2. Select "Product" > "Archive" from the menu
3. Follow the prompts to distribute the app

## Features

The Rankolab Mobile App includes the following key features:

### Authentication System
- User registration
- User login
- Password recovery
- Token management
- Biometric authentication (fingerprint/face ID)

### Dashboard
- Overview of key metrics
- Interactive charts for data visualization
- Customizable widgets
- Data refresh controls

### Content Management
- View published content
- Content statistics
- Draft management
- Basic content editing

### Performance Tracking
- Traffic analytics
- SEO performance metrics
- Content performance
- Conversion tracking

### Notification System
- Push notifications for important events
- Notification preferences
- Notification history
- Action-based notifications

### Offline Mode
- Data caching for offline access
- Offline actions queue
- Sync mechanism when online

### User Settings
- Profile management
- Notification preferences
- Theme settings (light/dark mode)
- App preferences

## Architecture

The Rankolab Mobile App follows a modular architecture with the following key components:

### Directory Structure

```
rankolab_mobile_app/
├── src/
│   ├── assets/         # Images, fonts, and other static assets
│   ├── components/     # Reusable UI components
│   ├── navigation/     # Navigation configuration
│   ├── screens/        # Screen components
│   ├── services/       # API services
│   ├── store/          # Redux store configuration
│   │   ├── actions/    # Redux actions
│   │   └── reducers/   # Redux reducers
│   └── utils/          # Utility functions and constants
├── App.js              # Main application component
└── index.js            # Entry point
```

### Technology Stack

- **Framework**: React Native for cross-platform development
- **State Management**: Redux for app state management
- **Navigation**: React Navigation for screen navigation
- **UI Components**: React Native Paper for consistent UI
- **Charts**: React Native Chart Kit for interactive charts
- **API Communication**: Axios for HTTP requests
- **Storage**: AsyncStorage for local data persistence
- **Authentication**: JWT tokens for secure authentication
- **Push Notifications**: Firebase Cloud Messaging

## Authentication

The authentication system uses JWT tokens for secure API access. The flow is as follows:

1. User enters credentials (username/password)
2. App sends credentials to the API
3. API validates credentials and returns a JWT token
4. App stores the token in AsyncStorage
5. Token is included in the header of all subsequent API requests
6. Token is validated on each app start
7. If token is expired, user is redirected to login

### Code Example

```javascript
// Login function
const login = async (username, password) => {
  try {
    const response = await AuthService.login(username, password);
    
    if (response.success) {
      // Store token in AsyncStorage
      await AsyncStorage.setItem('token', response.token);
      await AsyncStorage.setItem('user', JSON.stringify(response.user));
      
      // Set token for API requests
      AuthService.setAuthToken(response.token);
      
      return { success: true };
    } else {
      return { success: false, message: response.message };
    }
  } catch (error) {
    return { success: false, message: error.message };
  }
};
```

## Dashboard

The dashboard provides a comprehensive overview of website performance metrics. It includes:

- Traffic statistics (visitors, page views, bounce rate)
- SEO performance (score, keywords ranked, backlinks)
- Content statistics (total posts, published, drafts)
- Performance metrics (load time, server response, page size)

The dashboard data is fetched from the API and displayed using interactive charts and widgets. The data is automatically refreshed at regular intervals and can be manually refreshed by the user.

### Key Components

- **Overview Cards**: Display key metrics at a glance
- **Traffic Chart**: Shows visitor trends over time
- **SEO Stats**: Displays SEO performance metrics
- **Keyword Rankings**: Shows keyword position distribution
- **Content Distribution**: Visualizes content status
- **Performance Metrics**: Displays website speed metrics
- **Quick Actions**: Provides shortcuts to common tasks

## Content Management

The content management section allows users to view and manage their website content. Features include:

- List of published and draft posts
- Content statistics
- Search and filter capabilities
- Basic content editing

### Content Listing

The content list displays posts with the following information:

- Title
- Excerpt
- Author
- Publication date
- Categories
- Status (published/draft)
- Featured status

Users can filter posts by status (all, published, draft) and search by title, excerpt, author, or category.

### Content Editing

Basic content editing capabilities include:

- Edit title
- Edit excerpt
- Update categories
- Change status (publish/draft)
- Set featured status

## Performance Tracking

The performance tracking section provides detailed analytics on website performance. It includes:

- Traffic metrics (visitors, page views, bounce rate, session duration)
- SEO performance (score, keywords ranked, backlinks)
- Keyword rankings with position changes
- Page speed metrics (load time, server response, page size)

### Traffic Analytics

Traffic analytics are displayed with the following components:

- Current metrics compared to previous period
- Percentage change indicators
- Traffic trend chart over time
- Detailed breakdown by source

### SEO Performance

SEO performance metrics include:

- Overall SEO score
- Number of keywords ranked
- Backlink count
- Organic traffic volume
- Keyword position distribution

### Page Speed

Page speed metrics include:

- Overall speed score
- Load time
- Server response time
- Page size
- Recommendations for improvement

## Notifications

The notification system keeps users informed about important events related to their website. Features include:

- List of notifications with read/unread status
- Filter by notification type (traffic, SEO, content, performance, system)
- Mark as read functionality
- Notification preferences

### Notification Types

- **Traffic**: Alerts about significant traffic changes
- **SEO**: Updates on keyword rankings and backlinks
- **Content**: Reminders about content updates and new comments
- **Performance**: Alerts about page speed issues
- **System**: Updates about plugin and system status

### Push Notifications

Push notifications are implemented using Firebase Cloud Messaging (FCM). The app registers the device token with the Rankolab API, which then sends push notifications for important events.

## Offline Capabilities

The app includes robust offline capabilities to ensure users can access their data even without an internet connection. Features include:

- Data caching for offline access
- Offline actions queue
- Automatic sync when online

### Data Caching

The app caches the following data for offline access:

- Dashboard metrics
- Content list
- Performance metrics
- Notifications

Cached data includes a timestamp and expiry time to ensure data freshness.

### Offline Actions

When offline, user actions are queued for later execution when the device is online again. Actions that can be queued include:

- Mark notification as read
- Update content status
- Update user preferences

### Sync Mechanism

When the device comes online, the app automatically:

1. Syncs queued actions with the server
2. Refreshes cached data
3. Updates the UI with the latest data

## API Integration

The app integrates with the Rankolab API to fetch and update data. The API endpoints are organized by feature:

### Authentication Endpoints

- `POST /rankolab/v1/auth/login`: User login
- `POST /rankolab/v1/auth/register`: User registration
- `POST /rankolab/v1/auth/validate`: Token validation

### Dashboard Endpoints

- `GET /rankolab/v1/dashboard`: Dashboard data
- `GET /rankolab/v1/performance`: Performance metrics
- `GET /rankolab/v1/seo`: SEO metrics

### Content Endpoints

- `GET /rankolab/v1/content/stats`: Content statistics
- `GET /rankolab/v1/content/posts`: List posts
- `GET /rankolab/v1/content/posts/{id}`: Get post details
- `POST /rankolab/v1/content/posts`: Create post
- `PUT /rankolab/v1/content/posts/{id}`: Update post
- `DELETE /rankolab/v1/content/posts/{id}`: Delete post

### Performance Endpoints

- `GET /rankolab/v1/performance/metrics`: All performance metrics
- `GET /rankolab/v1/performance/traffic`: Traffic metrics
- `GET /rankolab/v1/performance/seo`: SEO metrics
- `GET /rankolab/v1/performance/keywords`: Keyword rankings
- `GET /rankolab/v1/performance/speed`: Page speed metrics

### Notification Endpoints

- `GET /rankolab/v1/notifications`: Get notifications
- `PUT /rankolab/v1/notifications/{id}/read`: Mark notification as read
- `PUT /rankolab/v1/notifications/read-all`: Mark all notifications as read
- `POST /rankolab/v1/notifications/register-device`: Register device for push notifications
- `PUT /rankolab/v1/notifications/preferences`: Update notification preferences

## Troubleshooting

### Common Issues

#### Authentication Issues

- **Issue**: Unable to log in
  - **Solution**: Verify username and password
  - **Solution**: Check internet connection
  - **Solution**: Ensure API base URL is correct

- **Issue**: Session expired
  - **Solution**: Log in again
  - **Solution**: Check if token is valid

#### Data Loading Issues

- **Issue**: Data not loading
  - **Solution**: Check internet connection
  - **Solution**: Pull down to refresh
  - **Solution**: Verify API base URL
  - **Solution**: Check if token is valid

- **Issue**: Stale data
  - **Solution**: Pull down to refresh
  - **Solution**: Check last sync timestamp
  - **Solution**: Restart the app

#### Offline Mode Issues

- **Issue**: Actions not syncing when online
  - **Solution**: Manually trigger sync
  - **Solution**: Check internet connection
  - **Solution**: Restart the app

- **Issue**: Cached data not available offline
  - **Solution**: Ensure data was loaded while online
  - **Solution**: Check if cache expiry is set correctly

### Support

For additional support, please contact:

- Email: support@rankolab.com
- Website: https://rankolab.com/support
- In-app: Settings > Help & Support
