# Rankolab Mobile App Installation Guide

This document provides detailed instructions for installing, building, and deploying the Rankolab Mobile App for both development and production environments.

## Development Environment Setup

### Prerequisites

Before you begin, ensure you have the following installed:

- Node.js (v16.0.0 or higher)
- npm (v8.0.0 or higher)
- React Native CLI
- Android Studio (for Android development)
- Xcode (for iOS development, macOS only)
- CocoaPods (for iOS dependencies, macOS only)
- Git

### Step 1: Clone the Repository

```bash
git clone https://github.com/rankolab/mobile-app.git
cd rankolab_mobile_app
```

### Step 2: Install Dependencies

```bash
npm install
```

For iOS, you'll also need to install CocoaPods dependencies:

```bash
cd ios
pod install
cd ..
```

### Step 3: Configure Environment

Create a `.env` file in the project root with the following variables:

```
API_BASE_URL=https://api.rankolab.com
```

For development purposes, you can use:

```
API_BASE_URL=https://dev-api.rankolab.com
```

### Step 4: Run the App in Development Mode

#### For Android:

```bash
npx react-native run-android
```

#### For iOS:

```bash
npx react-native run-ios
```

You can specify a simulator by using the `--simulator` flag:

```bash
npx react-native run-ios --simulator="iPhone 14 Pro"
```

## Production Build

### Android Production Build

#### Step 1: Generate a Signing Key

If you don't already have a signing key, generate one:

```bash
keytool -genkeypair -v -storetype PKCS12 -keystore rankolab.keystore -alias rankolab -keyalg RSA -keysize 2048 -validity 10000
```

#### Step 2: Configure Gradle Variables

Create or edit the `android/gradle.properties` file and add:

```
RANKOLAB_UPLOAD_STORE_FILE=rankolab.keystore
RANKOLAB_UPLOAD_KEY_ALIAS=rankolab
RANKOLAB_UPLOAD_STORE_PASSWORD=*****
RANKOLAB_UPLOAD_KEY_PASSWORD=*****
```

Replace `*****` with your actual keystore and key passwords.

#### Step 3: Configure Signing in Gradle

Edit the `android/app/build.gradle` file to include the signing configuration:

```gradle
android {
    ...
    defaultConfig { ... }
    signingConfigs {
        release {
            storeFile file(RANKOLAB_UPLOAD_STORE_FILE)
            storePassword RANKOLAB_UPLOAD_STORE_PASSWORD
            keyAlias RANKOLAB_UPLOAD_KEY_ALIAS
            keyPassword RANKOLAB_UPLOAD_KEY_PASSWORD
        }
    }
    buildTypes {
        release {
            ...
            signingConfig signingConfigs.release
        }
    }
}
```

#### Step 4: Build the Release APK

```bash
cd android
./gradlew assembleRelease
```

The APK will be generated at `android/app/build/outputs/apk/release/app-release.apk`.

#### Step 5: Test the Release Build

Install the release build on a device:

```bash
adb install app/build/outputs/apk/release/app-release.apk
```

### iOS Production Build

#### Step 1: Configure App Signing

1. Open the project in Xcode:
   ```bash
   open ios/RankolabMobileApp.xcworkspace
   ```

2. Select the project in the Project Navigator
3. Select the "Signing & Capabilities" tab
4. Select your team and ensure "Automatically manage signing" is checked
5. Resolve any signing issues that appear

#### Step 2: Configure Release Scheme

1. In Xcode, go to Product > Scheme > Edit Scheme
2. Select "Run" from the left sidebar
3. Change the Build Configuration to "Release"

#### Step 3: Build the App for Archive

1. Select a generic iOS device as the build target
2. Go to Product > Archive
3. Wait for the archiving process to complete

#### Step 4: Distribute the App

1. After archiving, the Organizer window will appear
2. Select the archive you just created
3. Click "Distribute App"
4. Follow the prompts to distribute via App Store Connect or as an Ad Hoc/Enterprise build

## Continuous Integration Setup

### GitHub Actions

Create a `.github/workflows/build.yml` file with the following content:

```yaml
name: Build and Test

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '16'
      - name: Install dependencies
        run: npm ci
      - name: Run tests
        run: npm test

  build-android:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '16'
      - name: Install dependencies
        run: npm ci
      - name: Set up JDK
        uses: actions/setup-java@v3
        with:
          distribution: 'adopt'
          java-version: '11'
      - name: Build Android Release
        run: |
          cd android
          ./gradlew assembleRelease
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: app-release
          path: android/app/build/outputs/apk/release/app-release.apk

  build-ios:
    needs: test
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '16'
      - name: Install dependencies
        run: |
          npm ci
          cd ios
          pod install
      - name: Build iOS
        run: |
          xcodebuild -workspace ios/RankolabMobileApp.xcworkspace -scheme RankolabMobileApp -configuration Release -sdk iphonesimulator -destination 'platform=iOS Simulator,name=iPhone 14' build
```

## Troubleshooting

### Common Build Issues

#### Android Build Issues

1. **Gradle Build Failures**
   - Solution: Check that you have the correct Java version installed
   - Solution: Run `./gradlew clean` and try again
   - Solution: Update Gradle version in `android/gradle/wrapper/gradle-wrapper.properties`

2. **Missing Android SDK Components**
   - Solution: Open Android Studio > SDK Manager and install required components
   - Solution: Set `ANDROID_HOME` environment variable to your Android SDK location

#### iOS Build Issues

1. **CocoaPods Dependencies Issues**
   - Solution: Run `pod repo update` and then `pod install` again
   - Solution: Delete the `Pods/` directory and `Podfile.lock`, then run `pod install`

2. **Xcode Build Errors**
   - Solution: Ensure you have the latest Xcode command line tools installed
   - Solution: Check that your Apple Developer account has the necessary permissions
   - Solution: Clean the build folder (Product > Clean Build Folder) and try again

### Getting Help

If you encounter issues not covered in this guide, please:

1. Check the [GitHub Issues](https://github.com/rankolab/mobile-app/issues) for similar problems
2. Contact the Rankolab support team at support@rankolab.com
3. Join our developer community on Slack for real-time assistance
