# Rankolab Mobile App

A comprehensive mobile application for the Rankolab WordPress plugin system, providing on-the-go access to website performance metrics, content management, and notifications.

## Overview

The Rankolab Mobile App is designed to complement the Rankolab WordPress plugin, allowing users to monitor and manage their websites from anywhere. The app provides real-time performance metrics, content management capabilities, and notifications for important events.

## Features

- **Authentication System**: Secure login, registration, and password recovery
- **Dashboard**: Interactive charts and widgets displaying key performance metrics
- **Content Management**: View, filter, and manage website content
- **Performance Tracking**: Detailed analytics for traffic, SEO, and page speed
- **Notification System**: Real-time alerts for important website events
- **Offline Mode**: Access data and queue actions while offline
- **User Settings**: Customize app preferences and notification settings

## Documentation

Comprehensive documentation is available in the `docs` directory:

- [User Guide](docs/README.md): Detailed information about app features and usage
- [Installation Guide](docs/INSTALLATION.md): Instructions for setting up development and production environments
- [API Integration Guide](docs/API_INTEGRATION.md): Details about API endpoints and integration

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm (v8 or higher)
- React Native CLI
- Android Studio (for Android development)
- Xcode (for iOS development, macOS only)

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. For iOS, install CocoaPods dependencies:
   ```
   cd ios && pod install && cd ..
   ```
4. Run the app:
   - Android: `npx react-native run-android`
   - iOS: `npx react-native run-ios`

## Building for Production

Use the build script to create production builds:

```
cd build
./build.sh
```

This will create APK (Android) and IPA (iOS) files in the `build` directory.

## Technology Stack

- **Framework**: React Native
- **State Management**: Redux
- **Navigation**: React Navigation
- **UI Components**: React Native Paper
- **Charts**: React Native Chart Kit
- **API Communication**: Axios
- **Storage**: AsyncStorage
- **Authentication**: JWT tokens
- **Push Notifications**: Firebase Cloud Messaging

## Project Structure

```
rankolab_mobile_app/
├── src/
│   ├── assets/         # Images, fonts, and other static assets
│   ├── components/     # Reusable UI components
│   ├── navigation/     # Navigation configuration
│   ├── screens/        # Screen components
│   ├── services/       # API services
│   ├── store/          # Redux store configuration
│   │   ├── actions/    # Redux actions
│   │   └── reducers/   # Redux reducers
│   └── utils/          # Utility functions and constants
├── docs/               # Documentation
├── build/              # Build scripts and output
├── App.js              # Main application component
└── index.js            # Entry point
```

## Support

For support with the Rankolab Mobile App, please contact:

- Email: support@rankolab.com
- Website: https://rankolab.com/support

## License

This project is licensed under the MIT License - see the LICENSE file for details.
