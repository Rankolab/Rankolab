<?php
/**
 * Backend API Endpoints for Rankolab
 *
 * This file defines the API endpoints for the Rankolab backend website.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

/**
 * Register the API endpoints.
 */
function rankolab_register_api_endpoints() {
    // Register the API namespace
    register_rest_namespace('rankolab/v1', array(
        // Authentication endpoints
        'auth/generate-api-key' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_generate_key',
            'permission_callback' => '__return_true',
        ),
        
        // License endpoints
        'license/verify' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_verify_license',
            'permission_callback' => '__return_true',
        ),
        'license/deactivate' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_deactivate_license',
            'permission_callback' => '__return_true',
        ),
        
        // User endpoints
        'users/sync' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_sync_user',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'users/delete' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_delete_user',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'users/login' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_track_login',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Subscription endpoints
        'subscriptions/create' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_create_subscription',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'subscriptions/update' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_update_subscription',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'subscriptions/cancel' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_cancel_subscription',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'subscriptions/details' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_subscription',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Content endpoints
        'content/templates' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_content_templates',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'content/generate' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_generate_content',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'content/sync' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_sync_content',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Domain endpoints
        'domain/analyze' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_analyze_domain',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // SEO endpoints
        'seo/recommendations' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_get_seo_recommendations',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'seo/data' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_seo_data',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Design endpoints
        'design/templates' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_design_templates',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'design/generate' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_generate_design',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Social media endpoints
        'social/suggestions' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_get_social_suggestions',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Link endpoints
        'links/opportunities' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_find_link_opportunities',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'links/check' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_check_link',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Monitoring endpoints
        'monitoring/results' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_monitoring_results',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // AdSense endpoints
        'adsense/suggestions' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_adsense_suggestions',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Assistant endpoints
        'assistant/query' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_assistant_query',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Affiliate endpoints
        'affiliate/register' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_register_affiliate',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'affiliate/conversion' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_track_affiliate_conversion',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Stats endpoints
        'stats/site' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_record_site_stats',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'stats/usage' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_record_usage_stats',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Usage endpoints
        'usage/track' => array(
            'methods' => 'POST',
            'callback' => 'rankolab_api_track_usage',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        'usage/current' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_get_current_usage',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
        
        // Update endpoints
        'updates/check' => array(
            'methods' => 'GET',
            'callback' => 'rankolab_api_check_updates',
            'permission_callback' => 'rankolab_api_check_auth',
        ),
    ));
}
add_action('rest_api_init', 'rankolab_register_api_endpoints');

/**
 * Check API authentication.
 *
 * @param WP_REST_Request $request The request object.
 * @return boolean Whether the request is authenticated.
 */
function rankolab_api_check_auth($request) {
    $api_key = $request->get_header('X-API-Key');
    
    if (empty($api_key)) {
        return false;
    }
    
    // Check if the API key is valid
    $valid_keys = get_option('rankolab_valid_api_keys', array());
    
    return in_array($api_key, $valid_keys);
}

/**
 * Generate an API key.
 *
 * @param WP_REST_Request $request The request object.
 * @return WP_REST_Response The response object.
 */
function rankolab_api_generate_key($request) {
    $params = $request->get_json_params();
    
    // Check required parameters
    if (empty($params['license_key']) || empty($params['domain'])) {
        return new WP_REST_Response(array(
            'success' => false,
            'error' => 'Missing required parameters',
        ), 400);
    }
    
    // Verify license key
    $license_key = sanitize_text_field($params['license_key']);
    $domain = sanitize_text_field($params['domain']);
    
    // Check if this is the master key
    $is_master = ($license_key === 'RANKO-MASTER-2025-XYZ123');
    
    // Check license in database
    if (!$is_master) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rankolab_licenses';
        
        $license = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE license_key = %s AND status = 'active'",
            $license_key
        ));
        
        if (!$license) {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Invalid or inactive license key',
            ), 400);
        }
        
        // Check if domain is allowed
        $allowed_domains = maybe_unserialize($license->domains);
        
        if (!empty($allowed_domains) && !in_array($domain, $allowed_domains)) {
            // Add domain to allowed domains if limit not reached
            if (count($allowed_domains) < $license->domain_limit) {
                $allowed_domains[] = $domain;
                $wpdb->update(
                    $table_name,
                    array('domains' => maybe_serialize($allowed_domains)),
                    array('id' => $license->id),
                    array('%s'),
                    array('%d')
                );
            } else {
                return new WP_REST_Response(array(
                    'success' => false,
                    'error' => 'Domain limit reached for this license',
                ), 400);
            }
        }
    }
    
    // Generate API key
    $api_key = 'ranko_' . md5(uniqid($license_key . $domain, true));
    
    // Store API key
    $valid_keys = get_option('rankolab_valid_api_keys', array());
    $valid_keys[] = $api_key;
    update_option('rankolab_valid_api_keys', $valid_keys);
    
    // Store domain mapping
    $domain_mappings = get_option('rankolab_domain_mappings', array());
    $domain_mappings[$api_key] = $domain;
    update_option('rankolab_domain_mappings', $domain_mappings);
    
    return new WP_REST_Response(array(
        'success' => true,
        'api_key' => $api_key,
    ), 200);
}

/**
 * Verify a license key.
 *
 * @param WP_REST_Request $request The request object.
 * @return WP_REST_Response The response object.
 */
function rankolab_api_verify_license($request) {
    $params = $request->get_json_params();
    
    // Check required parameters
    if (empty($params['license_key']) || empty($params['domain'])) {
        return new WP_REST_Response(array(
            'success' => false,
            'error' => 'Missing required parameters',
        ), 400);
    }
    
    // Verify license key
    $license_key = sanitize_text_field($params['license_key']);
    $domain = sanitize_text_field($params['domain']);
    
    // Check if this is the master key
    $is_master = ($license_key === 'RANKO-MASTER-2025-XYZ123');
    
    if ($is_master) {
        // Master key has all features and unlimited usage
        return new WP_REST_Response(array(
            'success' => true,
            'plan' => 'enterprise',
            'expiry' => '2099-12-31',
            'features' => array(
                'content_generation',
                'seo_optimization',
                'domain_analysis',
                'ai_website_design',
                'social_media_integration',
                'link_building',
                'website_monitoring',
                'adsense_optimization',
                'ai_charlotte_assistant',
                'affiliate_management',
                'link_management',
            ),
            'limits' => array(
                'content_generation' => -1,
                'seo_optimization' => -1,
                'domain_analysis' => -1,
                'ai_website_design' => -1,
                'social_media_integration' => -1,
                'link_building' => -1,
                'website_monitoring' => -1,
                'adsense_optimization' => -1,
                'ai_charlotte_assistant' => -1,
                'affiliate_management' => -1,
                'link_management' => -1,
            ),
        ), 200);
    }
    
    // Check license in database
    global $wpdb;
    $table_name = $wpdb->prefix . 'rankolab_licenses';
    
    $license = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE license_key = %s AND status = 'active'",
        $license_key
    ));
    
    if (!$license) {
        return new WP_REST_Response(array(
            'success' => false,
            'error' => 'Invalid or inactive license key',
        ), 400);
    }
    
    // Check if license has expired
    if (strtotime($license->expiry_date) < time()) {
        return new WP_REST_Response(array(
            'success' => false,
            'error' => 'License has expired',
        ), 400);
    }
    
    // Check if domain is allowed
    $allowed_domains = maybe_unserialize($license->domains);
    
    if (!empty($allowed_domains) && !in_array($domain, $allowed_domains)) {
        // Add domain to allowed domains if limit not reached
        if (count($allowed_domains) < $license->domain_limit) {
            $allowed_domains[] = $domain;
            $wpdb->update(
                $table_name,
                array('domains' => maybe_serialize($allowed_domains)),
                array('id' => $license->id),
                array('%s'),
                array('%d')
            );
        } else {
            return new WP_REST_Response(array(
                'success' => false,
                'error' => 'Domain limit reached for this license',
            ), 400);
        }
    }
    
    // Get plan features and limits
    $plan_features = rankolab_get_plan_features($license->plan);
    $plan_limits = rankolab_get_plan_limits($license->plan);
    
    return new WP_REST_Response(array(
        'success' => true,
        'plan' => $license->plan,
        'expiry' => $license->expiry_date,
        'features' => $plan_features,
        'limits' => $plan_limits,
    ), 200);
}

/**
 * Get plan features.
 *
 * @param string $plan The plan name.
 * @return array The plan features.
 */
function rankolab_get_plan_features($plan) {
    $features = array();
    
    switch ($plan) {
        case 'trial':
            $features = array(
                'content_generation',
                'seo_optimization',
                'domain_analysis',
            );
            break;
        
        case 'monthly':
            $features = array(
                'content_generation',
                'seo_optimization',
                'domain_analysis',
                'ai_website_design',
                'social_media_integration',
                'link_building',
                'website_monitoring',
                'adsense_optimization',
            );
            break;
        
        case 'yearly':
            $features = array(
                'content_generation',
                'seo_optimization',
                'domain_analysis',
                'ai_website_design',
                'social_media_integration',
                'link_building',
                'website_monitoring',
                'adsense_optimization',
                'ai_charlotte_assistant',
                'affiliate_management',
                'link_management',
            );
            break;
        
        case 'enterprise':
            $features = array(
                'content_generation',
                'seo_optimization',
                'domain_analysis',
   
(Content truncated due to size limit. Use line ranges to read in chunks)