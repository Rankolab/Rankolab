<?php
/**
 * The file that defines the AdSense optimization module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The AdSense optimization module class.
 *
 * This class handles AdSense optimization functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_AdSense_Optimization {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_analyze_adsense', array($this, 'ajax_analyze_adsense'));
        add_action('wp_ajax_rankolab_optimize_ad_placement', array($this, 'ajax_optimize_ad_placement'));
        add_action('wp_ajax_rankolab_get_adsense_stats', array($this, 'ajax_get_adsense_stats'));
        add_action('wp_ajax_rankolab_save_adsense_settings', array($this, 'ajax_save_adsense_settings'));
        add_action('wp_ajax_rankolab_connect_adsense_account', array($this, 'ajax_connect_adsense_account'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_adsense_page'), 20);
        
        // Register settings
        add_action('admin_init', array($this, 'register_adsense_settings'));
        
        // Add frontend hooks for ad insertion
        add_filter('the_content', array($this, 'insert_ads_in_content'), 100);
        add_action('wp_head', array($this, 'insert_adsense_header_code'));
    }

    /**
     * Add AdSense optimization admin page.
     *
     * @since    1.0.0
     */
    public function add_adsense_page() {
        add_submenu_page(
            'rankolab',
            'AdSense Optimization',
            'AdSense',
            'manage_options',
            'rankolab-adsense',
            array($this, 'display_adsense_page')
        );
    }

    /**
     * Display AdSense optimization admin page.
     *
     * @since    1.0.0
     */
    public function display_adsense_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-adsense.php';
    }

    /**
     * Register AdSense optimization settings.
     *
     * @since    1.0.0
     */
    public function register_adsense_settings() {
        register_setting('rankolab_adsense', 'rankolab_adsense_settings');
        
        add_settings_section(
            'rankolab_adsense_general',
            'General Settings',
            array($this, 'adsense_general_section_callback'),
            'rankolab_adsense'
        );
        
        add_settings_field(
            'adsense_publisher_id',
            'AdSense Publisher ID',
            array($this, 'adsense_publisher_id_callback'),
            'rankolab_adsense',
            'rankolab_adsense_general'
        );
        
        add_settings_field(
            'enable_auto_ads',
            'Enable Auto Ads',
            array($this, 'enable_auto_ads_callback'),
            'rankolab_adsense',
            'rankolab_adsense_general'
        );
        
        add_settings_section(
            'rankolab_adsense_placement',
            'Ad Placement Settings',
            array($this, 'adsense_placement_section_callback'),
            'rankolab_adsense'
        );
        
        add_settings_field(
            'enable_content_ads',
            'Enable Content Ads',
            array($this, 'enable_content_ads_callback'),
            'rankolab_adsense',
            'rankolab_adsense_placement'
        );
        
        add_settings_field(
            'content_ad_positions',
            'Content Ad Positions',
            array($this, 'content_ad_positions_callback'),
            'rankolab_adsense',
            'rankolab_adsense_placement'
        );
        
        add_settings_field(
            'enable_sidebar_ads',
            'Enable Sidebar Ads',
            array($this, 'enable_sidebar_ads_callback'),
            'rankolab_adsense',
            'rankolab_adsense_placement'
        );
        
        add_settings_section(
            'rankolab_adsense_optimization',
            'Optimization Settings',
            array($this, 'adsense_optimization_section_callback'),
            'rankolab_adsense'
        );
        
        add_settings_field(
            'enable_auto_optimization',
            'Enable Auto Optimization',
            array($this, 'enable_auto_optimization_callback'),
            'rankolab_adsense',
            'rankolab_adsense_optimization'
        );
        
        add_settings_field(
            'optimization_frequency',
            'Optimization Frequency',
            array($this, 'optimization_frequency_callback'),
            'rankolab_adsense',
            'rankolab_adsense_optimization'
        );
    }

    /**
     * AdSense general section callback.
     *
     * @since    1.0.0
     */
    public function adsense_general_section_callback() {
        echo '<p>Configure your AdSense account settings.</p>';
    }

    /**
     * AdSense publisher ID callback.
     *
     * @since    1.0.0
     */
    public function adsense_publisher_id_callback() {
        $options = get_option('rankolab_adsense_settings');
        $value = isset($options['adsense_publisher_id']) ? $options['adsense_publisher_id'] : '';
        
        echo '<input type="text" id="adsense_publisher_id" name="rankolab_adsense_settings[adsense_publisher_id]" value="' . esc_attr($value) . '" class="regular-text">';
        echo '<p class="description">Your AdSense publisher ID (e.g., pub-1234567890123456)</p>';
    }

    /**
     * Enable auto ads callback.
     *
     * @since    1.0.0
     */
    public function enable_auto_ads_callback() {
        $options = get_option('rankolab_adsense_settings');
        $value = isset($options['enable_auto_ads']) ? $options['enable_auto_ads'] : 0;
        
        echo '<input type="checkbox" id="enable_auto_ads" name="rankolab_adsense_settings[enable_auto_ads]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_auto_ads">Let AdSense automatically place ads on your site</label>';
    }

    /**
     * AdSense placement section callback.
     *
     * @since    1.0.0
     */
    public function adsense_placement_section_callback() {
        echo '<p>Configure where ads should appear on your site.</p>';
    }

    /**
     * Enable content ads callback.
     *
     * @since    1.0.0
     */
    public function enable_content_ads_callback() {
        $options = get_option('rankolab_adsense_settings');
        $value = isset($options['enable_content_ads']) ? $options['enable_content_ads'] : 0;
        
        echo '<input type="checkbox" id="enable_content_ads" name="rankolab_adsense_settings[enable_content_ads]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_content_ads">Insert ads within post content</label>';
    }

    /**
     * Content ad positions callback.
     *
     * @since    1.0.0
     */
    public function content_ad_positions_callback() {
        $options = get_option('rankolab_adsense_settings');
        $positions = isset($options['content_ad_positions']) ? $options['content_ad_positions'] : array('middle');
        
        echo '<label><input type="checkbox" name="rankolab_adsense_settings[content_ad_positions][]" value="top" ' . checked(in_array('top', $positions), true, false) . '> Top of content</label><br>';
        echo '<label><input type="checkbox" name="rankolab_adsense_settings[content_ad_positions][]" value="middle" ' . checked(in_array('middle', $positions), true, false) . '> Middle of content</label><br>';
        echo '<label><input type="checkbox" name="rankolab_adsense_settings[content_ad_positions][]" value="bottom" ' . checked(in_array('bottom', $positions), true, false) . '> Bottom of content</label><br>';
        echo '<label><input type="checkbox" name="rankolab_adsense_settings[content_ad_positions][]" value="after_paragraph" ' . checked(in_array('after_paragraph', $positions), true, false) . '> After specific paragraph</label>';
        
        $paragraph_number = isset($options['paragraph_number']) ? $options['paragraph_number'] : 3;
        echo ' Paragraph number: <input type="number" name="rankolab_adsense_settings[paragraph_number]" value="' . esc_attr($paragraph_number) . '" min="1" max="10" style="width: 60px;">';
    }

    /**
     * Enable sidebar ads callback.
     *
     * @since    1.0.0
     */
    public function enable_sidebar_ads_callback() {
        $options = get_option('rankolab_adsense_settings');
        $value = isset($options['enable_sidebar_ads']) ? $options['enable_sidebar_ads'] : 0;
        
        echo '<input type="checkbox" id="enable_sidebar_ads" name="rankolab_adsense_settings[enable_sidebar_ads]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_sidebar_ads">Insert ads in sidebar widgets</label>';
    }

    /**
     * AdSense optimization section callback.
     *
     * @since    1.0.0
     */
    public function adsense_optimization_section_callback() {
        echo '<p>Configure how ads should be optimized for better performance.</p>';
    }

    /**
     * Enable auto optimization callback.
     *
     * @since    1.0.0
     */
    public function enable_auto_optimization_callback() {
        $options = get_option('rankolab_adsense_settings');
        $value = isset($options['enable_auto_optimization']) ? $options['enable_auto_optimization'] : 0;
        
        echo '<input type="checkbox" id="enable_auto_optimization" name="rankolab_adsense_settings[enable_auto_optimization]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_auto_optimization">Automatically optimize ad placements based on performance</label>';
    }

    /**
     * Optimization frequency callback.
     *
     * @since    1.0.0
     */
    public function optimization_frequency_callback() {
        $options = get_option('rankolab_adsense_settings');
        $value = isset($options['optimization_frequency']) ? $options['optimization_frequency'] : 'weekly';
        
        echo '<select id="optimization_frequency" name="rankolab_adsense_settings[optimization_frequency]">';
        echo '<option value="daily" ' . selected('daily', $value, false) . '>Daily</option>';
        echo '<option value="weekly" ' . selected('weekly', $value, false) . '>Weekly</option>';
        echo '<option value="monthly" ' . selected('monthly', $value, false) . '>Monthly</option>';
        echo '</select>';
        echo '<p class="description">How often to analyze and optimize ad performance</p>';
    }

    /**
     * AJAX handler for analyzing AdSense.
     *
     * @since    1.0.0
     */
    public function ajax_analyze_adsense() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_adsense_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $period = isset($_POST['period']) ? sanitize_text_field($_POST['period']) : '30d';
        
        // Analyze AdSense
        $result = $this->analyze_adsense($period);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'analysis_results' => $result['analysis_results']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for optimizing ad placement.
     *
     * @since    1.0.0
     */
    public function ajax_optimize_ad_placement() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_adsense_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $strategy = isset($_POST['strategy']) ? sanitize_text_field($_POST['strategy']) : 'balanced';
        
        // Optimize ad placement
        $result = $this->optimize_ad_placement($strategy);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'optimization_results' => $result['optimization_results']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for getting AdSense stats.
     *
     * @since    1.0.0
     */
    public function ajax_get_adsense_stats() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_adsense_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $period = isset($_POST['period']) ? sanitize_text_field($_POST['period']) : '30d';
        
        // Get AdSense stats
        $result = $this->get_adsense_stats($period);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'stats' => $result['stats']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for saving AdSense settings.
     *
     * @since    1.0.0
     */
    public function ajax_save_adsense_settings() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_adsense_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $settings = isset($_POST['settings']) ? $_POST['settings'] : array();
        
        // Sanitize settings
        $sanitized_settings = array();
        
        foreach ($settings as $key => $value) {
            if (is_array($value)) {
                $sanitized_settings[$key] = array_map('sanitize_text_field', $value);
            } else {
                $sanitized_settings[$key] = sanitize_text_field($value);
            }
        }
        
        // Save settings
        update_option('rankolab_adsense_settings', $sanitized_settings);
        
        wp_send_json_success(array(
            'message' => 'Settings saved successfully.'
        ));
    }

    /**
     * AJAX handler for connecting AdSense account.
     *
     * @since    1.0.0
     */
    public function ajax_connect_adsense_account() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_adsense_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $publisher_id = isset($_POST['publisher_id']) ? sanitize_text_field($_POST['publisher_id']) : '';
        $auth_code = isset($_POST['auth_code']) ? sanitize_text_field($_POST['auth_code']) : '';
        
        // Connect AdSense account
        $result = $this->connect_adsense_account($publisher_id, $auth_code);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'message' => 'AdSense account connected successfully.',
                'account_info' => $result['account_info']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * 
(Content truncated due to size limit. Use line ranges to read in chunks)