<!-- Rankolab Content Generation Module Template -->
<div class="rankolab-content-generation-module" id="rankolab-content-generation">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Content Generation</h2>
            <p>Create high-quality, SEO-optimized content with our AI-powered content generator.</p>
        </div>
    </div>
    
    <!-- Content Generation Form -->
    <div class="rankolab-card rankolab-card-primary rankolab-generation-form">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Generate New Content</h3>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-form-group">
                <label for="rankolab-content-title" class="rankolab-form-label">Content Title</label>
                <input type="text" id="rankolab-content-title" class="rankolab-form-control" placeholder="Enter a title for your content">
            </div>
            
            <div class="rankolab-form-group">
                <label for="rankolab-content-topic" class="rankolab-form-label">Topic or Keywords</label>
                <input type="text" id="rankolab-content-topic" class="rankolab-form-control" placeholder="Enter the main topic or keywords">
                <small class="rankolab-form-text">Separate multiple keywords with commas</small>
            </div>
            
            <div class="rankolab-generation-options">
                <div class="rankolab-form-group">
                    <label for="rankolab-content-type" class="rankolab-form-label">Content Type</label>
                    <select id="rankolab-content-type" class="rankolab-form-control">
                        <option value="blog-post">Blog Post</option>
                        <option value="article">Article</option>
                        <option value="product-description">Product Description</option>
                        <option value="landing-page">Landing Page</option>
                        <option value="social-media">Social Media Post</option>
                        <option value="email">Email</option>
                        <option value="meta-description">Meta Description</option>
                    </select>
                </div>
                
                <div class="rankolab-form-group">
                    <label for="rankolab-content-length" class="rankolab-form-label">Content Length</label>
                    <select id="rankolab-content-length" class="rankolab-form-control">
                        <option value="short">Short (300-500 words)</option>
                        <option value="medium" selected>Medium (500-800 words)</option>
                        <option value="long">Long (800-1500 words)</option>
                        <option value="comprehensive">Comprehensive (1500+ words)</option>
                    </select>
                </div>
                
                <div class="rankolab-form-group">
                    <label for="rankolab-content-tone" class="rankolab-form-label">Tone of Voice</label>
                    <select id="rankolab-content-tone" class="rankolab-form-control">
                        <option value="professional">Professional</option>
                        <option value="conversational">Conversational</option>
                        <option value="friendly">Friendly</option>
                        <option value="authoritative">Authoritative</option>
                        <option value="persuasive">Persuasive</option>
                        <option value="humorous">Humorous</option>
                    </select>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label for="rankolab-content-instructions" class="rankolab-form-label">Additional Instructions (Optional)</label>
                <textarea id="rankolab-content-instructions" class="rankolab-form-control" rows="3" placeholder="Enter any specific instructions or requirements for the content"></textarea>
            </div>
            
            <div class="rankolab-generation-actions">
                <button id="rankolab-generate-content" class="rankolab-btn rankolab-btn-primary">
                    <i class="fas fa-magic"></i> Generate Content
                </button>
            </div>
        </div>
    </div>
    
    <!-- Content Editor -->
    <div class="rankolab-card rankolab-generation-result" style="display: none;">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title rankolab-generation-result-title">Generated Content</h3>
            <div class="rankolab-generation-result-actions">
                <button id="rankolab-analyze-content" class="rankolab-btn rankolab-btn-sm rankolab-btn-info">
                    <i class="fas fa-search"></i> Analyze
                </button>
                <button id="rankolab-save-content" class="rankolab-btn rankolab-btn-sm rankolab-btn-success">
                    <i class="fas fa-save"></i> Save
                </button>
                <button id="rankolab-copy-content" class="rankolab-btn rankolab-btn-sm rankolab-btn-secondary">
                    <i class="fas fa-copy"></i> Copy
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-generation-result-content">
                <textarea id="rankolab-content-editor" class="rankolab-form-control" rows="15"></textarea>
            </div>
        </div>
    </div>
    
    <!-- Content Analysis Results -->
    <div class="rankolab-content-analysis-results" style="display: none;">
        <div class="rankolab-row">
            <!-- Readability Analysis -->
            <div class="rankolab-col rankolab-col-6">
                <div class="rankolab-card">
                    <div class="rankolab-card-header">
                        <h3 class="rankolab-card-title">Readability Analysis</h3>
                    </div>
                    <div class="rankolab-card-body">
                        <div class="rankolab-readability-score">
                            <div class="rankolab-score-circle rankolab-readability-score-circle" style="--score-percentage: 85%;">
                                <div class="rankolab-score-value rankolab-readability-score-value">85</div>
                            </div>
                            <div class="rankolab-score-label">Readability Score</div>
                        </div>
                        
                        <div class="rankolab-readability-factors">
                            <!-- Readability factors will be populated dynamically -->
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- SEO Analysis -->
            <div class="rankolab-col rankolab-col-6">
                <div class="rankolab-card">
                    <div class="rankolab-card-header">
                        <h3 class="rankolab-card-title">SEO Analysis</h3>
                    </div>
                    <div class="rankolab-card-body">
                        <div class="rankolab-content-seo-score">
                            <div class="rankolab-score-circle rankolab-content-seo-score-circle" style="--score-percentage: 78%;">
                                <div class="rankolab-score-value rankolab-content-seo-score-value">78</div>
                            </div>
                            <div class="rankolab-score-label">SEO Score</div>
                        </div>
                        
                        <div class="rankolab-content-seo-factors">
                            <!-- SEO factors will be populated dynamically -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Content -->
    <div class="rankolab-card rankolab-widget">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Recent Content</h3>
            <div class="rankolab-card-actions">
                <a href="<?php echo admin_url('edit.php'); ?>" class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary">
                    View All Content
                </a>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-table-responsive">
                <table class="rankolab-table rankolab-table-hover">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>SEO Score</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recent_content)): ?>
                            <?php foreach ($recent_content as $content): ?>
                                <tr>
                                    <td><?php echo $content['title']; ?></td>
                                    <td><?php echo $content['type']; ?></td>
                                    <td><?php echo $content['date']; ?></td>
                                    <td>
                                        <div class="rankolab-progress">
                                            <div class="rankolab-progress-bar" style="width: <?php echo $content['seo_score']; ?>%;"><?php echo $content['seo_score']; ?>%</div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="rankolab-btn-group">
                                            <a href="<?php echo $content['edit_url']; ?>" class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo $content['view_url']; ?>" class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary rankolab-content-duplicate" data-content-id="<?php echo $content['id']; ?>">
                                                <i class="fas fa-copy"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="rankolab-empty-state">No content generated yet</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
