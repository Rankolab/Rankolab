<?php
/**
 * The file that defines the social media integration module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The social media integration module class.
 *
 * This class handles social media integration functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Social_Media_Integration {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_connect_social_account', array($this, 'ajax_connect_social_account'));
        add_action('wp_ajax_rankolab_disconnect_social_account', array($this, 'ajax_disconnect_social_account'));
        add_action('wp_ajax_rankolab_publish_to_social', array($this, 'ajax_publish_to_social'));
        add_action('wp_ajax_rankolab_schedule_social_post', array($this, 'ajax_schedule_social_post'));
        add_action('wp_ajax_rankolab_get_social_analytics', array($this, 'ajax_get_social_analytics'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_social_media_page'), 20);
        
        // Add meta box for post editor
        add_action('add_meta_boxes', array($this, 'add_social_media_meta_box'));
        
        // Add post publish actions
        add_action('transition_post_status', array($this, 'handle_post_publish'), 10, 3);
        
        // Add scheduled task for social media posting
        add_action('rankolab_scheduled_social_post', array($this, 'process_scheduled_post'), 10, 2);
    }

    /**
     * Add social media admin page.
     *
     * @since    1.0.0
     */
    public function add_social_media_page() {
        add_submenu_page(
            'rankolab',
            'Social Media Integration',
            'Social Media',
            'manage_options',
            'rankolab-social-media',
            array($this, 'display_social_media_page')
        );
    }

    /**
     * Display social media admin page.
     *
     * @since    1.0.0
     */
    public function display_social_media_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-social-media.php';
    }

    /**
     * Add social media meta box to post editor.
     *
     * @since    1.0.0
     */
    public function add_social_media_meta_box() {
        add_meta_box(
            'rankolab_social_media',
            'Rankolab Social Media',
            array($this, 'render_social_media_meta_box'),
            'post',
            'side',
            'high'
        );
    }

    /**
     * Render social media meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_social_media_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('rankolab_social_media_meta_box', 'rankolab_social_media_nonce');
        
        // Get connected accounts
        $connected_accounts = $this->get_connected_accounts();
        
        // Get saved meta
        $share_on_publish = get_post_meta($post->ID, '_rankolab_share_on_publish', true);
        $custom_message = get_post_meta($post->ID, '_rankolab_social_custom_message', true);
        $selected_networks = get_post_meta($post->ID, '_rankolab_selected_networks', true);
        
        if (!$selected_networks) {
            $selected_networks = array();
        }
        
        ?>
        <div class="rankolab-social-meta-box">
            <p>
                <label for="rankolab_share_on_publish">
                    <input type="checkbox" id="rankolab_share_on_publish" name="rankolab_share_on_publish" value="1" <?php checked($share_on_publish, '1'); ?>>
                    Share on social media when published
                </label>
            </p>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_social_custom_message">Custom Message:</label>
                <textarea id="rankolab_social_custom_message" name="rankolab_social_custom_message" class="widefat" rows="3"><?php echo esc_textarea($custom_message); ?></textarea>
                <p class="description">Leave blank to use post title and excerpt.</p>
            </div>
            
            <div class="rankolab-meta-box-field">
                <label>Share on:</label>
                
                <?php if (empty($connected_accounts)) : ?>
                    <p class="rankolab-no-accounts">No social media accounts connected. <a href="<?php echo admin_url('admin.php?page=rankolab-social-media'); ?>">Connect accounts</a></p>
                <?php else : ?>
                    <?php foreach ($connected_accounts as $account) : ?>
                        <p>
                            <label>
                                <input type="checkbox" name="rankolab_selected_networks[]" value="<?php echo esc_attr($account['id']); ?>" <?php checked(in_array($account['id'], $selected_networks)); ?>>
                                <?php echo esc_html($account['name']); ?> (<?php echo esc_html($account['network']); ?>)
                            </label>
                        </p>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="rankolab-meta-box-actions">
                <button type="button" id="rankolab_preview_social_btn" class="button">Preview</button>
                <button type="button" id="rankolab_publish_social_btn" class="button button-primary">Publish Now</button>
                <span class="spinner" style="float: none; margin-top: 0;"></span>
            </div>
            
            <div id="rankolab_social_preview" style="display: none;">
                <h4>Preview</h4>
                <div class="rankolab-social-preview-content"></div>
            </div>
        </div>
        
        <script>
            jQuery(document).ready(function($) {
                // Preview social media post
                $('#rankolab_preview_social_btn').on('click', function() {
                    const customMessage = $('#rankolab_social_custom_message').val();
                    const postTitle = '<?php echo esc_js(get_the_title($post->ID)); ?>';
                    const postExcerpt = '<?php echo esc_js(wp_trim_words(wp_strip_all_tags(strip_shortcodes($post->post_content)), 30, '...')); ?>';
                    const postUrl = '<?php echo esc_js(get_permalink($post->ID)); ?>';
                    
                    let previewContent = '';
                    
                    if (customMessage) {
                        previewContent = customMessage;
                    } else {
                        previewContent = postTitle + '\n\n' + postExcerpt + '\n\n' + postUrl;
                    }
                    
                    $('.rankolab-social-preview-content').text(previewContent);
                    $('#rankolab_social_preview').show();
                });
                
                // Publish to social media
                $('#rankolab_publish_social_btn').on('click', function() {
                    const selectedNetworks = [];
                    $('input[name="rankolab_selected_networks[]"]:checked').each(function() {
                        selectedNetworks.push($(this).val());
                    });
                    
                    if (selectedNetworks.length === 0) {
                        alert('Please select at least one social network.');
                        return;
                    }
                    
                    // Show spinner
                    $(this).prop('disabled', true);
                    $(this).prev().prop('disabled', true);
                    $('.spinner').css('visibility', 'visible');
                    
                    // Publish to social media
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'rankolab_publish_to_social',
                            nonce: '<?php echo wp_create_nonce('rankolab_social_media_nonce'); ?>',
                            post_id: <?php echo $post->ID; ?>,
                            custom_message: $('#rankolab_social_custom_message').val(),
                            networks: selectedNetworks
                        },
                        success: function(response) {
                            // Hide spinner
                            $('#rankolab_publish_social_btn').prop('disabled', false);
                            $('#rankolab_preview_social_btn').prop('disabled', false);
                            $('.spinner').css('visibility', 'hidden');
                            
                            if (response.success) {
                                alert('Published to social media successfully!');
                            } else {
                                alert(response.data);
                            }
                        },
                        error: function() {
                            // Hide spinner
                            $('#rankolab_publish_social_btn').prop('disabled', false);
                            $('#rankolab_preview_social_btn').prop('disabled', false);
                            $('.spinner').css('visibility', 'hidden');
                            
                            alert('An error occurred. Please try again.');
                        }
                    });
                });
            });
        </script>
        <style>
            .rankolab-social-meta-box {
                margin-bottom: 15px;
            }
            
            .rankolab-meta-box-field {
                margin-bottom: 15px;
            }
            
            .rankolab-meta-box-field label {
                display: block;
                margin-bottom: 5px;
                font-weight: 600;
            }
            
            .rankolab-no-accounts {
                color: #666;
                font-style: italic;
            }
            
            .rankolab-meta-box-actions {
                margin-top: 15px;
                display: flex;
                align-items: center;
            }
            
            .rankolab-meta-box-actions .spinner {
                margin-left: 10px;
            }
            
            #rankolab_social_preview {
                margin-top: 15px;
                padding: 10px;
                background-color: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            
            #rankolab_social_preview h4 {
                margin-top: 0;
                margin-bottom: 10px;
            }
            
            .rankolab-social-preview-content {
                white-space: pre-line;
                font-size: 13px;
            }
        </style>
        <?php
    }

    /**
     * Handle post publish.
     *
     * @since    1.0.0
     * @param    string     $new_status    The new post status.
     * @param    string     $old_status    The old post status.
     * @param    WP_Post    $post          The post object.
     */
    public function handle_post_publish($new_status, $old_status, $post) {
        // Check if post is being published
        if ($new_status === 'publish' && $old_status !== 'publish' && $post->post_type === 'post') {
            // Check if post should be shared on social media
            $share_on_publish = get_post_meta($post->ID, '_rankolab_share_on_publish', true);
            
            if ($share_on_publish === '1') {
                // Get selected networks
                $selected_networks = get_post_meta($post->ID, '_rankolab_selected_networks', true);
                
                if (!empty($selected_networks)) {
                    // Get custom message
                    $custom_message = get_post_meta($post->ID, '_rankolab_social_custom_message', true);
                    
                    // Publish to social media
                    $this->publish_to_social($post->ID, $custom_message, $selected_networks);
                }
            }
        }
    }

    /**
     * Save post meta.
     *
     * @since    1.0.0
     * @param    int       $post_id    The post ID.
     * @param    WP_Post   $post       The post object.
     */
    public function save_post_meta($post_id, $post) {
        // Check if nonce is set
        if (!isset($_POST['rankolab_social_media_nonce'])) {
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['rankolab_social_media_nonce'], 'rankolab_social_media_meta_box')) {
            return;
        }
        
        // Check if autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check permissions
        if ('post' === $_POST['post_type'] && !current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save share on publish
        if (isset($_POST['rankolab_share_on_publish'])) {
            update_post_meta($post_id, '_rankolab_share_on_publish', '1');
        } else {
            delete_post_meta($post_id, '_rankolab_share_on_publish');
        }
        
        // Save custom message
        if (isset($_POST['rankolab_social_custom_message'])) {
            update_post_meta($post_id, '_rankolab_social_custom_message', sanitize_textarea_field($_POST['rankolab_social_custom_message']));
        }
        
        // Save selected networks
        if (isset($_POST['rankolab_selected_networks'])) {
            update_post_meta($post_id, '_rankolab_selected_networks', array_map('sanitize_text_field', $_POST['rankolab_selected_networks']));
        } else {
            delete_post_meta($post_id, '_rankolab_selected_networks');
        }
    }

    /**
     * AJAX handler for connecting social account.
     *
     * @since    1.0.0
     */
    public function ajax_connect_social_account() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_social_media_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $network = isset($_POST['network']) ? sanitize_text_field($_POST['network']) : '';
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $credentials = isset($_POST['credentials']) ? $_POST['credentials'] : array();
        
        if (empty($network)) {
            wp_send_json_error('Please select a social network.');
            return;
        }
        
        if (empty($name)) {
            wp_send_json_error('Please enter an account name.');
            return;
        }
        
        // Validate credentials
        $validation_result = $this->validate_credentials($network, $credentials);
        
        if (!$validation_result['success']) {
            wp_send_json_error($validation_result['message']);
            return;
        }
        
        // Connect account
        $resu
(Content truncated due to size limit. Use line ranges to read in chunks)