<!-- Rankolab Admin Dashboard Template -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rankolab Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo RANKOLAB_URL; ?>assets/css/rankolab-main.css">
</head>
<body>
    <div class="rankolab-wrap">
        <div class="rankolab-dashboard">
            <!-- Sidebar Navigation -->
            <div class="rankolab-sidebar">
                <div class="rankolab-logo">
                    <img src="<?php echo RANKOLAB_URL; ?>assets/images/rankolab-logo.png" alt="Rankolab Logo">
                    <span class="rankolab-nav-text rankolab-logo-text">Rankolab</span>
                </div>
                
                <ul class="rankolab-nav">
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-dashboard'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-tachometer-alt"></i></div>
                            <span class="rankolab-nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-domain-analysis'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'domain-analysis' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-globe"></i></div>
                            <span class="rankolab-nav-text">Domain Analysis</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-content-generation'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'content-generation' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-pen-fancy"></i></div>
                            <span class="rankolab-nav-text">Content Generation</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-seo-optimization'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'seo-optimization' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-search"></i></div>
                            <span class="rankolab-nav-text">SEO Optimization</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-ai-website-design'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'ai-website-design' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-paint-brush"></i></div>
                            <span class="rankolab-nav-text">AI Website Design</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-social-media'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'social-media' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-share-alt"></i></div>
                            <span class="rankolab-nav-text">Social Media</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-link-building'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'link-building' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-link"></i></div>
                            <span class="rankolab-nav-text">Link Building</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-website-monitoring'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'website-monitoring' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-heartbeat"></i></div>
                            <span class="rankolab-nav-text">Website Monitoring</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-adsense'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'adsense' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-ad"></i></div>
                            <span class="rankolab-nav-text">AdSense Optimization</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-affiliate'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'affiliate' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-handshake"></i></div>
                            <span class="rankolab-nav-text">Affiliate Management</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-link-management'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'link-management' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-external-link-alt"></i></div>
                            <span class="rankolab-nav-text">Link Management</span>
                        </a>
                    </li>
                    <li class="rankolab-nav-item">
                        <a href="<?php echo admin_url('admin.php?page=rankolab-settings'); ?>" class="rankolab-nav-link <?php echo $active_tab === 'settings' ? 'active' : ''; ?>">
                            <div class="rankolab-nav-icon"><i class="fas fa-cog"></i></div>
                            <span class="rankolab-nav-text">Settings</span>
                        </a>
                    </li>
                </ul>
                
                <div class="rankolab-sidebar-footer">
                    <div class="rankolab-license-status">
                        <?php if ($license_status === 'active'): ?>
                            <div class="rankolab-license-badge rankolab-license-active">
                                <i class="fas fa-check-circle"></i> License Active
                            </div>
                        <?php else: ?>
                            <div class="rankolab-license-badge rankolab-license-inactive">
                                <i class="fas fa-exclamation-circle"></i> License Inactive
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="rankolab-version">
                        Version <?php echo RANKOLAB_VERSION; ?>
                    </div>
                </div>
            </div>
            
            <!-- Main Content Area -->
            <div class="rankolab-main-content">
                <!-- Header -->
                <div class="rankolab-header">
                    <div class="rankolab-header-title">
                        <h1><?php echo $page_title; ?></h1>
                    </div>
                    <div class="rankolab-header-actions">
                        <button class="rankolab-btn rankolab-btn-outline-primary rankolab-sidebar-toggle">
                            <i class="fas fa-bars"></i>
                        </button>
                        <div class="rankolab-notifications">
                            <button class="rankolab-btn rankolab-btn-outline-primary rankolab-notifications-toggle">
                                <i class="fas fa-bell"></i>
                                <?php if ($notification_count > 0): ?>
                                    <span class="rankolab-badge rankolab-badge-primary"><?php echo $notification_count; ?></span>
                                <?php endif; ?>
                            </button>
                            <div class="rankolab-notifications-dropdown">
                                <div class="rankolab-notifications-header">
                                    <h3>Notifications</h3>
                                    <a href="<?php echo admin_url('admin.php?page=rankolab-notifications'); ?>">View All</a>
                                </div>
                                <div class="rankolab-notifications-list">
                                    <?php if (!empty($notifications)): ?>
                                        <?php foreach ($notifications as $notification): ?>
                                            <div class="rankolab-notification-item">
                                                <div class="rankolab-notification-icon">
                                                    <i class="<?php echo $notification['icon']; ?>"></i>
                                                </div>
                                                <div class="rankolab-notification-content">
                                                    <div class="rankolab-notification-message"><?php echo $notification['message']; ?></div>
                                                    <div class="rankolab-notification-time"><?php echo $notification['time']; ?></div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="rankolab-empty-state">No notifications</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="rankolab-user-menu">
                            <button class="rankolab-btn rankolab-btn-outline-primary rankolab-user-menu-toggle">
                                <img src="<?php echo $user_avatar; ?>" alt="User Avatar" class="rankolab-user-avatar">
                                <span class="rankolab-user-name"><?php echo $user_name; ?></span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="rankolab-user-menu-dropdown">
                                <a href="<?php echo admin_url('profile.php'); ?>" class="rankolab-user-menu-item">
                                    <i class="fas fa-user"></i> Profile
                                </a>
                                <a href="<?php echo admin_url('admin.php?page=rankolab-settings'); ?>" class="rankolab-user-menu-item">
                                    <i class="fas fa-cog"></i> Settings
                                </a>
                                <a href="<?php echo wp_logout_url(admin_url()); ?>" class="rankolab-user-menu-item">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Page Content -->
                <div class="rankolab-page-content">
                    <!-- Notifications Container -->
                    <div class="rankolab-notifications-container"></div>
                    
                    <!-- Content will be loaded here -->
                    <?php echo $content; ?>
                </div>
                
                <!-- Footer -->
                <div class="rankolab-footer">
                    <div class="rankolab-footer-content">
                        <p>&copy; <?php echo date('Y'); ?> Rankolab. All rights reserved.</p>
                    </div>
                    <div class="rankolab-footer-links">
                        <a href="https://rankolab.com/documentation" target="_blank">Documentation</a>
                        <a href="https://rankolab.com/support" target="_blank">Support</a>
                        <a href="https://rankolab.com/blog" target="_blank">Blog</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- AI Assistant -->
    <div class="rankolab-ai-assistant">
        <div class="rankolab-ai-toggle">
            <i class="fas fa-robot"></i>
        </div>
        <div class="rankolab-ai-panel">
            <div class="rankolab-ai-header">
                <div class="rankolab-ai-title">Charlotte AI Assistant</div>
                <div class="rankolab-ai-close">&times;</div>
            </div>
            <div class="rankolab-ai-messages">
                <div class="rankolab-ai-message assistant">
                    Hi there! I'm Charlotte, your AI assistant. How can I help you with your SEO and content today?
                </div>
            </div>
            <div class="rankolab-ai-input">
                <input type="text" id="rankolab-ai-input" class="rankolab-form-control" placeholder="Ask Charlotte anything...">
                <button id="rankolab-ai-send" class="rankolab-btn rankolab-btn-primary">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var rankolab_params = {
            ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('rankolab_nonce'); ?>',
            license_url: '<?php echo admin_url('admin.php?page=rankolab-settings&tab=license'); ?>',
            admin_url: '<?php echo admin_url('admin.php'); ?>'
        };
    </script>
    <script src="<?php echo RANKOLAB_URL; ?>assets/js/rankolab-main.js"></script>
</body>
</html>
