<?php
/**
 * The file that defines the AI Charlotte Assistant module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The AI Charlotte Assistant module class.
 *
 * This class handles the AI-powered Charlotte Assistant functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_AI_Charlotte_Assistant {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_charlotte_chat', array($this, 'ajax_charlotte_chat'));
        add_action('wp_ajax_rankolab_charlotte_analyze_content', array($this, 'ajax_charlotte_analyze_content'));
        add_action('wp_ajax_rankolab_charlotte_generate_suggestions', array($this, 'ajax_charlotte_generate_suggestions'));
        add_action('wp_ajax_rankolab_charlotte_save_settings', array($this, 'ajax_charlotte_save_settings'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_charlotte_page'), 20);
        
        // Register settings
        add_action('admin_init', array($this, 'register_charlotte_settings'));
        
        // Add Charlotte assistant to admin bar
        add_action('admin_bar_menu', array($this, 'add_charlotte_to_admin_bar'), 999);
        
        // Add Charlotte assistant to editor
        add_action('admin_footer', array($this, 'add_charlotte_to_editor'));
        
        // Enqueue scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    /**
     * Add Charlotte assistant admin page.
     *
     * @since    1.0.0
     */
    public function add_charlotte_page() {
        add_submenu_page(
            'rankolab',
            'Charlotte AI Assistant',
            'Charlotte AI',
            'manage_options',
            'rankolab-charlotte',
            array($this, 'display_charlotte_page')
        );
    }

    /**
     * Display Charlotte assistant admin page.
     *
     * @since    1.0.0
     */
    public function display_charlotte_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-charlotte.php';
    }

    /**
     * Register Charlotte assistant settings.
     *
     * @since    1.0.0
     */
    public function register_charlotte_settings() {
        register_setting('rankolab_charlotte', 'rankolab_charlotte_settings');
        
        add_settings_section(
            'rankolab_charlotte_general',
            'General Settings',
            array($this, 'charlotte_general_section_callback'),
            'rankolab_charlotte'
        );
        
        add_settings_field(
            'enable_charlotte',
            'Enable Charlotte AI Assistant',
            array($this, 'enable_charlotte_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_general'
        );
        
        add_settings_field(
            'charlotte_api_key',
            'AI API Key',
            array($this, 'charlotte_api_key_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_general'
        );
        
        add_settings_field(
            'charlotte_model',
            'AI Model',
            array($this, 'charlotte_model_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_general'
        );
        
        add_settings_section(
            'rankolab_charlotte_features',
            'Feature Settings',
            array($this, 'charlotte_features_section_callback'),
            'rankolab_charlotte'
        );
        
        add_settings_field(
            'enable_content_analysis',
            'Enable Content Analysis',
            array($this, 'enable_content_analysis_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_features'
        );
        
        add_settings_field(
            'enable_writing_suggestions',
            'Enable Writing Suggestions',
            array($this, 'enable_writing_suggestions_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_features'
        );
        
        add_settings_field(
            'enable_seo_suggestions',
            'Enable SEO Suggestions',
            array($this, 'enable_seo_suggestions_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_features'
        );
        
        add_settings_field(
            'enable_chat_interface',
            'Enable Chat Interface',
            array($this, 'enable_chat_interface_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_features'
        );
        
        add_settings_section(
            'rankolab_charlotte_appearance',
            'Appearance Settings',
            array($this, 'charlotte_appearance_section_callback'),
            'rankolab_charlotte'
        );
        
        add_settings_field(
            'charlotte_position',
            'Charlotte Position',
            array($this, 'charlotte_position_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_appearance'
        );
        
        add_settings_field(
            'charlotte_theme',
            'Charlotte Theme',
            array($this, 'charlotte_theme_callback'),
            'rankolab_charlotte',
            'rankolab_charlotte_appearance'
        );
    }

    /**
     * Charlotte general section callback.
     *
     * @since    1.0.0
     */
    public function charlotte_general_section_callback() {
        echo '<p>Configure general settings for the Charlotte AI Assistant.</p>';
    }

    /**
     * Enable Charlotte callback.
     *
     * @since    1.0.0
     */
    public function enable_charlotte_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['enable_charlotte']) ? $options['enable_charlotte'] : 1;
        
        echo '<input type="checkbox" id="enable_charlotte" name="rankolab_charlotte_settings[enable_charlotte]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_charlotte">Enable Charlotte AI Assistant throughout WordPress admin</label>';
    }

    /**
     * Charlotte API key callback.
     *
     * @since    1.0.0
     */
    public function charlotte_api_key_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['charlotte_api_key']) ? $options['charlotte_api_key'] : '';
        
        echo '<input type="password" id="charlotte_api_key" name="rankolab_charlotte_settings[charlotte_api_key]" value="' . esc_attr($value) . '" class="regular-text">';
        echo '<p class="description">Your AI API key for Charlotte (optional - uses Rankolab API by default)</p>';
    }

    /**
     * Charlotte model callback.
     *
     * @since    1.0.0
     */
    public function charlotte_model_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['charlotte_model']) ? $options['charlotte_model'] : 'standard';
        
        echo '<select id="charlotte_model" name="rankolab_charlotte_settings[charlotte_model]">';
        echo '<option value="standard" ' . selected('standard', $value, false) . '>Standard</option>';
        echo '<option value="advanced" ' . selected('advanced', $value, false) . '>Advanced</option>';
        echo '<option value="expert" ' . selected('expert', $value, false) . '>Expert</option>';
        echo '</select>';
        echo '<p class="description">Select the AI model to use for Charlotte (advanced models may require higher tier subscription)</p>';
    }

    /**
     * Charlotte features section callback.
     *
     * @since    1.0.0
     */
    public function charlotte_features_section_callback() {
        echo '<p>Configure which features Charlotte should provide.</p>';
    }

    /**
     * Enable content analysis callback.
     *
     * @since    1.0.0
     */
    public function enable_content_analysis_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['enable_content_analysis']) ? $options['enable_content_analysis'] : 1;
        
        echo '<input type="checkbox" id="enable_content_analysis" name="rankolab_charlotte_settings[enable_content_analysis]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_content_analysis">Enable content analysis in the editor</label>';
    }

    /**
     * Enable writing suggestions callback.
     *
     * @since    1.0.0
     */
    public function enable_writing_suggestions_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['enable_writing_suggestions']) ? $options['enable_writing_suggestions'] : 1;
        
        echo '<input type="checkbox" id="enable_writing_suggestions" name="rankolab_charlotte_settings[enable_writing_suggestions]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_writing_suggestions">Enable writing suggestions in the editor</label>';
    }

    /**
     * Enable SEO suggestions callback.
     *
     * @since    1.0.0
     */
    public function enable_seo_suggestions_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['enable_seo_suggestions']) ? $options['enable_seo_suggestions'] : 1;
        
        echo '<input type="checkbox" id="enable_seo_suggestions" name="rankolab_charlotte_settings[enable_seo_suggestions]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_seo_suggestions">Enable SEO suggestions in the editor</label>';
    }

    /**
     * Enable chat interface callback.
     *
     * @since    1.0.0
     */
    public function enable_chat_interface_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['enable_chat_interface']) ? $options['enable_chat_interface'] : 1;
        
        echo '<input type="checkbox" id="enable_chat_interface" name="rankolab_charlotte_settings[enable_chat_interface]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_chat_interface">Enable chat interface for asking questions</label>';
    }

    /**
     * Charlotte appearance section callback.
     *
     * @since    1.0.0
     */
    public function charlotte_appearance_section_callback() {
        echo '<p>Configure how Charlotte appears in the WordPress admin.</p>';
    }

    /**
     * Charlotte position callback.
     *
     * @since    1.0.0
     */
    public function charlotte_position_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['charlotte_position']) ? $options['charlotte_position'] : 'bottom-right';
        
        echo '<select id="charlotte_position" name="rankolab_charlotte_settings[charlotte_position]">';
        echo '<option value="bottom-right" ' . selected('bottom-right', $value, false) . '>Bottom Right</option>';
        echo '<option value="bottom-left" ' . selected('bottom-left', $value, false) . '>Bottom Left</option>';
        echo '<option value="top-right" ' . selected('top-right', $value, false) . '>Top Right</option>';
        echo '<option value="top-left" ' . selected('top-left', $value, false) . '>Top Left</option>';
        echo '</select>';
        echo '<p class="description">Select where Charlotte should appear on the screen</p>';
    }

    /**
     * Charlotte theme callback.
     *
     * @since    1.0.0
     */
    public function charlotte_theme_callback() {
        $options = get_option('rankolab_charlotte_settings');
        $value = isset($options['charlotte_theme']) ? $options['charlotte_theme'] : 'light';
        
        echo '<select id="charlotte_theme" name="rankolab_charlotte_settings[charlotte_theme]">';
        echo '<option value="light" ' . selected('light', $value, false) . '>Light</option>';
        echo '<option value="dark" ' . selected('dark', $value, false) . '>Dark</option>';
        echo '<option value="auto" ' . selected('auto', $value, false) . '>Auto (follows system)</option>';
        echo '</select>';
        echo '<p class="description">Select the color theme for Charlotte</p>';
    }

    /**
     * Add Charlotte to admin bar.
     *
     * @since    1.0.0
     * @param    WP_Admin_Bar    $admin_bar    The admin bar object.
     */
    public function add_charlotte_to_admin_bar($admin_bar) {
        // Check if Charlotte is enabled
        $options = get_option('rankolab_charlotte_settings');
        $enable_charlotte = isset($options['enable_charlotte']) ? $options['enable_charlotte'] : 1;
        
        if (!$enable_charlotte) {
            return;
        }
        
        // Add Charlotte to admin bar
        $admin_bar->add_node(array(
            'id'    => 'rankolab-charlotte',
            'title' => '<span class="ab-icon dashicons dashicons-admin-customizer"></span><span class="ab-label">Charlotte AI</span>',
            'href'  => '#',
            'meta'  => array(
                'class' => 'rankolab-charlotte-toggle',
                'title' => 'Open Charlotte AI Assistant'
            )
        ));
    }

    /**
     * Add Charlotte to editor.
     *
     * @since    1.0.0
     */
    public function add_charlotte_to_editor() {
        // Check if Charlotte is enabled
        $options = get_option('rankolab_charlotte_settings');
        $enable_charlotte = isset($options['enable_charlotte']) ? $options['enable_charlotte'] : 1;
        
        if (!$enable_charlotte) {
            return;
        }
        
        // Check if we're on a post edit screen
        $screen = get_current_screen();
        
        if (!$screen || !in_array($screen->base, array('post', 'page', 'post-new', 'post-edit'))) {
            return;
        }
        
        // Get Charlotte settings
        $enable_content_analysis = isset($options['enable_content_analysis']) ? $options['enable_content_analysis'] : 1;
        $enable_writing_suggestions = isset($options['enable_writing_suggestions']) ? $options['enable_writing_suggestions'] : 1;
        $enable_seo_suggestions = isset($options['enable_seo_suggestions']) ? $options['enable_seo_suggestions'] : 1;
        $charlotte_position = isset($options['charlotte_position']) ? $options['charlotte_position'] : 'bottom-right';
        $charlotte_theme = isset($options['charlotte_theme']) ? $options['charlotte_theme'] : 'light';
        
        // Output Charlotte HTML
        ?>
        <div id="rankolab-charlotte-container" class="rankolab-charlotte-<?php echo esc_attr($charlotte_position); ?> rankolab-charlotte-theme-<?php echo esc_attr($charlotte_theme); ?>">
            <div class="rankolab-charlotte-toggle-button">
                <span class="dashicons dashicons-admin-customizer"></span>
            </div>
            <div class="rankolab-charlotte-panel">
                <div class="rankolab-charlotte-header">
                    <h3>Charlotte AI Assistant</h3>
                    <button class="rankolab-charlotte-close"><span class="dashicons dashicons-
(Content truncated due to size limit. Use line ranges to read in chunks)