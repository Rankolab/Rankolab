<?php
/**
 * The file that defines the license verification functionality
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

/**
 * The license verification class.
 *
 * This class handles license verification and management.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_License {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * The license key.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $license_key    The license key.
     */
    private $license_key;

    /**
     * The license status.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $license_status    The license status.
     */
    private $license_status;

    /**
     * The API endpoint for license verification.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $api_endpoint    The API endpoint for license verification.
     */
    private $api_endpoint = 'http://localhost:5001/api/licenses/validate';

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->license_key = get_option('rankolab_license_key', '');
        $this->license_status = get_option('rankolab_license_status', '');
        
        // Schedule daily license verification
        if (!wp_next_scheduled('rankolab_license_verification')) {
            wp_schedule_event(time(), 'daily', 'rankolab_license_verification');
        }
        
        // Add license verification hook
        add_action('rankolab_license_verification', array($this, 'verify_license_scheduled'));
    }

    /**
     * Verify the license key.
     *
     * @since    1.0.0
     * @param    string    $license_key    The license key to verify.
     * @return   array     The verification result.
     */
    public function verify_license($license_key) {
        global $wpdb;
        
        // Check if it's the master key
        $master_key = 'RANKO-MASTER-2025-XYZ123';
        
        if ($license_key === $master_key) {
            // Check if master key exists in database
            $table_name = $wpdb->prefix . 'rankolab_license_keys';
            $key_exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE license_key = %s", $master_key));
            
            if ($key_exists) {
                // Update last verification time
                $wpdb->update(
                    $table_name,
                    array('last_verification' => current_time('mysql')),
                    array('license_key' => $master_key),
                    array('%s'),
                    array('%s')
                );
                
                // Update options
                update_option('rankolab_license_key', $master_key);
                update_option('rankolab_license_status', 'valid');
                
                $this->license_key = $master_key;
                $this->license_status = 'valid';
                
                return array(
                    'success' => true,
                    'message' => 'Master license key verified successfully.',
                    'status' => 'valid',
                    'expiration' => date('Y-m-d H:i:s', strtotime('+10 years'))
                );
            }
        }
        
        // For regular keys, we would make an API call to the license server
        // For now, we'll simulate the API response
        
        // Check if key format is valid (basic validation)
        if (!preg_match('/^RANKO-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{6}$/', $license_key) && $license_key !== $master_key) {
            return array(
                'success' => false,
                'message' => 'Invalid license key format.',
                'status' => 'invalid'
            );
        }
        
        // Simulate API response
        $response = $this->simulate_api_response($license_key);
        
        // Update options based on response
        if ($response['success']) {
            update_option('rankolab_license_key', $license_key);
            update_option('rankolab_license_status', $response['status']);
            
            $this->license_key = $license_key;
            $this->license_status = $response['status'];
        }
        
        return $response;
    }

    /**
     * Simulate API response for license verification.
     *
     * @since    1.0.0
     * @param    string    $license_key    The license key to verify.
     * @return   array     The simulated API response.
     */
    private function simulate_api_response($license_key) {
        // For demonstration purposes, we'll consider all keys starting with "RANKO-" as valid
        // In a real implementation, this would make an actual API call to the license server
        
        if (strpos($license_key, 'RANKO-') === 0) {
            // Randomly determine if the license is valid or expired (for testing)
            $status = (rand(0, 10) > 2) ? 'valid' : 'expired';
            
            if ($status === 'valid') {
                return array(
                    'success' => true,
                    'message' => 'License key verified successfully.',
                    'status' => 'valid',
                    'expiration' => date('Y-m-d H:i:s', strtotime('+1 year'))
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'License key has expired.',
                    'status' => 'expired',
                    'expiration' => date('Y-m-d H:i:s', strtotime('-1 day'))
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'Invalid license key.',
                'status' => 'invalid'
            );
        }
    }

    /**
     * Scheduled license verification.
     *
     * @since    1.0.0
     */
    public function verify_license_scheduled() {
        $license_key = get_option('rankolab_license_key', '');
        
        if (!empty($license_key)) {
            $this->verify_license($license_key);
        }
    }

    /**
     * AJAX handler for license verification.
     *
     * @since    1.0.0
     */
    public function ajax_verify_license() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_wizard_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get license key
        $license_key = isset($_POST['license_key']) ? sanitize_text_field($_POST['license_key']) : '';
        
        if (empty($license_key)) {
            wp_send_json_error('Please enter a license key.');
            return;
        }
        
        // Verify license
        $result = $this->verify_license($license_key);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * Check if the license is valid.
     *
     * @since    1.0.0
     * @return   boolean    True if the license is valid, false otherwise.
     */
    public function is_license_valid() {
        return $this->license_status === 'valid';
    }

    /**
     * Get the license key.
     *
     * @since    1.0.0
     * @return   string    The license key.
     */
    public function get_license_key() {
        return $this->license_key;
    }

    /**
     * Get the license status.
     *
     * @since    1.0.0
     * @return   string    The license status.
     */
    public function get_license_status() {
        return $this->license_status;
    }
}
