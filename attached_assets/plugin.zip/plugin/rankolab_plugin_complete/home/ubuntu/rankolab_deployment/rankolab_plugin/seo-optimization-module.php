<!-- Rankolab SEO Optimization Module Template -->
<div class="rankolab-seo-optimization-module" id="rankolab-seo-optimization">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>SEO Optimization</h2>
            <p>Analyze and optimize your website's SEO to improve search engine rankings.</p>
        </div>
    </div>
    
    <!-- SEO Analysis Form -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Run SEO Analysis</h3>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-form-group">
                <label for="rankolab-analysis-target" class="rankolab-form-label">Analysis Target</label>
                <select id="rankolab-analysis-target" class="rankolab-form-control">
                    <option value="entire-site" selected>Entire Website</option>
                    <option value="homepage">Homepage Only</option>
                    <option value="specific-page">Specific Page</option>
                    <option value="specific-post">Specific Post</option>
                </select>
            </div>
            
            <div class="rankolab-form-group" id="rankolab-specific-page-container" style="display: none;">
                <label for="rankolab-specific-page" class="rankolab-form-label">Select Page/Post</label>
                <select id="rankolab-specific-page" class="rankolab-form-control">
                    <?php if (!empty($pages_posts)): ?>
                        <?php foreach ($pages_posts as $item): ?>
                            <option value="<?php echo $item['id']; ?>"><?php echo $item['title']; ?> (<?php echo $item['type']; ?>)</option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="">No pages/posts found</option>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="rankolab-form-group">
                <label for="rankolab-analysis-depth" class="rankolab-form-label">Analysis Depth</label>
                <select id="rankolab-analysis-depth" class="rankolab-form-control">
                    <option value="basic">Basic Analysis</option>
                    <option value="standard" selected>Standard Analysis</option>
                    <option value="comprehensive">Comprehensive Analysis</option>
                </select>
                <small class="rankolab-form-text">Comprehensive analysis may take longer to complete</small>
            </div>
            
            <div class="rankolab-form-group">
                <div class="rankolab-form-check">
                    <input type="checkbox" id="rankolab-include-suggestions" class="rankolab-form-check-input" checked>
                    <label for="rankolab-include-suggestions" class="rankolab-form-check-label">Include Improvement Suggestions</label>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <div class="rankolab-form-check">
                    <input type="checkbox" id="rankolab-auto-fix" class="rankolab-form-check-input">
                    <label for="rankolab-auto-fix" class="rankolab-form-check-label">Auto-Fix Critical Issues</label>
                </div>
            </div>
            
            <div class="rankolab-text-right">
                <button id="rankolab-run-seo-analysis" class="rankolab-btn rankolab-btn-primary">
                    <i class="fas fa-search"></i> Run Analysis
                </button>
            </div>
        </div>
    </div>
    
    <!-- SEO Analysis Results -->
    <div id="rankolab-seo-analysis" class="rankolab-seo-analysis-results" style="display: none;">
        <!-- Overall Score -->
        <div class="rankolab-card rankolab-card-primary">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Overall SEO Score</h3>
                <div class="rankolab-card-actions">
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-export-analysis">
                        <i class="fas fa-download"></i> Export Report
                    </button>
                </div>
            </div>
            <div class="rankolab-card-body">
                <div class="rankolab-row">
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-seo-score">
                            <div class="rankolab-score-circle" style="--score-percentage: 78%;">
                                <div class="rankolab-score-value">78</div>
                            </div>
                            <div class="rankolab-score-label">Overall SEO Score</div>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-8">
                        <div class="rankolab-score-factors">
                            <!-- SEO factors will be populated dynamically -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Detailed Analysis -->
        <div class="rankolab-row">
            <!-- On-Page SEO -->
            <div class="rankolab-col rankolab-col-6">
                <div class="rankolab-card">
                    <div class="rankolab-card-header">
                        <h3 class="rankolab-card-title">On-Page SEO</h3>
                    </div>
                    <div class="rankolab-card-body">
                        <div class="rankolab-analysis-tabs">
                            <div class="rankolab-analysis-tab active" data-tab="content">Content</div>
                            <div class="rankolab-analysis-tab" data-tab="meta">Meta Tags</div>
                            <div class="rankolab-analysis-tab" data-tab="images">Images</div>
                            <div class="rankolab-analysis-tab" data-tab="structure">Structure</div>
                        </div>
                        
                        <div class="rankolab-analysis-content active" data-tab-id="content">
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon good"><i class="fas fa-check-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Content Length</div>
                                    <div class="rankolab-analysis-description">Your content length is good (1,245 words). Longer content tends to rank better.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon improvement"><i class="fas fa-exclamation-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Keyword Density</div>
                                    <div class="rankolab-analysis-description">Your primary keyword density is 1.2%. Consider increasing it slightly to 1.5-2.5%.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon good"><i class="fas fa-check-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Readability</div>
                                    <div class="rankolab-analysis-description">Your content has a good readability score (Flesch Reading Ease: 68.5).</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="rankolab-analysis-content" data-tab-id="meta" style="display: none;">
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon problem"><i class="fas fa-times-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Meta Title</div>
                                    <div class="rankolab-analysis-description">Your meta title is too long (72 characters). Keep it under 60 characters.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon good"><i class="fas fa-check-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Meta Description</div>
                                    <div class="rankolab-analysis-description">Your meta description is well-optimized (145 characters) and includes your target keyword.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon improvement"><i class="fas fa-exclamation-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Canonical URL</div>
                                    <div class="rankolab-analysis-description">Canonical URL is set, but it's not consistent across all pages.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="rankolab-analysis-content" data-tab-id="images" style="display: none;">
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon improvement"><i class="fas fa-exclamation-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Image Alt Text</div>
                                    <div class="rankolab-analysis-description">3 out of 8 images are missing alt text. Add descriptive alt text to all images.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon problem"><i class="fas fa-times-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Image Size</div>
                                    <div class="rankolab-analysis-description">2 images are too large (over 1MB). Compress your images to improve page load time.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon good"><i class="fas fa-check-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Image File Names</div>
                                    <div class="rankolab-analysis-description">Your image file names are descriptive and include keywords.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="rankolab-analysis-content" data-tab-id="structure" style="display: none;">
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon good"><i class="fas fa-check-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Heading Structure</div>
                                    <div class="rankolab-analysis-description">Your heading structure is well-organized with proper H1, H2, and H3 tags.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon good"><i class="fas fa-check-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">URL Structure</div>
                                    <div class="rankolab-analysis-description">Your URL is clean, descriptive, and includes your target keyword.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon improvement"><i class="fas fa-exclamation-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Internal Linking</div>
                                    <div class="rankolab-analysis-description">You have 4 internal links. Consider adding more internal links to related content.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Technical SEO -->
            <div class="rankolab-col rankolab-col-6">
                <div class="rankolab-card">
                    <div class="rankolab-card-header">
                        <h3 class="rankolab-card-title">Technical SEO</h3>
                    </div>
                    <div class="rankolab-card-body">
                        <div class="rankolab-analysis-tabs">
                            <div class="rankolab-analysis-tab active" data-tab="performance">Performance</div>
                            <div class="rankolab-analysis-tab" data-tab="mobile">Mobile</div>
                            <div class="rankolab-analysis-tab" data-tab="security">Security</div>
                            <div class="rankolab-analysis-tab" data-tab="indexing">Indexing</div>
                        </div>
                        
                        <div class="rankolab-analysis-content active" data-tab-id="performance">
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon improvement"><i class="fas fa-exclamation-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Page Speed</div>
                                    <div class="rankolab-analysis-description">Your page load time is 3.2 seconds. Aim for under 2 seconds for optimal performance.</div>
                                </div>
                            </div>
                            <div class="rankolab-analysis-item">
                                <div class="rankolab-analysis-icon problem"><i class="fas fa-times-circle"></i></div>
                                <div class="rankolab-analysis-text">
                                    <div class="rankolab-analysis-title">Render-Blocking Resources</div>
                                    <div class="rankolab-analysis-description">You have 5 render-blocking resources. Consider deferring or asynchronously loading these resources.</div>
                         
(Content truncated due to size limit. Use line ranges to read in chunks)