<?php
/**
 * The file that defines the dashboard module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The dashboard module class.
 *
 * This class handles the main dashboard functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Dashboard {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_get_dashboard_data', array($this, 'ajax_get_dashboard_data'));
        add_action('wp_ajax_rankolab_get_module_status', array($this, 'ajax_get_module_status'));
        add_action('wp_ajax_rankolab_update_dashboard_settings', array($this, 'ajax_update_dashboard_settings'));
        add_action('wp_ajax_rankolab_get_recent_activities', array($this, 'ajax_get_recent_activities'));
        add_action('wp_ajax_rankolab_get_system_status', array($this, 'ajax_get_system_status'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_dashboard_page'), 5);
        
        // Register settings
        add_action('admin_init', array($this, 'register_dashboard_settings'));
        
        // Add dashboard widgets
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widgets'));
        
        // Add admin bar menu
        add_action('admin_bar_menu', array($this, 'add_admin_bar_menu'), 999);
        
        // Add activity logging
        add_action('rankolab_log_activity', array($this, 'log_activity'), 10, 3);
        
        // Add scheduled tasks
        add_action('rankolab_daily_tasks', array($this, 'run_daily_tasks'));
        
        // Schedule daily tasks if not already scheduled
        if (!wp_next_scheduled('rankolab_daily_tasks')) {
            wp_schedule_event(time(), 'daily', 'rankolab_daily_tasks');
        }
    }

    /**
     * Add dashboard admin page.
     *
     * @since    1.0.0
     */
    public function add_dashboard_page() {
        add_menu_page(
            'Rankolab Dashboard',
            'Rankolab',
            'manage_options',
            'rankolab',
            array($this, 'display_dashboard_page'),
            'dashicons-chart-area',
            30
        );
        
        add_submenu_page(
            'rankolab',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'rankolab',
            array($this, 'display_dashboard_page')
        );
    }

    /**
     * Display dashboard admin page.
     *
     * @since    1.0.0
     */
    public function display_dashboard_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-dashboard.php';
    }

    /**
     * Register dashboard settings.
     *
     * @since    1.0.0
     */
    public function register_dashboard_settings() {
        register_setting('rankolab_dashboard_settings', 'rankolab_dashboard_settings');
        
        add_settings_section(
            'rankolab_dashboard_general',
            'General Settings',
            array($this, 'dashboard_general_section_callback'),
            'rankolab_dashboard_settings'
        );
        
        add_settings_field(
            'dashboard_layout',
            'Dashboard Layout',
            array($this, 'dashboard_layout_callback'),
            'rankolab_dashboard_settings',
            'rankolab_dashboard_general'
        );
        
        add_settings_field(
            'visible_widgets',
            'Visible Widgets',
            array($this, 'visible_widgets_callback'),
            'rankolab_dashboard_settings',
            'rankolab_dashboard_general'
        );
        
        add_settings_field(
            'default_date_range',
            'Default Date Range',
            array($this, 'default_date_range_callback'),
            'rankolab_dashboard_settings',
            'rankolab_dashboard_general'
        );
        
        add_settings_section(
            'rankolab_dashboard_notifications',
            'Notification Settings',
            array($this, 'dashboard_notifications_section_callback'),
            'rankolab_dashboard_settings'
        );
        
        add_settings_field(
            'enable_notifications',
            'Enable Notifications',
            array($this, 'enable_notifications_callback'),
            'rankolab_dashboard_settings',
            'rankolab_dashboard_notifications'
        );
        
        add_settings_field(
            'notification_types',
            'Notification Types',
            array($this, 'notification_types_callback'),
            'rankolab_dashboard_settings',
            'rankolab_dashboard_notifications'
        );
        
        add_settings_field(
            'notification_email',
            'Notification Email',
            array($this, 'notification_email_callback'),
            'rankolab_dashboard_settings',
            'rankolab_dashboard_notifications'
        );
    }

    /**
     * Dashboard general section callback.
     *
     * @since    1.0.0
     */
    public function dashboard_general_section_callback() {
        echo '<p>Configure general settings for the dashboard.</p>';
    }

    /**
     * Dashboard layout callback.
     *
     * @since    1.0.0
     */
    public function dashboard_layout_callback() {
        $options = get_option('rankolab_dashboard_settings');
        $layout = isset($options['dashboard_layout']) ? $options['dashboard_layout'] : 'grid';
        
        echo '<select name="rankolab_dashboard_settings[dashboard_layout]">';
        echo '<option value="grid" ' . selected($layout, 'grid', false) . '>Grid Layout</option>';
        echo '<option value="columns" ' . selected($layout, 'columns', false) . '>Column Layout</option>';
        echo '<option value="tabs" ' . selected($layout, 'tabs', false) . '>Tabbed Layout</option>';
        echo '</select>';
        echo '<p class="description">Select the layout style for the dashboard.</p>';
    }

    /**
     * Visible widgets callback.
     *
     * @since    1.0.0
     */
    public function visible_widgets_callback() {
        $options = get_option('rankolab_dashboard_settings');
        $visible_widgets = isset($options['visible_widgets']) ? $options['visible_widgets'] : array(
            'overview',
            'seo_score',
            'content_stats',
            'recent_activities',
            'system_status'
        );
        
        $available_widgets = array(
            'overview' => 'Overview',
            'seo_score' => 'SEO Score',
            'content_stats' => 'Content Statistics',
            'recent_activities' => 'Recent Activities',
            'system_status' => 'System Status',
            'traffic_stats' => 'Traffic Statistics',
            'keyword_rankings' => 'Keyword Rankings',
            'backlink_stats' => 'Backlink Statistics',
            'social_media_stats' => 'Social Media Statistics',
            'affiliate_stats' => 'Affiliate Statistics'
        );
        
        foreach ($available_widgets as $id => $label) {
            echo '<label>';
            echo '<input type="checkbox" name="rankolab_dashboard_settings[visible_widgets][]" value="' . $id . '" ' . checked(in_array($id, $visible_widgets), true, false) . '>';
            echo ' ' . $label;
            echo '</label><br>';
        }
        
        echo '<p class="description">Select which widgets to display on the dashboard.</p>';
    }

    /**
     * Default date range callback.
     *
     * @since    1.0.0
     */
    public function default_date_range_callback() {
        $options = get_option('rankolab_dashboard_settings');
        $date_range = isset($options['default_date_range']) ? $options['default_date_range'] : '30days';
        
        echo '<select name="rankolab_dashboard_settings[default_date_range]">';
        echo '<option value="7days" ' . selected($date_range, '7days', false) . '>Last 7 Days</option>';
        echo '<option value="30days" ' . selected($date_range, '30days', false) . '>Last 30 Days</option>';
        echo '<option value="90days" ' . selected($date_range, '90days', false) . '>Last 90 Days</option>';
        echo '<option value="year" ' . selected($date_range, 'year', false) . '>Last Year</option>';
        echo '</select>';
        echo '<p class="description">Select the default date range for dashboard statistics.</p>';
    }

    /**
     * Dashboard notifications section callback.
     *
     * @since    1.0.0
     */
    public function dashboard_notifications_section_callback() {
        echo '<p>Configure notification settings for the dashboard.</p>';
    }

    /**
     * Enable notifications callback.
     *
     * @since    1.0.0
     */
    public function enable_notifications_callback() {
        $options = get_option('rankolab_dashboard_settings');
        $enable_notifications = isset($options['enable_notifications']) ? $options['enable_notifications'] : 1;
        
        echo '<input type="checkbox" id="enable_notifications" name="rankolab_dashboard_settings[enable_notifications]" value="1" ' . checked(1, $enable_notifications, false) . '>';
        echo '<label for="enable_notifications">Enable dashboard notifications</label>';
    }

    /**
     * Notification types callback.
     *
     * @since    1.0.0
     */
    public function notification_types_callback() {
        $options = get_option('rankolab_dashboard_settings');
        $notification_types = isset($options['notification_types']) ? $options['notification_types'] : array(
            'system',
            'seo',
            'content',
            'security'
        );
        
        $available_types = array(
            'system' => 'System Notifications',
            'seo' => 'SEO Notifications',
            'content' => 'Content Notifications',
            'security' => 'Security Notifications',
            'performance' => 'Performance Notifications',
            'social' => 'Social Media Notifications',
            'affiliate' => 'Affiliate Notifications'
        );
        
        foreach ($available_types as $id => $label) {
            echo '<label>';
            echo '<input type="checkbox" name="rankolab_dashboard_settings[notification_types][]" value="' . $id . '" ' . checked(in_array($id, $notification_types), true, false) . '>';
            echo ' ' . $label;
            echo '</label><br>';
        }
        
        echo '<p class="description">Select which types of notifications to receive.</p>';
    }

    /**
     * Notification email callback.
     *
     * @since    1.0.0
     */
    public function notification_email_callback() {
        $options = get_option('rankolab_dashboard_settings');
        $email = isset($options['notification_email']) ? $options['notification_email'] : get_option('admin_email');
        
        echo '<input type="email" id="notification_email" name="rankolab_dashboard_settings[notification_email]" value="' . esc_attr($email) . '" class="regular-text">';
        echo '<p class="description">Email address to receive notifications.</p>';
    }

    /**
     * Add dashboard widgets to WordPress dashboard.
     *
     * @since    1.0.0
     */
    public function add_dashboard_widgets() {
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Add Rankolab overview widget
        wp_add_dashboard_widget(
            'rankolab_overview_widget',
            'Rankolab Overview',
            array($this, 'display_overview_widget')
        );
        
        // Add SEO score widget
        wp_add_dashboard_widget(
            'rankolab_seo_score_widget',
            'Rankolab SEO Score',
            array($this, 'display_seo_score_widget')
        );
    }

    /**
     * Display overview widget.
     *
     * @since    1.0.0
     */
    public function display_overview_widget() {
        // Get dashboard data
        $data = $this->get_dashboard_data();
        
        // Display widget content
        ?>
        <div class="rankolab-overview-widget">
            <div class="rankolab-widget-section">
                <h4><?php _e('System Status', 'rankolab'); ?></h4>
                <p>
                    <?php if ($data['license_status'] === 'active') : ?>
                        <span class="rankolab-status-active"><?php _e('License Active', 'rankolab'); ?></span>
                    <?php else : ?>
                        <span class="rankolab-status-inactive"><?php _e('License Inactive', 'rankolab'); ?></span>
                    <?php endif; ?>
                </p>
                <p>
                    <?php printf(__('Version: %s', 'rankolab'), $this->version); ?>
                </p>
            </div>
            
            <div class="rankolab-widget-section">
                <h4><?php _e('Quick Stats', 'rankolab'); ?></h4>
                <ul>
                    <li><?php printf(__('SEO Score: %s', 'rankolab'), $data['seo_score'] . '%'); ?></li>
                    <li><?php printf(__('Content Items: %s', 'rankolab'), $data['content_count']); ?></li>
                    <li><?php printf(__('Keywords Tracked: %s', 'rankolab'), $data['keyword_count']); ?></li>
                </ul>
            </div>
            
            <div class="rankolab-widget-section">
                <h4><?php _e('Recent Activities', 'rankolab'); ?></h4>
                <?php if (!empty($data['recent_activities'])) : ?>
                    <ul>
                        <?php foreach ($data['recent_activities'] as $activity) : ?>
                            <li>
                                <?php echo esc_html($activity['message']); ?>
                                <span class="rankolab-activity-time"><?php echo human_time_diff(strtotime($activity['time']), current_time('timestamp')); ?> <?php _e('ago', 'rankolab'); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p><?php _e('No recent activities.', 'rankolab'); ?></p>
                <?php endif; ?>
            </div>
            
            <p class="rankolab-widget-footer">
                <a href="<?php echo admin_url('admin.php?page=rankolab'); ?>"><?php _e('Go to Rankolab Dashboard', 'rankolab'); ?></a>
            </p>
        </div>
        <style>
            .rankolab-overview-widget {
                margin: -12px;
            }
            .rankolab-widget-section {
                padding: 12px;
                border-bottom: 1px solid #eee;
            }
            .rankolab-widget-section:last-child {
                border-bottom: none;
            }
            .rankolab-status-active {
                color: #46b450;
                font-weight: bold;
            }
            .rankolab-status-inactive {
                color: #dc3232;
                font-weight: bold;
            }
            .rankolab-activity-time {
                color: #999;
                font-size: 0.9em;
                margin-left: 5px;
            }
            .rankol
(Content truncated due to size limit. Use line ranges to read in chunks)