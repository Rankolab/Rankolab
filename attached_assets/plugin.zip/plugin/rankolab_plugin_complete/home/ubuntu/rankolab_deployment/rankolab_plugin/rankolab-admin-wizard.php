<?php
/**
 * Admin wizard page partial template
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin/partials
 */

// Get wizard instance
global $rankolab_setup_wizard;
$step = isset($_GET['step']) ? intval($_GET['step']) : 1;
$total_steps = $rankolab_setup_wizard->total_steps;
?>

<div class="wrap rankolab-wizard-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="rankolab-wizard-container">
        <div class="rankolab-wizard-header">
            <div class="rankolab-wizard-steps">
                <?php for ($i = 1; $i <= $total_steps; $i++) : ?>
                    <div class="rankolab-wizard-step <?php echo ($i == $step) ? 'active' : ''; ?> <?php echo ($i < $step) ? 'completed' : ''; ?>">
                        <div class="rankolab-wizard-step-number"><?php echo $i; ?></div>
                        <div class="rankolab-wizard-step-label">
                            <?php
                            switch ($i) {
                                case 1:
                                    echo 'Welcome';
                                    break;
                                case 2:
                                    echo 'License';
                                    break;
                                case 3:
                                    echo 'Subscription';
                                    break;
                                case 4:
                                    echo 'Website';
                                    break;
                                case 5:
                                    echo 'API';
                                    break;
                                case 6:
                                    echo 'Complete';
                                    break;
                            }
                            ?>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
        
        <div class="rankolab-wizard-content">
            <?php echo $rankolab_setup_wizard->get_step_content($step); ?>
        </div>
        
        <div class="rankolab-wizard-footer">
            <?php if ($step > 1) : ?>
                <button type="button" class="button rankolab-wizard-prev"><?php echo esc_html__('Previous', 'rankolab'); ?></button>
            <?php endif; ?>
            
            <?php if ($step < $total_steps) : ?>
                <button type="button" class="button button-primary rankolab-wizard-next"><?php echo esc_html__('Next', 'rankolab'); ?></button>
                <a href="<?php echo admin_url('admin.php?page=rankolab'); ?>" class="button rankolab-wizard-skip"><?php echo esc_html__('Skip', 'rankolab'); ?></a>
            <?php else : ?>
                <a href="<?php echo admin_url('admin.php?page=rankolab'); ?>" class="button button-primary"><?php echo esc_html__('Finish', 'rankolab'); ?></a>
            <?php endif; ?>
            
            <?php wp_nonce_field('rankolab_wizard_nonce', 'rankolab_wizard_nonce'); ?>
            <input type="hidden" id="rankolab_wizard_step" value="<?php echo $step; ?>" />
        </div>
    </div>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    // Next button click
    $('.rankolab-wizard-next').on('click', function() {
        var step = parseInt($('#rankolab_wizard_step').val());
        var nonce = $('#rankolab_wizard_nonce').val();
        
        // Collect step data
        var data = {
            action: 'rankolab_wizard_next_step',
            step: step,
            nonce: nonce
        };
        
        // Add step-specific data
        switch (step) {
            case 2:
                data.rankolab_license_key = $('#rankolab_license_key').val();
                break;
            case 3:
                data.rankolab_selected_plan = $('#rankolab_selected_plan').val();
                break;
            case 4:
                data.rankolab_website_url = $('#rankolab_website_url').val();
                data.rankolab_website_niche = $('#rankolab_website_niche').val();
                break;
        }
        
        // Send AJAX request
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: data,
            success: function(response) {
                if (response.success) {
                    // Update step
                    $('#rankolab_wizard_step').val(response.data.step);
                    
                    // Update content
                    $('.rankolab-wizard-content').html(response.data.content);
                    
                    // Update steps
                    $('.rankolab-wizard-step').removeClass('active completed');
                    for (var i = 1; i <= response.data.step; i++) {
                        if (i == response.data.step) {
                            $('.rankolab-wizard-step:nth-child(' + i + ')').addClass('active');
                        } else {
                            $('.rankolab-wizard-step:nth-child(' + i + ')').addClass('completed');
                        }
                    }
                    
                    // Update buttons
                    if (response.data.step > 1) {
                        $('.rankolab-wizard-prev').show();
                    } else {
                        $('.rankolab-wizard-prev').hide();
                    }
                    
                    if (response.data.step < <?php echo $total_steps; ?>) {
                        $('.rankolab-wizard-next').show();
                        $('.rankolab-wizard-skip').show();
                    } else {
                        $('.rankolab-wizard-next').hide();
                        $('.rankolab-wizard-skip').hide();
                    }
                } else {
                    alert(response.data);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            }
        });
    });
    
    // Previous button click
    $('.rankolab-wizard-prev').on('click', function() {
        var step = parseInt($('#rankolab_wizard_step').val());
        var nonce = $('#rankolab_wizard_nonce').val();
        
        // Send AJAX request
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'rankolab_wizard_prev_step',
                step: step,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    // Update step
                    $('#rankolab_wizard_step').val(response.data.step);
                    
                    // Update content
                    $('.rankolab-wizard-content').html(response.data.content);
                    
                    // Update steps
                    $('.rankolab-wizard-step').removeClass('active completed');
                    for (var i = 1; i <= response.data.step; i++) {
                        if (i == response.data.step) {
                            $('.rankolab-wizard-step:nth-child(' + i + ')').addClass('active');
                        } else {
                            $('.rankolab-wizard-step:nth-child(' + i + ')').addClass('completed');
                        }
                    }
                    
                    // Update buttons
                    if (response.data.step > 1) {
                        $('.rankolab-wizard-prev').show();
                    } else {
                        $('.rankolab-wizard-prev').hide();
                    }
                    
                    if (response.data.step < <?php echo $total_steps; ?>) {
                        $('.rankolab-wizard-next').show();
                        $('.rankolab-wizard-skip').show();
                    } else {
                        $('.rankolab-wizard-next').hide();
                        $('.rankolab-wizard-skip').hide();
                    }
                } else {
                    alert(response.data);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            }
        });
    });
    
    // Skip button click
    $('.rankolab-wizard-skip').on('click', function(e) {
        e.preventDefault();
        
        if (confirm('Are you sure you want to skip the setup wizard? You can access it later from the Settings page.')) {
            var nonce = $('#rankolab_wizard_nonce').val();
            
            // Send AJAX request
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'rankolab_wizard_skip',
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.data.redirect;
                    } else {
                        alert(response.data);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                }
            });
        }
    });
    
    // Plan selection
    $(document).on('click', '.rankolab-select-plan', function() {
        $('.rankolab-select-plan').removeClass('selected');
        $(this).addClass('selected');
        $('#rankolab_selected_plan').val($(this).data('plan'));
    });
    
    // API connection
    $(document).on('click', '.rankolab-connect-api', function() {
        var api = $(this).data('api');
        alert('Connecting to ' + api + ' API. This functionality will be implemented in the next update.');
        $(this).text('Connected').addClass('connected').prop('disabled', true);
    });
});
</script>

<style>
.rankolab-wizard-wrap {
    margin: 20px 0;
}

.rankolab-wizard-container {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    max-width: 800px;
    margin: 0 auto;
}

.rankolab-wizard-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
}

.rankolab-wizard-steps {
    display: flex;
    justify-content: space-between;
}

.rankolab-wizard-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 16.66%;
    position: relative;
}

.rankolab-wizard-step:not(:last-child):after {
    content: '';
    position: absolute;
    top: 15px;
    right: -50%;
    width: 100%;
    height: 2px;
    background: #ddd;
    z-index: 1;
}

.rankolab-wizard-step.completed:not(:last-child):after {
    background: #46b450;
}

.rankolab-wizard-step-number {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: #ddd;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-bottom: 5px;
    position: relative;
    z-index: 2;
}

.rankolab-wizard-step.active .rankolab-wizard-step-number {
    background: #0073aa;
}

.rankolab-wizard-step.completed .rankolab-wizard-step-number {
    background: #46b450;
}

.rankolab-wizard-step-label {
    font-size: 12px;
    text-align: center;
}

.rankolab-wizard-content {
    padding: 30px;
    min-height: 300px;
}

.rankolab-wizard-footer {
    padding: 20px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: space-between;
}

.rankolab-wizard-form-field {
    margin-bottom: 20px;
}

.rankolab-wizard-form-field label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.rankolab-wizard-video {
    margin: 20px 0;
    text-align: center;
}

.rankolab-wizard-video iframe {
    max-width: 100%;
}

.rankolab-wizard-plans {
    display: flex;
    gap: 20px;
    margin: 20px 0;
}

.rankolab-wizard-plan {
    flex: 1;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 20px;
    text-align: center;
    position: relative;
}

.rankolab-wizard-plan.recommended {
    border-color: #0073aa;
    box-shadow: 0 0 10px rgba(0,115,170,0.2);
}

.rankolab-wizard-plan-badge {
    position: absolute;
    top: -10px;
    right: -10px;
    background: #0073aa;
    color: #fff;
    padding: 5px 10px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
}

.rankolab-wizard-plan-price {
    font-size: 24px;
    font-weight: bold;
    margin: 10px 0 5px;
}

.rankolab-wizard-plan-duration {
    color: #666;
    margin-bottom: 15px;
}

.rankolab-wizard-plan ul {
    text-align: left;
    margin: 0 0 20px;
    padding: 0 0 0 20px;
}

.rankolab-wizard-plan ul li {
    margin-bottom: 5px;
}

.rankolab-select-plan.selected {
    background: #46b450;
    border-color: #46b450;
}

.rankolab-wizard-api-connections {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.rankolab-wizard-api-connection {
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 15px;
}

.rankolab-wizard-api-connection h3 {
    margin-top: 0;
}

.rankolab-connect-api.connected {
    background: #46b450;
    border-color: #46b450;
    color: #fff;
}

.rankolab-wizard-completion {
    text-align: center;
    padding: 20px 0;
}

.rankolab-wizard-completion-icon {
    font-size: 48px;
    color: #46b450;
    margin-bottom: 20px;
}

.rankolab-wizard-completion-icon .dashicons {
    font-size: 48px;
    width: 48px;
    height: 48px;
}

.rankolab-wizard-completion ul {
    text-align: left;
    display: inline-block;
    margin: 20px 0;
}

.rankolab-wizard-completion ul li {
    margin-bottom: 10px;
}

@media screen and (max-width: 782px) {
    .rankolab-wizard-step-label {
        display: none;
    }
    
    .rankolab-wizard-plans {
        flex-direction: column;
    }
}
</style>
