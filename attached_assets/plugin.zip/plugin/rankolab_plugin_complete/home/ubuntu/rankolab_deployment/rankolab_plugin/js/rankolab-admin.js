/**
 * Rankolab Main JavaScript
 * Provides interactive functionality for the Rankolab WordPress plugin
 * Version: 1.0.0
 */

(function($) {
    'use strict';

    // Global Rankolab object
    window.Rankolab = window.Rankolab || {};

    /**
     * Core functionality
     */
    Rankolab.Core = {
        init: function() {
            this.setupEventListeners();
            this.initComponents();
            this.checkLicenseStatus();
        },

        setupEventListeners: function() {
            // Toggle sidebar
            $('.rankolab-sidebar-toggle').on('click', function() {
                $('.rankolab-sidebar').toggleClass('collapsed');
                $('.rankolab-main-content').toggleClass('expanded');
            });

            // Tooltips
            this.initTooltips();

            // Tabs
            this.initTabs();

            // Modals
            this.initModals();

            // Collapsible sections
            this.initCollapsible();
        },

        initComponents: function() {
            // Initialize all modules
            Rankolab.Dashboard.init();
            Rankolab.SEO.init();
            Rankolab.Content.init();
            Rankolab.Analytics.init();
            Rankolab.Settings.init();
            Rankolab.AIAssistant.init();
        },

        initTooltips: function() {
            $('.rankolab-tooltip-trigger').hover(function() {
                var tooltip = $(this).find('.rankolab-tooltip');
                tooltip.addClass('show');
            }, function() {
                var tooltip = $(this).find('.rankolab-tooltip');
                tooltip.removeClass('show');
            });
        },

        initTabs: function() {
            $('.rankolab-tabs').each(function() {
                var $tabs = $(this);
                var $tabLinks = $tabs.find('.rankolab-tab-link');
                var $tabContents = $('.rankolab-tab-content[data-tab-group="' + $tabs.data('tab-group') + '"]');

                $tabLinks.on('click', function(e) {
                    e.preventDefault();
                    var target = $(this).data('tab-target');

                    // Update active tab
                    $tabLinks.removeClass('active');
                    $(this).addClass('active');

                    // Show target content
                    $tabContents.removeClass('active');
                    $('.rankolab-tab-content[data-tab-id="' + target + '"]').addClass('active');
                });
            });
        },

        initModals: function() {
            // Open modal
            $('.rankolab-modal-trigger').on('click', function(e) {
                e.preventDefault();
                var target = $(this).data('modal-target');
                $('#' + target).addClass('show');
                $('body').addClass('rankolab-modal-open');
            });

            // Close modal
            $('.rankolab-modal-close, .rankolab-modal-cancel').on('click', function(e) {
                e.preventDefault();
                $(this).closest('.rankolab-modal').removeClass('show');
                $('body').removeClass('rankolab-modal-open');
            });

            // Close when clicking outside
            $('.rankolab-modal').on('click', function(e) {
                if ($(e.target).hasClass('rankolab-modal')) {
                    $(this).removeClass('show');
                    $('body').removeClass('rankolab-modal-open');
                }
            });
        },

        initCollapsible: function() {
            $('.rankolab-collapsible-header').on('click', function() {
                $(this).parent().toggleClass('collapsed');
                $(this).next('.rankolab-collapsible-body').slideToggle(300);
            });
        },

        checkLicenseStatus: function() {
            $.ajax({
                url: rankolab_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'rankolab_check_license',
                    nonce: rankolab_params.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (!response.data.is_active) {
                            Rankolab.Core.showLicenseNotification();
                        }
                    }
                }
            });
        },

        showLicenseNotification: function() {
            var notification = $('<div class="rankolab-notification rankolab-notification-warning">' +
                '<div class="rankolab-notification-content">' +
                '<div class="rankolab-notification-title">License Inactive</div>' +
                '<div class="rankolab-notification-message">Your Rankolab license is inactive or has expired. Please activate your license to continue receiving updates and support.</div>' +
                '</div>' +
                '<div class="rankolab-notification-actions">' +
                '<a href="' + rankolab_params.license_url + '" class="rankolab-btn rankolab-btn-sm rankolab-btn-primary">Activate License</a>' +
                '<button class="rankolab-notification-close">&times;</button>' +
                '</div>' +
                '</div>');

            $('.rankolab-notifications-container').append(notification);

            // Close notification
            notification.find('.rankolab-notification-close').on('click', function() {
                notification.fadeOut(300, function() {
                    $(this).remove();
                });
            });
        },

        showNotification: function(type, title, message, autoClose) {
            var notification = $('<div class="rankolab-notification rankolab-notification-' + type + '">' +
                '<div class="rankolab-notification-content">' +
                '<div class="rankolab-notification-title">' + title + '</div>' +
                '<div class="rankolab-notification-message">' + message + '</div>' +
                '</div>' +
                '<div class="rankolab-notification-actions">' +
                '<button class="rankolab-notification-close">&times;</button>' +
                '</div>' +
                '</div>');

            $('.rankolab-notifications-container').append(notification);

            // Close notification
            notification.find('.rankolab-notification-close').on('click', function() {
                notification.fadeOut(300, function() {
                    $(this).remove();
                });
            });

            // Auto close if specified
            if (autoClose) {
                setTimeout(function() {
                    notification.fadeOut(300, function() {
                        $(this).remove();
                    });
                }, autoClose);
            }

            return notification;
        },

        confirmDialog: function(title, message, callback) {
            var modal = $('<div class="rankolab-modal">' +
                '<div class="rankolab-modal-dialog">' +
                '<div class="rankolab-modal-content">' +
                '<div class="rankolab-modal-header">' +
                '<h5 class="rankolab-modal-title">' + title + '</h5>' +
                '<button type="button" class="rankolab-modal-close">&times;</button>' +
                '</div>' +
                '<div class="rankolab-modal-body">' +
                '<p>' + message + '</p>' +
                '</div>' +
                '<div class="rankolab-modal-footer">' +
                '<button type="button" class="rankolab-btn rankolab-btn-secondary rankolab-modal-cancel">Cancel</button>' +
                '<button type="button" class="rankolab-btn rankolab-btn-primary rankolab-modal-confirm">Confirm</button>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>');

            $('body').append(modal);
            modal.addClass('show');
            $('body').addClass('rankolab-modal-open');

            // Close modal
            modal.find('.rankolab-modal-close, .rankolab-modal-cancel').on('click', function() {
                modal.removeClass('show');
                $('body').removeClass('rankolab-modal-open');
                setTimeout(function() {
                    modal.remove();
                }, 300);
            });

            // Confirm action
            modal.find('.rankolab-modal-confirm').on('click', function() {
                if (typeof callback === 'function') {
                    callback(true);
                }
                modal.removeClass('show');
                $('body').removeClass('rankolab-modal-open');
                setTimeout(function() {
                    modal.remove();
                }, 300);
            });

            // Close when clicking outside
            modal.on('click', function(e) {
                if ($(e.target).hasClass('rankolab-modal')) {
                    modal.removeClass('show');
                    $('body').removeClass('rankolab-modal-open');
                    setTimeout(function() {
                        modal.remove();
                    }, 300);
                }
            });
        }
    };

    /**
     * Dashboard functionality
     */
    Rankolab.Dashboard = {
        init: function() {
            this.loadDashboardData();
            this.setupEventListeners();
            this.initCharts();
        },

        setupEventListeners: function() {
            // Date range selector
            $('#rankolab-date-range').on('change', function() {
                Rankolab.Dashboard.loadDashboardData($(this).val());
            });

            // Refresh data
            $('.rankolab-refresh-data').on('click', function(e) {
                e.preventDefault();
                Rankolab.Dashboard.loadDashboardData();
            });
        },

        loadDashboardData: function(dateRange) {
            var loadingNotification = Rankolab.Core.showNotification('info', 'Loading Data', 'Fetching the latest dashboard data...', false);

            $.ajax({
                url: rankolab_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'rankolab_get_dashboard_data',
                    nonce: rankolab_params.nonce,
                    date_range: dateRange || $('#rankolab-date-range').val()
                },
                success: function(response) {
                    loadingNotification.fadeOut(300, function() {
                        $(this).remove();
                    });

                    if (response.success) {
                        Rankolab.Dashboard.updateDashboardUI(response.data);
                    } else {
                        Rankolab.Core.showNotification('error', 'Error', 'Failed to load dashboard data. Please try again.', 5000);
                    }
                },
                error: function() {
                    loadingNotification.fadeOut(300, function() {
                        $(this).remove();
                    });
                    Rankolab.Core.showNotification('error', 'Error', 'Failed to load dashboard data. Please try again.', 5000);
                }
            });
        },

        updateDashboardUI: function(data) {
            // Update stats
            $('.rankolab-stat-seo-score .rankolab-stat-value').text(data.seo_score);
            $('.rankolab-stat-content-count .rankolab-stat-value').text(data.content_count);
            $('.rankolab-stat-keyword-count .rankolab-stat-value').text(data.keyword_count);
            $('.rankolab-stat-traffic .rankolab-stat-value').text(data.traffic);

            // Update SEO score circle
            $('.rankolab-score-circle').css('--score-percentage', data.seo_score + '%');
            $('.rankolab-score-value').text(data.seo_score);

            // Update recent activities
            var activitiesList = $('.rankolab-recent-activities-list');
            activitiesList.empty();

            if (data.recent_activities && data.recent_activities.length > 0) {
                $.each(data.recent_activities, function(index, activity) {
                    var activityItem = $('<div class="rankolab-activity-item">' +
                        '<div class="rankolab-activity-icon"><i class="' + activity.icon + '"></i></div>' +
                        '<div class="rankolab-activity-content">' +
                        '<div class="rankolab-activity-message">' + activity.message + '</div>' +
                        '<div class="rankolab-activity-time">' + activity.time_ago + '</div>' +
                        '</div>' +
                        '</div>');
                    activitiesList.append(activityItem);
                });
            } else {
                activitiesList.append('<div class="rankolab-empty-state">No recent activities</div>');
            }

            // Update charts
            this.updateCharts(data);
        },

        initCharts: function() {
            // Initialize charts if Chart.js is available
            if (typeof Chart !== 'undefined') {
                // Traffic chart
                var trafficCtx = document.getElementById('rankolab-traffic-chart');
                if (trafficCtx) {
                    this.trafficChart = new Chart(trafficCtx, {
                        type: 'line',
                        data: {
                            labels: [],
                            datasets: [{
                                label: 'Traffic',
                                data: [],
                                borderColor: '#4a6bff',
                                backgroundColor: 'rgba(74, 107, 255, 0.1)',
                                borderWidth: 2,
                                tension: 0.4,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    mode: 'index',
                                    intersect: false
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                }

                // SEO progress chart
                var seoProgressCtx = document.getElementById('rankolab-seo-progress-chart');
                if (seoProgressCtx) {
                    this.seoProgressChart = new Chart(seoProgressCtx, {
                        type: 'radar',
                        data: {
                            labels: ['Content', 'Keywords', 'Meta Tags', 'Links', 'Performance', 'Mobile'],
                            datasets: [{
                                label: 'Current',
                                data: [0, 0, 0, 0, 0, 0],
                                backgroundColor: 'rgba(74, 107, 255, 0.2)',
                                borderColor: '#4a6bff',
                                borderWidth: 2,
                                pointBackgroundColor: '#4a6bff'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                r: {
                                    angleLines: {
                                        display: true
                                    },
                                    suggestedMin: 0,
                                    suggestedMax: 100
                   
(Content truncated due to size limit. Use line ranges to read in chunks)