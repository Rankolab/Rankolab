<!-- Rankolab Link Management Module Template -->
<div class="rankolab-link-management-module" id="rankolab-link-management">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Link Management</h2>
            <p>Manage, track, and optimize all your website links in one place.</p>
        </div>
    </div>
    
    <!-- Dashboard Overview -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Link Dashboard</h3>
            <div class="rankolab-card-actions">
                <div class="rankolab-form-group rankolab-mb-0">
                    <select id="rankolab-link-timeframe" class="rankolab-form-control rankolab-form-control-sm">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                        <option value="365">Last Year</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-link-metrics">
                <div class="rankolab-link-metric">
                    <div class="rankolab-link-metric-icon">
                        <i class="fas fa-link"></i>
                    </div>
                    <div class="rankolab-link-metric-value"><?php echo esc_html($total_links); ?></div>
                    <div class="rankolab-link-metric-label">Total Links</div>
                    <div class="rankolab-link-metric-change <?php echo $links_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $links_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($links_change)); ?>%
                    </div>
                </div>
                <div class="rankolab-link-metric">
                    <div class="rankolab-link-metric-icon">
                        <i class="fas fa-unlink"></i>
                    </div>
                    <div class="rankolab-link-metric-value"><?php echo esc_html($broken_links); ?></div>
                    <div class="rankolab-link-metric-label">Broken Links</div>
                    <div class="rankolab-link-metric-change <?php echo $broken_links_change <= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $broken_links_change <= 0 ? 'fa-arrow-down' : 'fa-arrow-up'; ?>"></i> <?php echo abs(esc_html($broken_links_change)); ?>%
                    </div>
                </div>
                <div class="rankolab-link-metric">
                    <div class="rankolab-link-metric-icon">
                        <i class="fas fa-mouse-pointer"></i>
                    </div>
                    <div class="rankolab-link-metric-value"><?php echo esc_html($total_clicks); ?></div>
                    <div class="rankolab-link-metric-label">Total Clicks</div>
                    <div class="rankolab-link-metric-change <?php echo $clicks_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $clicks_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($clicks_change)); ?>%
                    </div>
                </div>
                <div class="rankolab-link-metric">
                    <div class="rankolab-link-metric-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="rankolab-link-metric-value"><?php echo esc_html($ctr); ?>%</div>
                    <div class="rankolab-link-metric-label">Click-Through Rate</div>
                    <div class="rankolab-link-metric-change <?php echo $ctr_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $ctr_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($ctr_change)); ?>%
                    </div>
                </div>
            </div>
            
            <div class="rankolab-chart-container">
                <canvas id="rankolab-link-performance-chart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Link Management Tabs -->
    <div class="rankolab-tabs" data-tab-group="link-management">
        <div class="rankolab-tab-link active" data-tab-target="all-links">All Links</div>
        <div class="rankolab-tab-link" data-tab-target="broken-links">Broken Links</div>
        <div class="rankolab-tab-link" data-tab-target="redirects">Redirects</div>
        <div class="rankolab-tab-link" data-tab-target="analytics">Analytics</div>
        <div class="rankolab-tab-link" data-tab-target="settings">Settings</div>
    </div>
    
    <!-- All Links Tab -->
    <div class="rankolab-tab-content active" data-tab-group="link-management" data-tab-id="all-links">
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Manage Links</h3>
                <div class="rankolab-card-actions">
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-add-link">
                        <i class="fas fa-plus"></i> Add Link
                    </button>
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" id="rankolab-import-links">
                        <i class="fas fa-file-import"></i> Import
                    </button>
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" id="rankolab-export-links">
                        <i class="fas fa-file-export"></i> Export
                    </button>
                </div>
            </div>
            <div class="rankolab-card-body">
                <div class="rankolab-filters">
                    <div class="rankolab-row">
                        <div class="rankolab-col rankolab-col-4">
                            <div class="rankolab-form-group">
                                <input type="text" id="rankolab-link-search" class="rankolab-form-control" placeholder="Search links...">
                            </div>
                        </div>
                        <div class="rankolab-col rankolab-col-3">
                            <div class="rankolab-form-group">
                                <select id="rankolab-link-type-filter" class="rankolab-form-control">
                                    <option value="">All Link Types</option>
                                    <option value="internal">Internal</option>
                                    <option value="external">External</option>
                                    <option value="affiliate">Affiliate</option>
                                    <option value="redirect">Redirect</option>
                                </select>
                            </div>
                        </div>
                        <div class="rankolab-col rankolab-col-3">
                            <div class="rankolab-form-group">
                                <select id="rankolab-link-status-filter" class="rankolab-form-control">
                                    <option value="">All Statuses</option>
                                    <option value="active">Active</option>
                                    <option value="broken">Broken</option>
                                    <option value="redirected">Redirected</option>
                                </select>
                            </div>
                        </div>
                        <div class="rankolab-col rankolab-col-2">
                            <button id="rankolab-reset-link-filters" class="rankolab-btn rankolab-btn-outline-secondary rankolab-btn-block">
                                Reset
                            </button>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($links)): ?>
                    <div class="rankolab-table-responsive">
                        <table class="rankolab-table rankolab-table-hover">
                            <thead>
                                <tr>
                                    <th>
                                        <div class="rankolab-form-check">
                                            <input type="checkbox" id="rankolab-select-all-links" class="rankolab-form-check-input">
                                            <label for="rankolab-select-all-links" class="rankolab-form-check-label"></label>
                                        </div>
                                    </th>
                                    <th>URL</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Clicks</th>
                                    <th>Last Checked</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($links as $link): ?>
                                    <tr>
                                        <td>
                                            <div class="rankolab-form-check">
                                                <input type="checkbox" id="rankolab-link-<?php echo esc_attr($link['id']); ?>" class="rankolab-form-check-input rankolab-link-checkbox" data-link-id="<?php echo esc_attr($link['id']); ?>">
                                                <label for="rankolab-link-<?php echo esc_attr($link['id']); ?>" class="rankolab-form-check-label"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="rankolab-link-url">
                                                <div class="rankolab-link-title"><?php echo esc_html($link['title']); ?></div>
                                                <div class="rankolab-link-href">
                                                    <a href="<?php echo esc_url($link['url']); ?>" target="_blank"><?php echo esc_html($link['url']); ?></a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="rankolab-badge rankolab-badge-<?php echo esc_attr($link['type']); ?>">
                                                <?php echo ucfirst(esc_html($link['type'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="rankolab-status-indicator rankolab-status-<?php echo esc_attr($link['status']); ?>">
                                                <?php echo ucfirst(esc_html($link['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html($link['clicks']); ?></td>
                                        <td><?php echo esc_html($link['last_checked']); ?></td>
                                        <td>
                                            <div class="rankolab-btn-group">
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-check-link" data-link-id="<?php echo esc_attr($link['id']); ?>">
                                                    <i class="fas fa-sync-alt"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary rankolab-edit-link" data-link-id="<?php echo esc_attr($link['id']); ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger rankolab-delete-link" data-link-id="<?php echo esc_attr($link['id']); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="rankolab-bulk-actions">
                        <div class="rankolab-row">
                            <div class="rankolab-col rankolab-col-4">
                                <select id="rankolab-link-bulk-action" class="rankolab-form-control">
                                    <option value="">Bulk Actions</option>
                                    <option value="check">Check Status</option>
                                    <option value="nofollow">Add Nofollow</option>
                                    <option value="follow">Remove Nofollow</option>
                                    <option value="sponsored">Add Sponsored</option>
                                    <option value="ugc">Add UGC</option>
                                    <option value="delete">Delete</option>
                                </select>
                            </div>
                            <div class="rankolab-col rankolab-col-2">
                                <button id="rankolab-apply-bulk-action" class="rankolab-btn rankolab-btn-outline-primary rankolab-btn-block">
                                    Apply
                                </button>
                            </div>
                            <div class="rankolab-col rankolab-col-6">
                                <div class="rankolab-pagination">
                                    <div class="rankolab-pagination-info">
                                        Showing <?php echo esc_html($pagination['showing_start']); ?> to <?php echo esc_html($pagination['showing_end']); ?> of <?php echo esc_html($pagination['total']); ?> links
                                    </div>
                                    <div class="rankolab-pagination-controls">
                                        <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary <?php echo $pagination['current_page'] <= 1 ? 'disabled' : ''; ?>" <?php echo $pagination['current_page'] <= 1 ? 'disabled' : ''; ?> data-page="<?php echo esc_attr($pagination['current_page'] - 1); ?>">
                                            <i class="fas fa-chevron-left"></i> Previous
                                        </button>
                                        <span class="rankolab-pagination-pages">
                                            Page <?php echo esc_html($pagination['current_page']); ?> of <?php echo esc_html($pagination['total_pages']); ?>
                                        </span>
                                        <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary <?php echo $pagination['current_page'] >= $pagination['total_pages'] ? 'disabled' : ''; ?>" <?php echo $pagination['current_page'] >= $pagination['total_pages'] ? 'disabled' : ''; ?> data-page="<?php echo esc_attr($pagination['current_page'] + 1); ?>">
                                            Next <i class="fas fa-chevron-right"></i>
                                        </button>
       
(Content truncated due to size limit. Use line ranges to read in chunks)