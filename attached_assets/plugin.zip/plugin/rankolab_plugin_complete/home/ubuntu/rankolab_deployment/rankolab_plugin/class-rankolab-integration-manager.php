<?php
/**
 * Integration Manager Class for Rankolab
 *
 * This class manages all integration components between the WordPress plugin and the Rankolab backend website.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

class Rankolab_Integration_Manager {

    /**
     * The API integration instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_API_Integration    $api    The API integration instance.
     */
    private $api;

    /**
     * The user integration instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_User_Integration    $user    The user integration instance.
     */
    private $user;

    /**
     * The data sync instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_Data_Sync    $data_sync    The data sync instance.
     */
    private $data_sync;

    /**
     * The license integration instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_License_Integration    $license    The license integration instance.
     */
    private $license;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Initialize API integration
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rankolab-api-integration.php';
        $this->api = new Rankolab_API_Integration();
        
        // Initialize license integration
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rankolab-license-integration.php';
        $this->license = new Rankolab_License_Integration($this->api);
        
        // Initialize user integration
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rankolab-user-integration.php';
        $this->user = new Rankolab_User_Integration($this->api);
        
        // Initialize data sync
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-rankolab-data-sync.php';
        $this->data_sync = new Rankolab_Data_Sync($this->api);
        
        // Add hooks for integration management
        add_action('admin_init', array($this, 'check_integration_status'));
        add_action('rankolab_activate', array($this, 'initialize_integration'));
    }

    /**
     * Check the integration status.
     *
     * @since    1.0.0
     */
    public function check_integration_status() {
        // Check if integration is initialized
        $initialized = get_option('rankolab_integration_initialized', false);
        
        if (!$initialized) {
            // Initialize integration
            $this->initialize_integration();
        }
    }

    /**
     * Initialize the integration.
     *
     * @since    1.0.0
     */
    public function initialize_integration() {
        // Initialize data sync
        $this->data_sync->initialize_sync();
        
        // Mark integration as initialized
        update_option('rankolab_integration_initialized', true);
    }

    /**
     * Get the API integration instance.
     *
     * @since    1.0.0
     * @return   Rankolab_API_Integration    The API integration instance.
     */
    public function get_api() {
        return $this->api;
    }

    /**
     * Get the user integration instance.
     *
     * @since    1.0.0
     * @return   Rankolab_User_Integration    The user integration instance.
     */
    public function get_user() {
        return $this->user;
    }

    /**
     * Get the data sync instance.
     *
     * @since    1.0.0
     * @return   Rankolab_Data_Sync    The data sync instance.
     */
    public function get_data_sync() {
        return $this->data_sync;
    }

    /**
     * Get the license integration instance.
     *
     * @since    1.0.0
     * @return   Rankolab_License_Integration    The license integration instance.
     */
    public function get_license() {
        return $this->license;
    }

    /**
     * Check if the integration is properly configured.
     *
     * @since    1.0.0
     * @return   boolean    Whether the integration is properly configured.
     */
    public function is_integration_configured() {
        // Check if API key is set
        $api_key = get_option('rankolab_api_key', '');
        
        if (empty($api_key)) {
            return false;
        }
        
        // Check if license is valid
        if (!$this->license->is_license_valid()) {
            return false;
        }
        
        return true;
    }

    /**
     * Get the integration status.
     *
     * @since    1.0.0
     * @return   array    The integration status.
     */
    public function get_integration_status() {
        $status = array(
            'initialized' => get_option('rankolab_integration_initialized', false),
            'api_key' => !empty(get_option('rankolab_api_key', '')),
            'license_valid' => $this->license->is_license_valid(),
            'license_expired' => $this->license->is_license_expired(),
            'license_plan' => $this->license->get_license_plan(),
            'license_expiry' => $this->license->get_license_expiry(),
            'days_remaining' => $this->license->get_days_remaining(),
        );
        
        return $status;
    }

    /**
     * Reset the integration.
     *
     * @since    1.0.0
     */
    public function reset_integration() {
        // Deactivate license
        $this->license->deactivate_license();
        
        // Delete integration options
        delete_option('rankolab_integration_initialized');
        delete_option('rankolab_api_key');
        
        // Delete data options
        delete_option('rankolab_seo_data');
        delete_option('rankolab_content_templates');
        delete_option('rankolab_design_templates');
        delete_option('rankolab_monitoring_data');
        delete_option('rankolab_adsense_suggestions');
    }
}
