<?php
/**
 * Rankolab Enhanced Error Logging Module
 *
 * Provides centralized viewing and management of Rankolab-specific logs.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Your Name <your@email.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	 exit; // Exit if accessed directly
}

class Rankolab_Error_Logging {

	 private static $instance;
	 private $plugin_name;
	 private $version;
	 private $option_name = 'rankolab_logging_settings';
	 private static $log_dir_path;
	 private static $log_file_path;
	 private static $log_levels = array(
		 'DEBUG'   => 100,
		 'INFO'    => 200,
		 'WARNING' => 300,
		 'ERROR'   => 400,
	 );

	 /**
	  * Get singleton instance.
	  */
	 public static function get_instance( $plugin_name, $version ) {
		 if ( null === self::$instance ) {
			 self::$instance = new self( $plugin_name, $version );
		 }
		 return self::$instance;
	 }

	 /**
	  * Initialize the class and set its properties.
	  */
	 private function __construct( $plugin_name, $version ) {
		 $this->plugin_name = $plugin_name;
		 $this->version = $version;

		 $this->setup_log_paths();
		 $this->ensure_log_directory_exists();

		 // Add hooks
		 add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		 add_action( 'admin_init', array( $this, 'register_settings' ) );
		 add_action( 'wp_ajax_rankolab_clear_log', array( $this, 'handle_clear_log_ajax' ) );
		 add_action( 'admin_post_rankolab_download_log', array( $this, 'handle_download_log' ) ); // Use admin_post for downloads
	 }

	 /**
	  * Setup log directory and file paths.
	  */
	 private function setup_log_paths() {
		 $upload_dir = wp_upload_dir();
		 self::$log_dir_path = $upload_dir['basedir'] . '/rankolab-logs';
		 self::$log_file_path = self::$log_dir_path . '/rankolab-debug.log';
	 }

	 /**
	  * Ensure log directory exists and is protected.
	  */
	 private function ensure_log_directory_exists() {
		 if ( ! file_exists( self::$log_dir_path ) ) {
			 wp_mkdir_p( self::$log_dir_path );
		 }

		 // Add .htaccess file for security
		 $htaccess_file = self::$log_dir_path . '/.htaccess';
		 if ( ! file_exists( $htaccess_file ) ) {
			 $htaccess_content = 'deny from all';
			 @file_put_contents( $htaccess_file, $htaccess_content );
		 }

		 // Add index.php file for security
		 $index_file = self::$log_dir_path . '/index.php';
		 if ( ! file_exists( $index_file ) ) {
			 $index_content = '<?php // Silence is golden.';
			 @file_put_contents( $index_file, $index_content );
		 }
	 }

	 /**
	  * Add settings page to Rankolab menu.
	  */
	 public function add_settings_page() {
		 add_submenu_page(
			 'rankolab', // Parent slug
			 __( 'Error Logs', 'rankolab' ), // Page title
			 __( 'Logs', 'rankolab' ), // Menu title
			 'manage_options', // Capability
			 'rankolab-logs', // Menu slug
			 array( $this, 'display_settings_page' ) // Function
		 );
	 }

	 /**
	  * Register settings.
	  */
	 public function register_settings() {
		 register_setting( $this->option_name . '_group', $this->option_name, array( $this, 'sanitize_settings' ) );

		 add_settings_section(
			 'rankolab_logging_main_section',
			 __( 'Logging Settings', 'rankolab' ),
			 null,
			 $this->option_name . '_page'
		 );

		 add_settings_field(
			 'log_level',
			 __( 'Minimum Log Level', 'rankolab' ),
			 array( $this, 'render_log_level_field' ),
			 $this->option_name . '_page',
			 'rankolab_logging_main_section'
		 );
	 }

	 /**
	  * Sanitize settings before saving.
	  */
	 public function sanitize_settings( $input ) {
		 $sanitized_input = array();
		 $defaults = $this->get_default_settings();

		 $sanitized_input['log_level'] = isset( $input['log_level'] ) && array_key_exists( $input['log_level'], self::$log_levels ) ? sanitize_text_field( $input['log_level'] ) : $defaults['log_level'];

		 return $sanitized_input;
	 }

	 /**
	  * Get default settings.
	  */
	 private function get_default_settings() {
		 return array(
			 'log_level' => 'INFO',
		 );
	 }

	 /**
	  * Get current settings.
	  */
	 private function get_settings() {
		 return get_option( $this->option_name, $this->get_default_settings() );
	 }

	 /**
	  * Render log level dropdown field.
	  */
	 public function render_log_level_field() {
		 $options = $this->get_settings();
		 $current_level = isset( $options['log_level'] ) ? $options['log_level'] : 'INFO';

		 echo "<select name='{$this->option_name}[log_level]'>";
		 foreach ( self::$log_levels as $level => $code ) {
			 echo "<option value='" . esc_attr( $level ) . "' " . selected( $current_level, $level, false ) . ">" . esc_html( $level ) . "</option>";
		 }
		 echo "</select>";
		 echo "<p class='description'>" . __( 'Select the minimum level of messages to log. DEBUG logs everything.', 'rankolab' ) . "</p>";
	 }

	 /**
	  * Display the settings page.
	  */
	 public function display_settings_page() {
		 $log_content = $this->read_log_file();
		 $log_file_exists = file_exists( self::$log_file_path );
		 $log_file_size = $log_file_exists ? size_format( filesize( self::$log_file_path ), 2 ) : 'N/A';
		 ?>
		 <div class="wrap">
			 <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

			 <form action="options.php" method="post">
				 <?php
				 settings_fields( $this->option_name . '_group' );
				 do_settings_sections( $this->option_name . '_page' );
				 submit_button( __( 'Save Settings', 'rankolab' ) );
				 ?>
			 </form>

			 <h2><?php _e( 'Log Viewer', 'rankolab' ); ?></h2>
			 <p><?php printf( __( 'Log file path: %s', 'rankolab' ), '<code>' . esc_html( self::$log_file_path ) . '</code>' ); ?></p>
			 <p><?php printf( __( 'Log file size: %s', 'rankolab' ), '<strong>' . esc_html( $log_file_size ) . '</strong>' ); ?></p>

			 <textarea readonly="readonly" style="width: 100%; height: 400px; font-family: monospace; white-space: pre; overflow: scroll; background: #f1f1f1;"><?php echo esc_textarea( $log_content ); ?></textarea>

			 <p style="margin-top: 15px;">
				 <button id="rankolab-clear-log-btn" class="button button-secondary" <?php echo $log_file_exists ? '' : 'disabled'; ?>><?php _e( 'Clear Log File', 'rankolab' ); ?></button>
				 <a href="<?php echo esc_url( admin_url( 'admin-post.php?action=rankolab_download_log&_wpnonce=' . wp_create_nonce( 'rankolab_download_log_nonce' ) ) ); ?>" class="button button-secondary" <?php echo $log_file_exists ? '' : 'disabled'; ?>><?php _e( 'Download Log File', 'rankolab' ); ?></a>
				 <span id="rankolab-log-action-status" style="margin-left: 10px;"></span>
			 </p>

		 </div>
		 <script type="text/javascript">
			 jQuery(document).ready(function($) {
				 $('#rankolab-clear-log-btn').on('click', function(e) {
					 e.preventDefault();
					 if (!confirm('<?php echo esc_js( __( 'Are you sure you want to clear the log file? This action cannot be undone.', 'rankolab' ) ); ?>')) {
						 return;
					 }

					 var $button = $(this);
					 var $status = $('#rankolab-log-action-status');
					 $button.prop('disabled', true);
					 $status.text('<?php _e( 'Clearing...', 'rankolab' ); ?>').css('color', 'orange');

					 $.post(ajaxurl, {
						 action: 'rankolab_clear_log',
						 _ajax_nonce: '<?php echo wp_create_nonce( 'rankolab_clear_log_nonce' ); ?>'
					 }, function(response) {
						 if (response.success) {
							 $status.text('<?php _e( 'Log file cleared successfully!', 'rankolab' ); ?>').css('color', 'green');
							 $('textarea').val(''); // Clear the textarea
							 $button.prop('disabled', true); // Disable clear button after clearing
							 $('a.button-secondary').last().prop('disabled', true).attr('disabled', 'disabled'); // Disable download button
						 } else {
							 $status.text('<?php _e( 'Error clearing log file.', 'rankolab' ); ?>' + (response.data.message ? ' ' + response.data.message : '')).css('color', 'red');
							 $button.prop('disabled', false);
						 }
						 setTimeout(function(){ $status.text(''); }, 5000);
					 });
				 });
			 });
		 </script>
		 <?php
	 }

	 /**
	  * Read log file content (last N lines or limited size).
	  */
	 private function read_log_file( $lines = 500 ) {
		 if ( ! file_exists( self::$log_file_path ) || ! is_readable( self::$log_file_path ) ) {
			 return __( 'Log file does not exist or is not readable.', 'rankolab' );
		 }

		 // Simple approach: read the whole file if small, otherwise tail it.
		 // For very large files, a more robust tail function would be needed.
		 $filesize = filesize( self::$log_file_path );
		 if ( $filesize < 1024 * 1024 ) { // Less than 1MB, read all
			 $content = @file_get_contents( self::$log_file_path );
			 if ($content === false) {
				 return __( 'Error reading log file.', 'rankolab' );
			 }
			 $log_lines = explode("\n", trim($content));
			 $log_lines = array_reverse($log_lines);
			 $log_lines = array_slice($log_lines, 0, $lines);
			 return implode("\n", array_reverse($log_lines)); // Show latest first
		 } else {
			 // Basic tail implementation (may not be efficient for huge files)
			 $file_handle = @fopen( self::$log_file_path, 'r' );
			 if (!$file_handle) {
				 return __( 'Error opening log file for reading.', 'rankolab' );
			 }
			 $line_buffer = array();
			 $pos = -2;
			 $eof = false;
			 while ( count( $line_buffer ) < $lines && !$eof ) {
				 if ( fseek( $file_handle, $pos, SEEK_END ) === 0 ) {
					 $char = fgetc( $file_handle );
					 if ( $char === "\n" ) {
						 array_unshift( $line_buffer, fgets( $file_handle ) );
					 }
					 $pos--;
				 } else {
					 $eof = true;
					 fseek( $file_handle, 0, SEEK_SET ); // Go to beginning if reached start
					 array_unshift( $line_buffer, fgets( $file_handle ) ); // Add first line
				 }
			 }
			 fclose( $file_handle );
			 return implode( '', $line_buffer );
		 }
	 }

	 /**
	  * Handle AJAX request for clearing the log file.
	  */
	 public function handle_clear_log_ajax() {
		 check_ajax_referer( 'rankolab_clear_log_nonce' );

		 if ( ! current_user_can( 'manage_options' ) ) {
			 wp_send_json_error( array( 'message' => __( 'Permission denied.', 'rankolab' ) ) );
		 }

		 if ( file_exists( self::$log_file_path ) ) {
			 if ( @unlink( self::$log_file_path ) ) {
				 self::log( 'Log file cleared manually.', 'INFO' ); // Log the clearing action
				 wp_send_json_success();
			 } else {
				 wp_send_json_error( array( 'message' => __( 'Could not delete log file. Check permissions.', 'rankolab' ) ) );
			 }
		 } else {
			 wp_send_json_success(); // File doesn't exist, consider it cleared
		 }
	 }

	 /**
	  * Handle request to download the log file.
	  */
	 public function handle_download_log() {
		 if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'rankolab_download_log_nonce' ) ) {
			 wp_die( __( 'Invalid nonce.', 'rankolab' ) );
		 }

		 if ( ! current_user_can( 'manage_options' ) ) {
			 wp_die( __( 'Permission denied.', 'rankolab' ) );
		 }

		 if ( file_exists( self::$log_file_path ) && is_readable( self::$log_file_path ) ) {
			 header( 'Content-Description: File Transfer' );
			 header( 'Content-Type: text/plain' );
			 header( 'Content-Disposition: attachment; filename="' . basename( self::$log_file_path ) . '"' );
			 header( 'Expires: 0' );
			 header( 'Cache-Control: must-revalidate' );
			 header( 'Pragma: public' );
			 header( 'Content-Length: ' . filesize( self::$log_file_path ) );
			 readfile( self::$log_file_path );
			 exit;
		 } else {
			 wp_die( __( 'Log file not found or not readable.', 'rankolab' ) );
		 }
	 }

	 /**
	  * Static logging function.
	  *
	  * @param string $message The message to log.
	  * @param string $level   The log level (DEBUG, INFO, WARNING, ERROR).
	  */
	 public static function log( $message, $level = 'INFO' ) {
		 // Ensure paths are set if called statically before instantiation
		 if ( empty( self::$log_dir_path ) ) {
			 $upload_dir = wp_upload_dir();
			 self::$log_dir_path = $upload_dir['basedir'] . '/rankolab-logs';
			 self::$log_file_path = self::$log_dir_path . '/rankolab-debug.log';
			 // Attempt to create dir if not exists - best effort
			 if ( ! file_exists( self::$log_dir_path ) ) {
				 @wp_mkdir_p( self::$log_dir_path );
			 }
		 }

		 $settings = get_option( 'rankolab_logging_settings', array( 'log_level' => 'INFO' ) );
		 $min_level_setting = isset( $settings['log_level'] ) ? $settings['log_level'] : 'INFO';
		 $min_level_code = isset( self::$log_levels[$min_level_setting] ) ? self::$log_levels[$min_level_setting] : 200; // Default to INFO

		 $message_level_code = isset( self::$log_levels[$level] ) ? self::$log_levels[$level] : 200; // Default to INFO

		 // Only log if message level is equal to or higher than the minimum setting
		 if ( $message_level_code >= $min_level_code ) {
			 $timestamp = current_time( 'mysql' );
			 $log_entry = sprintf( "[%s] [%s]: %s\n", $timestamp, $level, $message );

			 // Use file_put_contents with append and lock
			 @file_put_contents( self::$log_file_path, $log_entry, FILE_APPEND | LOCK_EX );
		 }
	 }
}

// Instantiate the class
// Example: Rankolab_Error_Logging::get_instance( RANKOLAB_PLUGIN_NAME, RANKOLAB_VERSION );

