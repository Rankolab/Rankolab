<!-- Rankolab Website Monitoring Module Template -->
<div class="rankolab-website-monitoring-module" id="rankolab-website-monitoring">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Website Monitoring</h2>
            <p>Monitor your website's uptime, performance, security, and technical health.</p>
        </div>
    </div>
    
    <!-- Website Status Overview -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Website Status Overview</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-run-scan">
                    <i class="fas fa-sync-alt"></i> Run Full Scan
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-status-overview">
                <div class="rankolab-status-item">
                    <div class="rankolab-status-icon <?php echo $uptime_status === 'up' ? 'status-good' : 'status-error'; ?>">
                        <i class="fas <?php echo $uptime_status === 'up' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                    </div>
                    <div class="rankolab-status-details">
                        <div class="rankolab-status-title">Uptime</div>
                        <div class="rankolab-status-value"><?php echo esc_html($uptime_percentage); ?>%</div>
                        <div class="rankolab-status-description">Last 30 days</div>
                    </div>
                </div>
                <div class="rankolab-status-item">
                    <div class="rankolab-status-icon <?php echo $performance_status === 'good' ? 'status-good' : ($performance_status === 'warning' ? 'status-warning' : 'status-error'); ?>">
                        <i class="fas <?php echo $performance_status === 'good' ? 'fa-check-circle' : ($performance_status === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle'); ?>"></i>
                    </div>
                    <div class="rankolab-status-details">
                        <div class="rankolab-status-title">Performance</div>
                        <div class="rankolab-status-value"><?php echo esc_html($performance_score); ?>/100</div>
                        <div class="rankolab-status-description"><?php echo esc_html($load_time); ?> load time</div>
                    </div>
                </div>
                <div class="rankolab-status-item">
                    <div class="rankolab-status-icon <?php echo $security_status === 'secure' ? 'status-good' : ($security_status === 'warning' ? 'status-warning' : 'status-error'); ?>">
                        <i class="fas <?php echo $security_status === 'secure' ? 'fa-shield-alt' : ($security_status === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle'); ?>"></i>
                    </div>
                    <div class="rankolab-status-details">
                        <div class="rankolab-status-title">Security</div>
                        <div class="rankolab-status-value"><?php echo esc_html($security_issues); ?> issues</div>
                        <div class="rankolab-status-description"><?php echo $security_status === 'secure' ? 'No threats detected' : 'Action required'; ?></div>
                    </div>
                </div>
                <div class="rankolab-status-item">
                    <div class="rankolab-status-icon <?php echo $seo_status === 'good' ? 'status-good' : ($seo_status === 'warning' ? 'status-warning' : 'status-error'); ?>">
                        <i class="fas <?php echo $seo_status === 'good' ? 'fa-check-circle' : ($seo_status === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle'); ?>"></i>
                    </div>
                    <div class="rankolab-status-details">
                        <div class="rankolab-status-title">SEO Health</div>
                        <div class="rankolab-status-value"><?php echo esc_html($seo_score); ?>/100</div>
                        <div class="rankolab-status-description"><?php echo esc_html($seo_issues); ?> issues found</div>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-last-scan">
                Last scan: <?php echo esc_html($last_scan_time); ?> 
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-link" id="rankolab-scan-settings">
                    <i class="fas fa-cog"></i> Scan Settings
                </button>
            </div>
        </div>
    </div>
    
    <!-- Uptime Monitoring -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Uptime Monitoring</h3>
            <div class="rankolab-card-actions">
                <div class="rankolab-form-group rankolab-mb-0">
                    <select id="rankolab-uptime-timeframe" class="rankolab-form-control rankolab-form-control-sm">
                        <option value="24h">Last 24 Hours</option>
                        <option value="7d" selected>Last 7 Days</option>
                        <option value="30d">Last 30 Days</option>
                        <option value="90d">Last 90 Days</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-uptime-metrics">
                <div class="rankolab-uptime-metric">
                    <div class="rankolab-uptime-metric-value"><?php echo esc_html($uptime_percentage); ?>%</div>
                    <div class="rankolab-uptime-metric-label">Uptime</div>
                </div>
                <div class="rankolab-uptime-metric">
                    <div class="rankolab-uptime-metric-value"><?php echo esc_html($downtime_duration); ?></div>
                    <div class="rankolab-uptime-metric-label">Total Downtime</div>
                </div>
                <div class="rankolab-uptime-metric">
                    <div class="rankolab-uptime-metric-value"><?php echo esc_html($outage_count); ?></div>
                    <div class="rankolab-uptime-metric-label">Outages</div>
                </div>
                <div class="rankolab-uptime-metric">
                    <div class="rankolab-uptime-metric-value"><?php echo esc_html($avg_response_time); ?></div>
                    <div class="rankolab-uptime-metric-label">Avg. Response Time</div>
                </div>
            </div>
            
            <div class="rankolab-chart-container">
                <canvas id="rankolab-uptime-chart"></canvas>
            </div>
            
            <div class="rankolab-section-title">Recent Incidents</div>
            <?php if (!empty($incidents)): ?>
                <div class="rankolab-incidents">
                    <?php foreach ($incidents as $incident): ?>
                        <div class="rankolab-incident-item">
                            <div class="rankolab-incident-status <?php echo esc_attr($incident['status']); ?>">
                                <i class="fas <?php echo $incident['status'] === 'resolved' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                            </div>
                            <div class="rankolab-incident-details">
                                <div class="rankolab-incident-title"><?php echo esc_html($incident['title']); ?></div>
                                <div class="rankolab-incident-time">
                                    <span class="rankolab-incident-start"><?php echo esc_html($incident['start_time']); ?></span>
                                    <?php if ($incident['status'] === 'resolved'): ?>
                                        <span class="rankolab-incident-separator">to</span>
                                        <span class="rankolab-incident-end"><?php echo esc_html($incident['end_time']); ?></span>
                                        <span class="rankolab-incident-duration">(<?php echo esc_html($incident['duration']); ?>)</span>
                                    <?php else: ?>
                                        <span class="rankolab-incident-ongoing">Ongoing</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="rankolab-incident-actions">
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-incident-details-btn" data-incident-id="<?php echo esc_attr($incident['id']); ?>">
                                    Details
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="rankolab-empty-state rankolab-empty-state-small">
                    <div class="rankolab-empty-state-text">No incidents detected in the selected time period.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Performance Monitoring -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Performance Monitoring</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-run-performance-test">
                    <i class="fas fa-tachometer-alt"></i> Run Performance Test
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-performance-score">
                <div class="rankolab-score-circle <?php echo $performance_score >= 90 ? 'score-excellent' : ($performance_score >= 70 ? 'score-good' : ($performance_score >= 50 ? 'score-average' : 'score-poor')); ?>">
                    <div class="rankolab-score-value"><?php echo esc_html($performance_score); ?></div>
                    <div class="rankolab-score-label">Performance<br>Score</div>
                </div>
                <div class="rankolab-performance-metrics">
                    <div class="rankolab-performance-metric">
                        <div class="rankolab-performance-metric-label">First Contentful Paint</div>
                        <div class="rankolab-performance-metric-value"><?php echo esc_html($first_contentful_paint); ?></div>
                        <div class="rankolab-performance-metric-rating <?php echo $fcp_rating; ?>">
                            <?php echo ucfirst(esc_html($fcp_rating)); ?>
                        </div>
                    </div>
                    <div class="rankolab-performance-metric">
                        <div class="rankolab-performance-metric-label">Speed Index</div>
                        <div class="rankolab-performance-metric-value"><?php echo esc_html($speed_index); ?></div>
                        <div class="rankolab-performance-metric-rating <?php echo $si_rating; ?>">
                            <?php echo ucfirst(esc_html($si_rating)); ?>
                        </div>
                    </div>
                    <div class="rankolab-performance-metric">
                        <div class="rankolab-performance-metric-label">Largest Contentful Paint</div>
                        <div class="rankolab-performance-metric-value"><?php echo esc_html($largest_contentful_paint); ?></div>
                        <div class="rankolab-performance-metric-rating <?php echo $lcp_rating; ?>">
                            <?php echo ucfirst(esc_html($lcp_rating)); ?>
                        </div>
                    </div>
                    <div class="rankolab-performance-metric">
                        <div class="rankolab-performance-metric-label">Time to Interactive</div>
                        <div class="rankolab-performance-metric-value"><?php echo esc_html($time_to_interactive); ?></div>
                        <div class="rankolab-performance-metric-rating <?php echo $tti_rating; ?>">
                            <?php echo ucfirst(esc_html($tti_rating)); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-section-title">Performance History</div>
            <div class="rankolab-chart-container">
                <canvas id="rankolab-performance-history-chart"></canvas>
            </div>
            
            <div class="rankolab-section-title">Optimization Recommendations</div>
            <?php if (!empty($performance_recommendations)): ?>
                <div class="rankolab-recommendations">
                    <?php foreach ($performance_recommendations as $recommendation): ?>
                        <div class="rankolab-recommendation-item">
                            <div class="rankolab-recommendation-priority <?php echo esc_attr($recommendation['priority']); ?>">
                                <?php echo ucfirst(esc_html($recommendation['priority'])); ?>
                            </div>
                            <div class="rankolab-recommendation-details">
                                <div class="rankolab-recommendation-title"><?php echo esc_html($recommendation['title']); ?></div>
                                <div class="rankolab-recommendation-description"><?php echo esc_html($recommendation['description']); ?></div>
                            </div>
                            <div class="rankolab-recommendation-actions">
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-fix-recommendation" data-recommendation-id="<?php echo esc_attr($recommendation['id']); ?>">
                                    Fix Issue
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="rankolab-empty-state rankolab-empty-state-small">
                    <div class="rankolab-empty-state-text">No optimization recommendations available.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Security Monitoring -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Security Monitoring</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-run-security-scan">
                    <i class="fas fa-shield-alt"></i> Run Security Scan
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-security-overview">
                <div class="rankolab-security-score">
                    <div class="rankolab-score-circle <?php echo $security_score >= 90 ? 'score-excellent' : ($security_score >= 70 ? 'score-good' : ($security_score >= 50 ? 'score-average' : 'score-poor')); ?>">
                        <div class="rankolab-score-value"><?php echo esc_html($security_score); ?></div>
                        <div class="rankolab-score-label">Security<br>Score</div>
                    </div>
                </div>
                <div class="rankolab-security-metrics">
                    <div class="rankolab-security-metric">
                        <div class="rankolab-security-metric-icon <?php echo $critical_issues > 0 ? 'status-error' : 'status-good'; ?>">
                            <i class="fas <?php echo $critical_issues > 0 ? 'fa-exclamation-circle' : 'fa-check-circle'; ?>"></i>
                        </div>
        
(Content truncated due to size limit. Use line ranges to read in chunks)