<?php
/**
 * Admin dashboard partial template
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin/partials
 */
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="rankolab-dashboard-container">
        <div class="rankolab-dashboard-header">
            <h2>Welcome to Rankolab SEO & Content Suite</h2>
            <p>Your all-in-one solution for SEO optimization and content management.</p>
        </div>
        
        <div class="rankolab-dashboard-widgets">
            <div class="rankolab-widget">
                <h3>Website Performance</h3>
                <div class="rankolab-widget-content">
                    <p>Connect your website to view performance metrics.</p>
                    <a href="#" class="button button-primary">Connect Website</a>
                </div>
            </div>
            
            <div class="rankolab-widget">
                <h3>Content Status</h3>
                <div class="rankolab-widget-content">
                    <p>No content plans found. Create your first content plan.</p>
                    <a href="#" class="button button-primary">Create Content Plan</a>
                </div>
            </div>
            
            <div class="rankolab-widget">
                <h3>SEO Rankings</h3>
                <div class="rankolab-widget-content">
                    <p>Track your keyword rankings and SEO performance.</p>
                    <a href="#" class="button button-primary">Add Keywords</a>
                </div>
            </div>
            
            <div class="rankolab-widget">
                <h3>License Status</h3>
                <div class="rankolab-widget-content">
                    <p>Your license is: <span class="rankolab-license-inactive">Inactive</span></p>
                    <a href="?page=rankolab-license" class="button button-primary">Activate License</a>
                </div>
            </div>
        </div>
        
        <div class="rankolab-dashboard-footer">
            <p>Need help? <a href="https://rankolab.com/support" target="_blank">Contact Support</a> or view our <a href="https://rankolab.com/documentation" target="_blank">Documentation</a>.</p>
        </div>
    </div>
</div>
