<?php
/**
 * Rankolab Weekly Newsletter Module
 *
 * Handles automatic generation and sending of weekly email newsletters.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Your Name <your@email.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	 exit; // Exit if accessed directly
}

class Rankolab_Newsletter {

	 private static $instance;
	 private $plugin_name;
	 private $version;
	 private $option_name = 'rankolab_newsletter_settings';
	 private $cron_hook = 'rankolab_send_newsletter_cron';

	 /**
	  * Get singleton instance.
	  */
	 public static function get_instance( $plugin_name, $version ) {
		 if ( null === self::$instance ) {
			 self::$instance = new self( $plugin_name, $version );
		 }
		 return self::$instance;
	 }

	 /**
	  * Initialize the class and set its properties.
	  */
	 private function __construct( $plugin_name, $version ) {
		 $this->plugin_name = $plugin_name;
		 $this->version = $version;

		 // Add hooks
		 add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		 add_action( 'admin_init', array( $this, 'register_settings' ) );
		 add_action( 'wp_ajax_rankolab_send_test_newsletter', array( $this, 'handle_send_test_newsletter_ajax' ) );
		 add_action( $this->cron_hook, array( $this, 'send_newsletter' ) );

		 // Add custom cron schedules if needed (e.g., weekly)
		 add_filter( 'cron_schedules', array( $this, 'add_weekly_cron_schedule' ) );

		 // Schedule/Unschedule cron based on settings
		 $this->manage_cron_schedule();
	 }

	 /**
	  * Add settings page to Rankolab menu.
	  */
	 public function add_settings_page() {
		 add_submenu_page(
			 'rankolab', // Parent slug
			 __( 'Weekly Newsletter', 'rankolab' ), // Page title
			 __( 'Newsletter', 'rankolab' ), // Menu title
			 'manage_options', // Capability
			 'rankolab-newsletter', // Menu slug
			 array( $this, 'display_settings_page' ) // Function
		 );
	 }

	 /**
	  * Register settings.
	  */
	 public function register_settings() {
		 register_setting( $this->option_name . '_group', $this->option_name, array( $this, 'sanitize_settings' ) );

		 add_settings_section(
			 'rankolab_newsletter_main_section',
			 __( 'Newsletter Settings', 'rankolab' ),
			 null,
			 $this->option_name . '_page'
		 );

		 add_settings_field(
			 'enabled',
			 __( 'Enable Weekly Newsletter', 'rankolab' ),
			 array( $this, 'render_enabled_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'schedule_day',
			 __( 'Send On', 'rankolab' ),
			 array( $this, 'render_schedule_day_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'schedule_time',
			 __( 'Send At', 'rankolab' ),
			 array( $this, 'render_schedule_time_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'recipients',
			 __( 'Recipient Emails', 'rankolab' ),
			 array( $this, 'render_recipients_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'from_name',
			 __( 'From Name', 'rankolab' ),
			 array( $this, 'render_from_name_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'from_email',
			 __( 'From Email', 'rankolab' ),
			 array( $this, 'render_from_email_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'subject',
			 __( 'Email Subject', 'rankolab' ),
			 array( $this, 'render_subject_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'include_posts',
			 __( 'Include Recent Posts', 'rankolab' ),
			 array( $this, 'render_include_posts_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'post_count',
			 __( 'Number of Posts', 'rankolab' ),
			 array( $this, 'render_post_count_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );

		 add_settings_field(
			 'intro_text',
			 __( 'Custom Introduction', 'rankolab' ),
			 array( $this, 'render_intro_text_field' ),
			 $this->option_name . '_page',
			 'rankolab_newsletter_main_section'
		 );
	 }

	 /**
	  * Sanitize settings before saving.
	  */
	 public function sanitize_settings( $input ) {
		 $sanitized_input = array();
		 $defaults = $this->get_default_settings();

		 $sanitized_input['enabled'] = isset( $input['enabled'] ) ? 1 : 0;
		 $sanitized_input['schedule_day'] = isset( $input['schedule_day'] ) && in_array( $input['schedule_day'], range(0, 6) ) ? intval( $input['schedule_day'] ) : $defaults['schedule_day'];
		 $sanitized_input['schedule_time'] = isset( $input['schedule_time'] ) && preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $input['schedule_time']) ? sanitize_text_field( $input['schedule_time'] ) : $defaults['schedule_time'];
		 $sanitized_input['from_name'] = isset( $input['from_name'] ) ? sanitize_text_field( $input['from_name'] ) : $defaults['from_name'];
		 $sanitized_input['from_email'] = isset( $input['from_email'] ) && is_email( $input['from_email'] ) ? sanitize_email( $input['from_email'] ) : $defaults['from_email'];
		 $sanitized_input['subject'] = isset( $input['subject'] ) ? sanitize_text_field( $input['subject'] ) : $defaults['subject'];
		 $sanitized_input['include_posts'] = isset( $input['include_posts'] ) ? 1 : 0;
		 $sanitized_input['post_count'] = isset( $input['post_count'] ) ? absint( $input['post_count'] ) : $defaults['post_count'];
		 $sanitized_input['intro_text'] = isset( $input['intro_text'] ) ? wp_kses_post( $input['intro_text'] ) : $defaults['intro_text'];

		 // Sanitize recipients - one valid email per line
		 $recipients = array();
		 if ( isset( $input['recipients'] ) ) {
			 $lines = explode( "\n", $input['recipients'] );
			 foreach ( $lines as $line ) {
				 $email = sanitize_email( trim( $line ) );
				 if ( is_email( $email ) ) {
					 $recipients[] = $email;
				 }
			 }
		 }
		 $sanitized_input['recipients'] = implode( "\n", $recipients );

		 // Reschedule cron after saving settings
		 $this->manage_cron_schedule( $sanitized_input );

		 return $sanitized_input;
	 }

	 /**
	  * Get default settings.
	  */
	 private function get_default_settings() {
		 return array(
			 'enabled'       => 0,
			 'schedule_day'  => 1, // Monday
			 'schedule_time' => '09:00',
			 'recipients'    => get_option( 'admin_email' ),
			 'from_name'     => get_bloginfo( 'name' ),
			 'from_email'    => get_option( 'admin_email' ),
			 'subject'       => sprintf( __( 'Weekly Update from %s', 'rankolab' ), get_bloginfo( 'name' ) ),
			 'include_posts' => 1,
			 'post_count'    => 5,
			 'intro_text'    => __( '<p>Here is your weekly update!</p>', 'rankolab' ),
		 );
	 }

	 /**
	  * Get current settings.
	  */
	 private function get_settings() {
		 return get_option( $this->option_name, $this->get_default_settings() );
	 }

	 // --- Render Settings Fields --- (Implementations for each field)

	 public function render_enabled_field() {
		 $options = $this->get_settings();
		 $checked = isset( $options['enabled'] ) && $options['enabled'] ? 'checked' : '';
		 echo "<input type='checkbox' name='{$this->option_name}[enabled]' value='1' {$checked} />";
		 echo "<p class='description'>" . __( 'Enable the automatic weekly newsletter.', 'rankolab' ) . "</p>";
	 }

	 public function render_schedule_day_field() {
		 $options = $this->get_settings();
		 $current_day = isset( $options['schedule_day'] ) ? $options['schedule_day'] : 1;
		 $days = array( 
			 0 => __( 'Sunday', 'rankolab' ), 
			 1 => __( 'Monday', 'rankolab' ), 
			 2 => __( 'Tuesday', 'rankolab' ), 
			 3 => __( 'Wednesday', 'rankolab' ), 
			 4 => __( 'Thursday', 'rankolab' ), 
			 5 => __( 'Friday', 'rankolab' ), 
			 6 => __( 'Saturday', 'rankolab' ) 
		 );
		 echo "<select name='{$this->option_name}[schedule_day]'>";
		 foreach ( $days as $value => $label ) {
			 echo "<option value='" . esc_attr( $value ) . "' " . selected( $current_day, $value, false ) . ">" . esc_html( $label ) . "</option>";
		 }
		 echo "</select>";
	 }

	 public function render_schedule_time_field() {
		 $options = $this->get_settings();
		 $current_time = isset( $options['schedule_time'] ) ? $options['schedule_time'] : '09:00';
		 echo "<input type='time' name='{$this->option_name}[schedule_time]' value='" . esc_attr( $current_time ) . "' />";
		 echo "<p class='description'>" . sprintf( __( 'Time based on your WordPress timezone setting (%s).', 'rankolab' ), wp_timezone_string() ) . "</p>";
	 }

	 public function render_recipients_field() {
		 $options = $this->get_settings();
		 $recipients = isset( $options['recipients'] ) ? $options['recipients'] : '';
		 echo "<textarea name='{$this->option_name}[recipients]' rows='5' cols='50' class='large-text code'>" . esc_textarea( $recipients ) . "</textarea>";
		 echo "<p class='description'>" . __( 'Enter recipient email addresses, one per line.', 'rankolab' ) . "</p>";
	 }

	 public function render_from_name_field() {
		 $options = $this->get_settings();
		 $from_name = isset( $options['from_name'] ) ? $options['from_name'] : '';
		 echo "<input type='text' name='{$this->option_name}[from_name]' value='" . esc_attr( $from_name ) . "' class='regular-text' />";
	 }

	 public function render_from_email_field() {
		 $options = $this->get_settings();
		 $from_email = isset( $options['from_email'] ) ? $options['from_email'] : '';
		 echo "<input type='email' name='{$this->option_name}[from_email]' value='" . esc_attr( $from_email ) . "' class='regular-text' />";
	 }

	 public function render_subject_field() {
		 $options = $this->get_settings();
		 $subject = isset( $options['subject'] ) ? $options['subject'] : '';
		 echo "<input type='text' name='{$this->option_name}[subject]' value='" . esc_attr( $subject ) . "' class='large-text' />";
	 }

	 public function render_include_posts_field() {
		 $options = $this->get_settings();
		 $checked = isset( $options['include_posts'] ) && $options['include_posts'] ? 'checked' : '';
		 echo "<input type='checkbox' name='{$this->option_name}[include_posts]' value='1' {$checked} />";
		 echo "<p class='description'>" . __( 'Include a list of recent posts in the newsletter.', 'rankolab' ) . "</p>";
	 }

	 public function render_post_count_field() {
		 $options = $this->get_settings();
		 $post_count = isset( $options['post_count'] ) ? $options['post_count'] : 5;
		 echo "<input type='number' name='{$this->option_name}[post_count]' value='" . esc_attr( $post_count ) . "' min='1' max='20' class='small-text' />";
		 echo "<p class='description'>" . __( 'Number of recent posts to include (if enabled).', 'rankolab' ) . "</p>";
	 }

	 public function render_intro_text_field() {
		 $options = $this->get_settings();
		 $intro_text = isset( $options['intro_text'] ) ? $options['intro_text'] : '';
		 wp_editor( $intro_text, 'rankolab_newsletter_intro_text', array(
			 'textarea_name' => $this->option_name . '[intro_text]',
			 'media_buttons' => false,
			 'textarea_rows' => 5,
			 'teeny' => true
		 ) );
		 echo "<p class='description'>" . __( 'Custom text to appear at the beginning of the newsletter.', 'rankolab' ) . "</p>";
	 }

	 /**
	  * Display the settings page.
	  */
	 public function display_settings_page() {
		 $next_scheduled = wp_next_scheduled( $this->cron_hook );
		 $last_sent = get_option( 'rankolab_newsletter_last_sent', __( 'Never', 'rankolab' ) );
		 ?>
		 <div class="wrap">
			 <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			 <form action="options.php" method="post">
				 <?php
				 settings_fields( $this->option_name . '_group' );
				 do_settings_sections( $this->option_name . '_page' );
				 submit_button( __( 'Save Settings', 'rankolab' ) );
				 ?>
			 </form>

			 <h2><?php _e( 'Status & Testing', 'rankolab' ); ?></h2>
			 <p>
				 <?php _e( 'Next Scheduled Send:', 'rankolab' ); ?> 
				 <strong><?php echo $next_scheduled ? esc_html( get_date_from_gmt( date( 'Y-m-d H:i:s', $next_scheduled ), 'Y-m-d H:i:s' ) ) : __( 'Not Scheduled', 'rankolab' ); ?></strong>
			 </p>
			 <p>
				 <?php _e( 'Last Sent:', 'rankolab' ); ?> 
				 <strong><?php echo esc_html( $last_sent ); ?></strong>
			 </p>

			 <h3><?php _e( 'Send Test Newsletter', 'rankolab' ); ?></h3>
			 <p><?php _e( 'Send a test email to preview the newsletter content.', 'rankolab' ); ?></p>
			 <label for="rankolab-test-email"><?php _e( 'Test Email Address:', 'rankolab' ); ?></label>
			 <input type="email" id="rankolab-test-email" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" class="regular-text" />
			 <button id="rankolab-send-test-btn" class="button button-secondary"><?php _e( 'Send Test', 'rankolab' ); ?></button>
			 <span id="rankolab-test-send-status" style="margin-left: 10px;"></span>
		 </div>
		 <script type="text/javascript">
			 jQuery(document).ready(function($) {
				 $('#rankolab-send-test-btn').on('click', function(e) {
					 e.preventDefault();
					 var $button = $(this);
					 var $status = $('#rankolab-test-send-status');
					 var testEmail = $('#rankolab-test-email').val();

					 if (!testEmail) {
						 $status.text('<?php _e( 'Please enter a test email address.', 'rankolab' ); ?>').css('color', 'red');
						 return;
					 }

					 $button.prop('disabled', true);
					 $status.text('<?php _e( 'Sending...', 'rankolab' ); ?>').css('color', 'orange');

					 $.post(ajaxurl, {
						 action: 'rankolab_send_test_newsletter',
						 _ajax_nonce: '<?php echo wp_create_nonce( 'rankolab_send_test_newsletter_nonce' ); ?>',
						 test_email: testEmail
					 }, function(response) {
						 if (response.success) {
							 $status.text('<?php _e( 'Test email sent successfully!', 'rankolab' ); ?>').css('color', 'green');
						 } else {
							 $status.text('<?php _e( 'Error sending test email.', 'rankolab' ); ?>' + (response.data.message ? ' ' + response.data.message : '')).css('color', 'red');
						 }
						 $button.prop('disabled', false);
						 setTimeout(function(){ $status.text(''); }, 5000);
					 });
				 });
			 });
		 </script>
		 <?php
	 }

	 /**
	  * Handle AJAX request for sending a test newsletter.
	  */
	 public function handle_send_test_newsletter_ajax() {
		 check_ajax_referer( 'rankolab_send_test_newsletter_nonce' );

		 if ( ! current_user_can( 'manage_options' ) ) {
			 wp_send_json_error( array( 'message' => __( 'Permission denied.', 'rankolab' ) ) );
		 }

		 $test_email = isset( $_POST['test_email'] ) ? sanitize_email( $_POST['test_email'] ) : '';

		 if ( ! is_email( $test_email ) ) {
			 wp_send_json_error( array( 'message' => __( 'Invalid test email address.', 'rankolab' ) ) );
		 }

		 $settings = $this->get_settings();
		 $subject = '[TEST] ' . $settings['subject'];
		 $content = $this->generate_newsletter_content( $settings );
		 $headers = $this->get_email_headers( $settings );

		 $sent = wp_mail( $test_email, $subject, $content, $headers );

		 if ( $sent ) {
			 wp_send_json_success();
		 } else {
			 global $ts_mail_errors;
			 $error_message = !empty($ts_mail_errors) ? implode(', ', $ts_mail_errors) : __( 'Unknown mail error.', 'rankolab' );
			 // Rankolab_Error_Logging::log( 'Test Newsletter Send Error: ' . $error_message ); // Optional logging
			 wp_send_json_error( array( 'message' => $error_message ) );
		 }
	 }

	 /**
	  * Generate the HTML content for the newsletter.
	  */
	 private function generate_newsletter_content( $settings ) {
		 $content = '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="font-family: sans-serif;">';
		 $content .= wpautop( $settings['intro_text'] ); // Use wpautop for paragraph formatting

		 if ( $settings['include_posts'] && $settings['post_count'] > 0 ) {
			 $args = array(
				 'numberposts' => $settings['post_count'],
				 'post_status' => 'publish',
				 'orderby'     => 'date',
				 'order'       => 'DESC',
			 );
			 $recent_posts = wp_get_recent_posts( $args, OBJECT );

			 if ( $recent_posts ) {
				 $content .= '<h2>' . __( 'Recent Posts', 'rankolab' ) . '</h2>';
				 $content .= '<ul>';
				 foreach ( $recent_posts as $post ) {
					 $content .= '<li>';
					 $content .= '<h3><a href="' . esc_url( get_permalink( $post->ID ) ) . '">' . esc_html( $post->post_title ) . '</a></h3>';
					 $excerpt = has_excerpt( $post->ID ) ? $post->post_excerpt : wp_trim_words( $post->post_content, 55, '...' );
					 $content .= '<p>' . esc_html( $excerpt ) . '</p>';
					 $content .= '</li>';
				 }
				 $content .= '</ul>';
			 }
		 }

		 $content .= '<hr><p style="font-size: small; color: #888;">' . sprintf( __( 'This email was sent from %s.', 'rankolab' ), get_bloginfo( 'name' ) ) . '</p>';
		 $content .= '</body></html>';

		 return $content;
	 }

	 /**
	  * Get email headers.
	  */
	 private function get_email_headers( $settings ) {
		 $headers = array();
		 $headers[] = 'Content-Type: text/html; charset=UTF-8';
		 $from_name = $settings['from_name'];
		 $from_email = $settings['from_email'];
		 if ( $from_name && $from_email ) {
			 $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
		 }
		 return $headers;
	 }

	 /**
	  * Send the newsletter via WP-Cron.
	  */
	 public function send_newsletter() {
		 $settings = $this->get_settings();

		 // Double-check if enabled, might have been disabled since scheduling
		 if ( ! $settings['enabled'] ) {
			 return;
		 }

		 $recipients_str = $settings['recipients'];
		 if ( empty( $recipients_str ) ) {
			 // Rankolab_Error_Logging::log( 'Newsletter Error: No recipients configured.' ); // Optional logging
			 return;
		 }

		 $recipients = array_map( 'trim', explode( "\n", $recipients_str ) );
		 $valid_recipients = array_filter( $recipients, 'is_email' );

		 if ( empty( $valid_recipients ) ) {
			 // Rankolab_Error_Logging::log( 'Newsletter Error: No valid recipients found.' ); // Optional logging
			 return;
		 }

		 $subject = $settings['subject'];
		 $content = $this->generate_newsletter_content( $settings );
		 $headers = $this->get_email_headers( $settings );

		 // Use BCC to send to multiple recipients without exposing addresses
		 $bcc_headers = $headers;
		 $bcc_headers[] = 'Bcc: ' . implode( ',', $valid_recipients );

		 // Send to the first recipient directly, others via BCC
		 $sent = wp_mail( $valid_recipients[0], $subject, $content, $bcc_headers );

		 if ( $sent ) {
			 update_option( 'rankolab_newsletter_last_sent', current_time( 'mysql' ) );
			 // Rankolab_Error_Logging::log( 'Weekly newsletter sent successfully to ' . count($valid_recipients) . ' recipients.' ); // Optional logging
		 } else {
			 global $ts_mail_errors;
			 $error_message = !empty($ts_mail_errors) ? implode(', ', $ts_mail_errors) : __( 'Unknown mail error during scheduled send.', 'rankolab' );
			 // Rankolab_Error_Logging::log( 'Newsletter Send Error: ' . $error_message ); // Optional logging
		 }
	 }

	 /**
	  * Add custom weekly cron schedule.
	  */
	 public function add_weekly_cron_schedule( $schedules ) {
		 if ( ! isset( $schedules['weekly'] ) ) {
			 $schedules['weekly'] = array(
				 'interval' => 604800, // 7 days in seconds
				 'display'  => __( 'Once Weekly', 'rankolab' )
			 );
		 }
		 return $schedules;
	 }

	 /**
	  * Manage WP-Cron scheduling based on settings.
	  */
	 private function manage_cron_schedule( $settings = null ) {
		 if ( $settings === null ) {
			 $settings = $this->get_settings();
		 }

		 $timestamp = wp_next_scheduled( $this->cron_hook );

		 // Clear existing schedule first
		 if ( $timestamp ) {
			 wp_clear_scheduled_hook( $this->cron_hook );
		 }

		 // Schedule if enabled
		 if ( isset( $settings['enabled'] ) && $settings['enabled'] ) {
			 $day_of_week = $settings['schedule_day']; // 0 (Sun) to 6 (Sat)
			 $time_str = $settings['schedule_time']; // HH:MM
			 list( $hour, $minute ) = explode( ':', $time_str );

			 // Calculate the timestamp for the next occurrence in the site's timezone
			 $timezone = wp_timezone();
			 $now = new DateTime( 'now', $timezone );
			 $next_run = new DateTime( 'now', $timezone );
			 $next_run->setTime( (int)$hour, (int)$minute, 0 );

			 // Find the next desired day of the week
			 $current_day_of_week = (int)$now->format('w');
			 $days_diff = $day_of_week - $current_day_of_week;

			 if ( $days_diff < 0 || ( $days_diff == 0 && $now > $next_run ) ) {
				 // If the target day is earlier in the week OR it's today but the time has passed, schedule for next week
				 $days_diff += 7;
			 }

			 if ( $days_diff > 0 ) {
				 $next_run->modify( '+' . $days_diff . ' days' );
			 }

			 // Convert to UTC timestamp for scheduling
			 $schedule_timestamp = $next_run->getTimestamp();

			 wp_schedule_event( $schedule_timestamp, 'weekly', $this->cron_hook );
		 }
	 }
}

// Instantiate the class
// Example: Rankolab_Newsletter::get_instance( RANKOLAB_PLUGIN_NAME, RANKOLAB_VERSION );

