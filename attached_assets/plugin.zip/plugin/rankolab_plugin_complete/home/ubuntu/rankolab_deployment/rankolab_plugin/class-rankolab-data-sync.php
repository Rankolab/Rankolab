<?php
/**
 * Data Synchronization Class for Rankolab
 *
 * This class handles data synchronization between the WordPress plugin and the Rankolab backend website.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

class Rankolab_Data_Sync {

    /**
     * The API integration instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_API_Integration    $api    The API integration instance.
     */
    private $api;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    Rankolab_API_Integration    $api    The API integration instance.
     */
    public function __construct($api) {
        $this->api = $api;
        
        // Add hooks for data synchronization
        add_action('save_post', array($this, 'sync_post_data'), 10, 3);
        add_action('rankolab_sync_data', array($this, 'scheduled_sync'));
        
        // Schedule regular data synchronization
        if (!wp_next_scheduled('rankolab_sync_data')) {
            wp_schedule_event(time(), 'hourly', 'rankolab_sync_data');
        }
    }

    /**
     * Sync post data with the backend.
     *
     * @since    1.0.0
     * @param    int       $post_id    The post ID.
     * @param    WP_Post   $post       The post object.
     * @param    boolean   $update     Whether this is an update.
     */
    public function sync_post_data($post_id, $post, $update) {
        // Don't sync revisions or auto-saves
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        
        // Only sync published posts
        if ($post->post_status !== 'publish') {
            return;
        }
        
        // Get post meta data
        $seo_data = get_post_meta($post_id, '_rankolab_seo_data', true);
        $content_data = get_post_meta($post_id, '_rankolab_content_data', true);
        
        // Prepare data for sync
        $data = array(
            'post_id' => $post_id,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'url' => get_permalink($post_id),
            'post_type' => $post->post_type,
            'post_date' => $post->post_date,
            'modified_date' => $post->post_modified,
            'author' => get_the_author_meta('display_name', $post->post_author),
            'seo_data' => $seo_data ? $seo_data : array(),
            'content_data' => $content_data ? $content_data : array(),
        );
        
        // Sync with backend
        $this->api->request('content/sync', $data, 'POST');
    }

    /**
     * Perform scheduled data synchronization.
     *
     * @since    1.0.0
     */
    public function scheduled_sync() {
        // Sync site statistics
        $this->sync_site_stats();
        
        // Sync user data
        $this->sync_all_users();
        
        // Sync content data
        $this->sync_all_content();
    }

    /**
     * Sync site statistics with the backend.
     *
     * @since    1.0.0
     */
    public function sync_site_stats() {
        global $wpdb;
        
        // Get post counts
        $post_counts = wp_count_posts();
        $page_counts = wp_count_posts('page');
        
        // Get user counts
        $user_counts = count_users();
        
        // Get comment counts
        $comment_counts = wp_count_comments();
        
        // Get plugin and theme info
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        $theme = wp_get_theme();
        
        // Get WordPress version
        $wp_version = get_bloginfo('version');
        
        // Get database size
        $db_size = $wpdb->get_var("SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = '" . DB_NAME . "'");
        
        // Prepare stats data
        $stats = array(
            'domain' => get_site_url(),
            'wp_version' => $wp_version,
            'posts' => array(
                'total' => $post_counts->publish + $post_counts->draft + $post_counts->pending + $post_counts->private,
                'published' => $post_counts->publish,
                'draft' => $post_counts->draft,
                'pending' => $post_counts->pending,
                'private' => $post_counts->private,
            ),
            'pages' => array(
                'total' => $page_counts->publish + $page_counts->draft + $page_counts->pending + $page_counts->private,
                'published' => $page_counts->publish,
                'draft' => $page_counts->draft,
                'pending' => $page_counts->pending,
                'private' => $page_counts->private,
            ),
            'users' => array(
                'total' => $user_counts['total_users'],
                'by_role' => $user_counts['avail_roles'],
            ),
            'comments' => array(
                'total' => $comment_counts->total_comments,
                'approved' => $comment_counts->approved,
                'pending' => $comment_counts->moderated,
                'spam' => $comment_counts->spam,
                'trash' => $comment_counts->trash,
            ),
            'plugins' => array(
                'total' => count($plugins),
                'active' => count($active_plugins),
            ),
            'theme' => array(
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
            ),
            'database' => array(
                'size' => $db_size,
            ),
        );
        
        // Sync with backend
        $this->api->request('stats/site', $stats, 'POST');
    }

    /**
     * Sync all users with the backend.
     *
     * @since    1.0.0
     */
    public function sync_all_users() {
        $users = get_users(array(
            'fields' => 'ID',
        ));
        
        foreach ($users as $user_id) {
            $this->api->sync_user($user_id);
        }
    }

    /**
     * Sync all content with the backend.
     *
     * @since    1.0.0
     */
    public function sync_all_content() {
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => -1,
            'fields' => 'ids',
        ));
        
        foreach ($posts as $post_id) {
            $post = get_post($post_id);
            $this->sync_post_data($post_id, $post, true);
        }
    }

    /**
     * Pull data from the backend and update local database.
     *
     * @since    1.0.0
     * @return   boolean    Whether the pull was successful.
     */
    public function pull_data_from_backend() {
        // Pull SEO data
        $seo_data = $this->api->request('seo/data', array('domain' => get_site_url()));
        
        if (!is_wp_error($seo_data)) {
            update_option('rankolab_seo_data', $seo_data);
        }
        
        // Pull content templates
        $content_templates = $this->api->get_content_templates();
        
        if (!is_wp_error($content_templates)) {
            update_option('rankolab_content_templates', $content_templates);
        }
        
        // Pull design templates
        $design_templates = $this->api->get_design_templates();
        
        if (!is_wp_error($design_templates)) {
            update_option('rankolab_design_templates', $design_templates);
        }
        
        // Pull monitoring data
        $monitoring_data = $this->api->get_monitoring_results();
        
        if (!is_wp_error($monitoring_data)) {
            update_option('rankolab_monitoring_data', $monitoring_data);
        }
        
        // Pull AdSense suggestions
        $adsense_suggestions = $this->api->get_adsense_suggestions();
        
        if (!is_wp_error($adsense_suggestions)) {
            update_option('rankolab_adsense_suggestions', $adsense_suggestions);
        }
        
        return true;
    }

    /**
     * Initialize data synchronization.
     *
     * @since    1.0.0
     * @return   boolean    Whether the initialization was successful.
     */
    public function initialize_sync() {
        // Sync site stats
        $this->sync_site_stats();
        
        // Sync all users
        $this->sync_all_users();
        
        // Sync all content
        $this->sync_all_content();
        
        // Pull data from backend
        $this->pull_data_from_backend();
        
        return true;
    }
}
