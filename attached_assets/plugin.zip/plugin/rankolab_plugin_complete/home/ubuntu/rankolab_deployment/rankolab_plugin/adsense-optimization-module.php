<!-- Rankolab AdSense Optimization Module Template -->
<div class="rankolab-adsense-optimization-module" id="rankolab-adsense-optimization">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>AdSense Optimization</h2>
            <p>Optimize your ad placements, analyze performance, and maximize your AdSense revenue.</p>
        </div>
    </div>
    
    <!-- AdSense Account Connection -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">AdSense Account</h3>
        </div>
        <div class="rankolab-card-body">
            <?php if ($adsense_connected): ?>
                <div class="rankolab-adsense-account">
                    <div class="rankolab-adsense-account-info">
                        <div class="rankolab-adsense-account-icon">
                            <i class="fab fa-google"></i>
                        </div>
                        <div class="rankolab-adsense-account-details">
                            <div class="rankolab-adsense-account-name"><?php echo esc_html($adsense_account_name); ?></div>
                            <div class="rankolab-adsense-account-id"><?php echo esc_html($adsense_publisher_id); ?></div>
                        </div>
                    </div>
                    <div class="rankolab-adsense-account-status">
                        <div class="rankolab-status-badge rankolab-status-success">
                            <i class="fas fa-check-circle"></i> Connected
                        </div>
                    </div>
                    <div class="rankolab-adsense-account-actions">
                        <button class="rankolab-btn rankolab-btn-outline-primary" id="rankolab-adsense-refresh">
                            <i class="fas fa-sync-alt"></i> Refresh Data
                        </button>
                        <button class="rankolab-btn rankolab-btn-outline-danger" id="rankolab-adsense-disconnect">
                            <i class="fas fa-unlink"></i> Disconnect
                        </button>
                    </div>
                </div>
            <?php else: ?>
                <div class="rankolab-adsense-connect">
                    <div class="rankolab-adsense-connect-icon">
                        <i class="fab fa-google"></i>
                    </div>
                    <div class="rankolab-adsense-connect-text">
                        <h4>Connect your Google AdSense account</h4>
                        <p>Connect your AdSense account to analyze performance, optimize ad placements, and maximize your revenue.</p>
                    </div>
                    <div class="rankolab-adsense-connect-action">
                        <button class="rankolab-btn rankolab-btn-primary" id="rankolab-adsense-connect">
                            <i class="fas fa-link"></i> Connect AdSense Account
                        </button>
                    </div>
                </div>
                
                <div class="rankolab-adsense-manual-setup">
                    <div class="rankolab-adsense-manual-setup-toggle">
                        <a href="#" id="rankolab-manual-setup-toggle">Or enter your AdSense publisher ID manually</a>
                    </div>
                    <div class="rankolab-adsense-manual-setup-form" style="display: none;">
                        <div class="rankolab-form-group">
                            <label for="rankolab-adsense-publisher-id" class="rankolab-form-label">AdSense Publisher ID</label>
                            <input type="text" id="rankolab-adsense-publisher-id" class="rankolab-form-control" placeholder="e.g., pub-1234567890123456">
                            <div class="rankolab-form-text">Enter your AdSense publisher ID to enable basic ad management features.</div>
                        </div>
                        <button class="rankolab-btn rankolab-btn-primary" id="rankolab-adsense-manual-connect">
                            <i class="fas fa-save"></i> Save Publisher ID
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($adsense_connected): ?>
        <!-- AdSense Performance Overview -->
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Performance Overview</h3>
                <div class="rankolab-card-actions">
                    <div class="rankolab-form-group rankolab-mb-0">
                        <select id="rankolab-adsense-timeframe" class="rankolab-form-control rankolab-form-control-sm">
                            <option value="7">Last 7 Days</option>
                            <option value="30" selected>Last 30 Days</option>
                            <option value="90">Last 90 Days</option>
                            <option value="365">Last Year</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="rankolab-card-body">
                <div class="rankolab-adsense-metrics">
                    <div class="rankolab-adsense-metric">
                        <div class="rankolab-adsense-metric-icon">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="rankolab-adsense-metric-value"><?php echo esc_html($adsense_revenue); ?></div>
                        <div class="rankolab-adsense-metric-label">Revenue</div>
                        <div class="rankolab-adsense-metric-change <?php echo $revenue_change >= 0 ? 'positive' : 'negative'; ?>">
                            <i class="fas <?php echo $revenue_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($revenue_change)); ?>%
                        </div>
                    </div>
                    <div class="rankolab-adsense-metric">
                        <div class="rankolab-adsense-metric-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <div class="rankolab-adsense-metric-value"><?php echo number_format($adsense_impressions); ?></div>
                        <div class="rankolab-adsense-metric-label">Impressions</div>
                        <div class="rankolab-adsense-metric-change <?php echo $impressions_change >= 0 ? 'positive' : 'negative'; ?>">
                            <i class="fas <?php echo $impressions_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($impressions_change)); ?>%
                        </div>
                    </div>
                    <div class="rankolab-adsense-metric">
                        <div class="rankolab-adsense-metric-icon">
                            <i class="fas fa-mouse-pointer"></i>
                        </div>
                        <div class="rankolab-adsense-metric-value"><?php echo esc_html($adsense_ctr); ?>%</div>
                        <div class="rankolab-adsense-metric-label">Click-Through Rate</div>
                        <div class="rankolab-adsense-metric-change <?php echo $ctr_change >= 0 ? 'positive' : 'negative'; ?>">
                            <i class="fas <?php echo $ctr_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($ctr_change)); ?>%
                        </div>
                    </div>
                    <div class="rankolab-adsense-metric">
                        <div class="rankolab-adsense-metric-icon">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div class="rankolab-adsense-metric-value"><?php echo esc_html($adsense_cpc); ?></div>
                        <div class="rankolab-adsense-metric-label">Cost Per Click</div>
                        <div class="rankolab-adsense-metric-change <?php echo $cpc_change >= 0 ? 'positive' : 'negative'; ?>">
                            <i class="fas <?php echo $cpc_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($cpc_change)); ?>%
                        </div>
                    </div>
                </div>
                
                <div class="rankolab-chart-container">
                    <canvas id="rankolab-adsense-revenue-chart"></canvas>
                </div>
                
                <div class="rankolab-adsense-summary">
                    <div class="rankolab-adsense-summary-title">Performance Summary</div>
                    <div class="rankolab-adsense-summary-content">
                        <?php if ($performance_trend === 'up'): ?>
                            <div class="rankolab-adsense-summary-positive">
                                <i class="fas fa-chart-line"></i> Your AdSense performance is trending upward. Revenue has increased by <?php echo esc_html($revenue_change); ?>% compared to the previous period.
                            </div>
                        <?php elseif ($performance_trend === 'down'): ?>
                            <div class="rankolab-adsense-summary-negative">
                                <i class="fas fa-chart-line"></i> Your AdSense performance is trending downward. Revenue has decreased by <?php echo abs(esc_html($revenue_change)); ?>% compared to the previous period.
                            </div>
                        <?php else: ?>
                            <div class="rankolab-adsense-summary-neutral">
                                <i class="fas fa-chart-line"></i> Your AdSense performance is stable. Revenue has changed by <?php echo esc_html($revenue_change); ?>% compared to the previous period.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Ad Units -->
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Ad Units</h3>
                <div class="rankolab-card-actions">
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-create-ad-unit">
                        <i class="fas fa-plus"></i> Create Ad Unit
                    </button>
                </div>
            </div>
            <div class="rankolab-card-body">
                <?php if (!empty($ad_units)): ?>
                    <div class="rankolab-table-responsive">
                        <table class="rankolab-table rankolab-table-hover">
                            <thead>
                                <tr>
                                    <th>Ad Unit</th>
                                    <th>Type</th>
                                    <th>Size</th>
                                    <th>Impressions</th>
                                    <th>CTR</th>
                                    <th>Revenue</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ad_units as $ad_unit): ?>
                                    <tr>
                                        <td>
                                            <div class="rankolab-ad-unit-info">
                                                <div class="rankolab-ad-unit-name"><?php echo esc_html($ad_unit['name']); ?></div>
                                                <div class="rankolab-ad-unit-id"><?php echo esc_html($ad_unit['id']); ?></div>
                                            </div>
                                        </td>
                                        <td><?php echo esc_html($ad_unit['type']); ?></td>
                                        <td><?php echo esc_html($ad_unit['size']); ?></td>
                                        <td><?php echo number_format($ad_unit['impressions']); ?></td>
                                        <td><?php echo esc_html($ad_unit['ctr']); ?>%</td>
                                        <td><?php echo esc_html($ad_unit['revenue']); ?></td>
                                        <td>
                                            <div class="rankolab-btn-group">
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-edit-ad-unit" data-ad-unit-id="<?php echo esc_attr($ad_unit['id']); ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-info rankolab-get-ad-code" data-ad-unit-id="<?php echo esc_attr($ad_unit['id']); ?>">
                                                    <i class="fas fa-code"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger rankolab-delete-ad-unit" data-ad-unit-id="<?php echo esc_attr($ad_unit['id']); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="rankolab-empty-state">
                        <div class="rankolab-empty-state-icon">
                            <i class="fas fa-ad"></i>
                        </div>
                        <div class="rankolab-empty-state-text">No ad units found. Click "Create Ad Unit" to get started.</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Ad Placement Optimization -->
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Ad Placement Optimization</h3>
            </div>
            <div class="rankolab-card-body">
                <div class="rankolab-tabs" data-tab-group="ad-placement">
                    <div class="rankolab-tab-link active" data-tab-target="auto-placement">Auto Placement</div>
                    <div class="rankolab-tab-link" data-tab-target="manual-placement">Manual Placement</div>
                    <div class="rankolab-tab-link" data-tab-target="placement-analysis">Placement Analysis</div>
                </div>
                
                <div class="rankolab-tab-content active" data-tab-group="ad-placement" data-tab-id="auto-placement">
                    <div class="rankolab-auto-placement">
                        <div class="rankolab-auto-placement-description">
                            <p>Auto placement automatically inserts ads at optimal positions in your content for maximum revenue while maintaining a good user experience.</p>
                        </div>
                        
                        <div class="rankolab-form-group">
                            <label for="rankolab-auto-placement-status" class="rankolab-form-label">Auto Placement</label>
                            <div class="rankolab-form-check rankolab-form-switch">
                                <input type="checkbox" id="rankolab-auto-placement-status" class="rankolab-form-check-input" <?php echo $auto_placement_enabled ? 'checked' : ''; ?>>
                                <label for="rankolab-auto-placement-status" class="rank
(Content truncated due to size limit. Use line ranges to read in chunks)