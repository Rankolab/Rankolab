<?php
/**
 * Fired during plugin deactivation
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Deactivator {

    /**
     * Deactivate the plugin.
     *
     * Performs cleanup operations when the plugin is deactivated.
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        // Clear any scheduled events
        wp_clear_scheduled_hook('rankolab_daily_maintenance');
        wp_clear_scheduled_hook('rankolab_weekly_reports');
        wp_clear_scheduled_hook('rankolab_license_verification');
        
        // Remove transients
        delete_transient('rankolab_activation_redirect');
        delete_transient('rankolab_api_cache');
        delete_transient('rankolab_seo_analysis_cache');
        
        // Flush rewrite rules
        flush_rewrite_rules();

        // Call deactivate methods for modules that have them
        if (class_exists(\'Rankolab_Cache_Management\') && method_exists(\'Rankolab_Cache_Management\', \'deactivate\')) {
            Rankolab_Cache_Management::deactivate();
        }
        if (class_exists(\'Rankolab_Newsletter\') && method_exists(\'Rankolab_Newsletter\', \'deactivate\')) {
            Rankolab_Newsletter::deactivate();
        }
        if (class_exists(\'Rankolab_Error_Logging\') && method_exists(\'Rankolab_Error_Logging\', \'deactivate\')) {
            Rankolab_Error_Logging::deactivate();
        }
        
        // Log deactivation
        // self::log_deactivation(); // Consider using the new logging module instead
        if (class_exists(\'Rankolab_Error_Logging\')) {
            Rankolab_Error_Logging::log(\'Rankolab plugin deactivated.\', \'info\', \'Core Deactivator\');
        }
    }
    
    /**
     * Log the deactivation event.
     *
     * @since    1.0.0
     */
    private static function log_deactivation() {
        $log_file = WP_CONTENT_DIR . '/rankolab-logs/deactivation.log';
        
        // Create logs directory if it doesn't exist
        if (!file_exists(WP_CONTENT_DIR . '/rankolab-logs')) {
            wp_mkdir_p(WP_CONTENT_DIR . '/rankolab-logs');
        }
        
        // Get plugin data
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/rankolab/rankolab.php');
        
        // Log message
        $log_message = sprintf(
            "[%s] Rankolab plugin v%s deactivated on %s\n",
            current_time('mysql'),
            $plugin_data['Version'],
            home_url()
        );
        
        // Write to log file
        file_put_contents($log_file, $log_message, FILE_APPEND);
    }
}
