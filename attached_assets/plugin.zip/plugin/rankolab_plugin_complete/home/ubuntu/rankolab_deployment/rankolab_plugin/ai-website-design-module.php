<!-- Rankolab AI Website Design Module Template -->
<div class="rankolab-ai-website-design-module" id="rankolab-ai-website-design">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>AI Website Design</h2>
            <p>Create beautiful, responsive website designs tailored to your industry and preferences.</p>
        </div>
    </div>
    
    <!-- Design Generator Form -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Generate Website Design</h3>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-form-group">
                <label for="rankolab-website-name" class="rankolab-form-label">Website Name</label>
                <input type="text" id="rankolab-website-name" class="rankolab-form-control" placeholder="Enter your website name">
            </div>
            
            <div class="rankolab-form-group">
                <label for="rankolab-website-industry" class="rankolab-form-label">Industry</label>
                <select id="rankolab-website-industry" class="rankolab-form-control">
                    <option value="">Select an industry</option>
                    <option value="business">Business & Corporate</option>
                    <option value="ecommerce">E-Commerce</option>
                    <option value="blog">Blog & Magazine</option>
                    <option value="portfolio">Portfolio & Creative</option>
                    <option value="education">Education & Learning</option>
                    <option value="health">Health & Wellness</option>
                    <option value="travel">Travel & Hospitality</option>
                    <option value="food">Food & Restaurant</option>
                    <option value="real-estate">Real Estate</option>
                    <option value="technology">Technology & Software</option>
                    <option value="nonprofit">Nonprofit & Charity</option>
                    <option value="entertainment">Entertainment & Media</option>
                    <option value="other">Other</option>
                </select>
            </div>
            
            <div class="rankolab-row">
                <div class="rankolab-col rankolab-col-6">
                    <div class="rankolab-form-group">
                        <label for="rankolab-design-style" class="rankolab-form-label">Design Style</label>
                        <select id="rankolab-design-style" class="rankolab-form-control">
                            <option value="">Select a style</option>
                            <option value="modern">Modern & Minimal</option>
                            <option value="classic">Classic & Professional</option>
                            <option value="creative">Creative & Bold</option>
                            <option value="elegant">Elegant & Sophisticated</option>
                            <option value="playful">Playful & Vibrant</option>
                            <option value="corporate">Corporate & Serious</option>
                            <option value="tech">Tech & Innovative</option>
                            <option value="natural">Natural & Organic</option>
                        </select>
                    </div>
                </div>
                <div class="rankolab-col rankolab-col-6">
                    <div class="rankolab-form-group">
                        <label for="rankolab-color-scheme" class="rankolab-form-label">Color Scheme</label>
                        <select id="rankolab-color-scheme" class="rankolab-form-control">
                            <option value="">Select a color scheme</option>
                            <option value="blue">Blue Tones</option>
                            <option value="green">Green Tones</option>
                            <option value="red">Red Tones</option>
                            <option value="purple">Purple Tones</option>
                            <option value="orange">Orange Tones</option>
                            <option value="monochrome">Monochrome</option>
                            <option value="pastel">Pastel Colors</option>
                            <option value="vibrant">Vibrant & Colorful</option>
                            <option value="dark">Dark Mode</option>
                            <option value="light">Light & Airy</option>
                            <option value="custom">Custom Colors</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div id="rankolab-custom-colors" class="rankolab-row" style="display: none;">
                <div class="rankolab-col rankolab-col-4">
                    <div class="rankolab-form-group">
                        <label for="rankolab-primary-color" class="rankolab-form-label">Primary Color</label>
                        <input type="color" id="rankolab-primary-color" class="rankolab-form-control rankolab-color-picker" value="#4a6bff">
                    </div>
                </div>
                <div class="rankolab-col rankolab-col-4">
                    <div class="rankolab-form-group">
                        <label for="rankolab-secondary-color" class="rankolab-form-label">Secondary Color</label>
                        <input type="color" id="rankolab-secondary-color" class="rankolab-form-control rankolab-color-picker" value="#ff6b4a">
                    </div>
                </div>
                <div class="rankolab-col rankolab-col-4">
                    <div class="rankolab-form-group">
                        <label for="rankolab-accent-color" class="rankolab-form-label">Accent Color</label>
                        <input type="color" id="rankolab-accent-color" class="rankolab-form-control rankolab-color-picker" value="#4aff6b">
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label class="rankolab-form-label">Layout Structure</label>
                <div class="rankolab-layout-options">
                    <div class="rankolab-layout-option">
                        <input type="radio" name="rankolab-layout" id="rankolab-layout-standard" value="standard" checked>
                        <label for="rankolab-layout-standard" class="rankolab-layout-label">
                            <div class="rankolab-layout-preview rankolab-layout-standard"></div>
                            <div class="rankolab-layout-name">Standard</div>
                        </label>
                    </div>
                    <div class="rankolab-layout-option">
                        <input type="radio" name="rankolab-layout" id="rankolab-layout-sidebar" value="sidebar">
                        <label for="rankolab-layout-sidebar" class="rankolab-layout-label">
                            <div class="rankolab-layout-preview rankolab-layout-sidebar"></div>
                            <div class="rankolab-layout-name">With Sidebar</div>
                        </label>
                    </div>
                    <div class="rankolab-layout-option">
                        <input type="radio" name="rankolab-layout" id="rankolab-layout-fullwidth" value="fullwidth">
                        <label for="rankolab-layout-fullwidth" class="rankolab-layout-label">
                            <div class="rankolab-layout-preview rankolab-layout-fullwidth"></div>
                            <div class="rankolab-layout-name">Full Width</div>
                        </label>
                    </div>
                    <div class="rankolab-layout-option">
                        <input type="radio" name="rankolab-layout" id="rankolab-layout-grid" value="grid">
                        <label for="rankolab-layout-grid" class="rankolab-layout-label">
                            <div class="rankolab-layout-preview rankolab-layout-grid"></div>
                            <div class="rankolab-layout-name">Grid Layout</div>
                        </label>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label class="rankolab-form-label">Required Pages</label>
                <div class="rankolab-row">
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-home" class="rankolab-form-check-input" checked disabled>
                            <label for="rankolab-page-home" class="rankolab-form-check-label">Home</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-about" class="rankolab-form-check-input" checked>
                            <label for="rankolab-page-about" class="rankolab-form-check-label">About</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-services" class="rankolab-form-check-input" checked>
                            <label for="rankolab-page-services" class="rankolab-form-check-label">Services</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-contact" class="rankolab-form-check-input" checked>
                            <label for="rankolab-page-contact" class="rankolab-form-check-label">Contact</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-blog" class="rankolab-form-check-input">
                            <label for="rankolab-page-blog" class="rankolab-form-check-label">Blog</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-portfolio" class="rankolab-form-check-input">
                            <label for="rankolab-page-portfolio" class="rankolab-form-check-label">Portfolio</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-testimonials" class="rankolab-form-check-input">
                            <label for="rankolab-page-testimonials" class="rankolab-form-check-label">Testimonials</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-page-pricing" class="rankolab-form-check-input">
                            <label for="rankolab-page-pricing" class="rankolab-form-check-label">Pricing</label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label class="rankolab-form-label">Additional Features</label>
                <div class="rankolab-row">
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-feature-responsive" class="rankolab-form-check-input" checked disabled>
                            <label for="rankolab-feature-responsive" class="rankolab-form-check-label">Responsive Design</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-feature-seo" class="rankolab-form-check-input" checked>
                            <label for="rankolab-feature-seo" class="rankolab-form-check-label">SEO Optimized</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-feature-social" class="rankolab-form-check-input" checked>
                            <label for="rankolab-feature-social" class="rankolab-form-check-label">Social Media Integration</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-feature-newsletter" class="rankolab-form-check-input">
                            <label for="rankolab-feature-newsletter" class="rankolab-form-check-label">Newsletter Signup</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-feature-chat" class="rankolab-form-check-input">
                            <label for="rankolab-feature-chat" class="rankolab-form-check-label">Live Chat</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-feature-analytics" class="rankolab-form-check-input">
                            <label for="rankolab-feature-analytics" class="rankolab-form-check-label">Analytics Integration</label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label for="rankolab-design-notes" class="rankolab-form-label">Additional Notes (Optional)</label>
                <textarea id="rankolab-design-notes" class="rankolab-form-control" rows="3" placeholder="Enter any specific requirements or preferences for your website design"></textarea>
            </div>
            
            <div class="rankolab-text-right">
                <button id="rankolab-generate-design" class="rankolab-btn rankolab-btn-primary">
                    <i class="fas fa-magic"></i> Generate Design
                </button>
            </div>
        </div>
    </div>
    
    <!-- Design Preview -->
    <div id="rankolab-design-preview" class="rankolab-design-preview" style="display: none;">
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Design Preview</h3>
                <div class="rankolab-card-actions">
                    <div class="rankolab-btn-group">
                        <button id="rankolab-preview-desktop" class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary active">
                            <i class="fas fa-desktop"></i>
                        </button>
                        <button id="rankolab-preview-tablet" class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary">
                        
(Content truncated due to size limit. Use line ranges to read in chunks)