<?php
/**
 * Rankolab Cache Management Module
 *
 * Handles automatic and manual clearing of WordPress cache.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Your Name <your@email.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	 exit; // Exit if accessed directly
}

class Rankolab_Cache_Management {

	 private static $instance;
	 private $plugin_name;
	 private $version;
	 private $option_name = 'rankolab_cache_settings';
	 private $cron_hook = 'rankolab_cache_clear_cron';

	 /**
	  * Get singleton instance.
	  */
	 public static function get_instance( $plugin_name, $version ) {
		 if ( null === self::$instance ) {
			 self::$instance = new self( $plugin_name, $version );
		 }
		 return self::$instance;
	 }

	 /**
	  * Initialize the class and set its properties.
	  */
	 private function __construct( $plugin_name, $version ) {
		 $this->plugin_name = $plugin_name;
		 $this->version = $version;

		 // Add hooks
		 add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		 add_action( 'admin_init', array( $this, 'register_settings' ) );
		 add_action( 'wp_ajax_rankolab_manual_cache_clear', array( $this, 'handle_manual_cache_clear_ajax' ) );
		 add_action( $this->cron_hook, array( $this, 'clear_cache' ) );

		 // Schedule/Unschedule cron based on settings
		 $this->manage_cron_schedule();
	 }

	 /**
	  * Add settings page to Rankolab menu.
	  */
	 public function add_settings_page() {
		 add_submenu_page(
			 'rankolab', // Parent slug
			 __( 'Cache Management', 'rankolab' ), // Page title
			 __( 'Cache Management', 'rankolab' ), // Menu title
			 'manage_options', // Capability
			 'rankolab-cache', // Menu slug
			 array( $this, 'display_settings_page' ) // Function
		 );
	 }

	 /**
	  * Register settings.
	  */
	 public function register_settings() {
		 register_setting( $this->option_name . '_group', $this->option_name, array( $this, 'sanitize_settings' ) );

		 add_settings_section(
			 'rankolab_cache_main_section',
			 __( 'Cache Settings', 'rankolab' ),
			 null,
			 $this->option_name . '_page'
		 );

		 add_settings_field(
			 'enabled',
			 __( 'Enable Automatic Clearing', 'rankolab' ),
			 array( $this, 'render_enabled_field' ),
			 $this->option_name . '_page',
			 'rankolab_cache_main_section'
		 );

		 add_settings_field(
			 'frequency',
			 __( 'Clearing Frequency', 'rankolab' ),
			 array( $this, 'render_frequency_field' ),
			 $this->option_name . '_page',
			 'rankolab_cache_main_section'
		 );
	 }

	 /**
	  * Sanitize settings before saving.
	  */
	 public function sanitize_settings( $input ) {
		 $sanitized_input = array();
		 $defaults = $this->get_default_settings();

		 $sanitized_input['enabled'] = isset( $input['enabled'] ) ? 1 : 0;
		 $sanitized_input['frequency'] = isset( $input['frequency'] ) && array_key_exists( $input['frequency'], $this->get_cron_schedules() ) ? sanitize_text_field( $input['frequency'] ) : $defaults['frequency'];

		 // Reschedule cron after saving settings
		 $this->manage_cron_schedule( $sanitized_input );

		 return $sanitized_input;
	 }

	 /**
	  * Get default settings.
	  */
	 private function get_default_settings() {
		 return array(
			 'enabled'   => 0,
			 'frequency' => 'daily',
		 );
	 }

	 /**
	  * Get current settings.
	  */
	 private function get_settings() {
		 return get_option( $this->option_name, $this->get_default_settings() );
	 }

	 /**
	  * Render enabled checkbox field.
	  */
	 public function render_enabled_field() {
		 $options = $this->get_settings();
		 $checked = isset( $options['enabled'] ) && $options['enabled'] ? 'checked' : '';
		 echo "<input type='checkbox' name='{$this->option_name}[enabled]' value='1' {$checked} />";
		 echo "<p class='description'>" . __( 'Check this box to enable automatic cache clearing based on the frequency below.', 'rankolab' ) . "</p>";
	 }

	 /**
	  * Render frequency dropdown field.
	  */
	 public function render_frequency_field() {
		 $options = $this->get_settings();
		 $current_frequency = isset( $options['frequency'] ) ? $options['frequency'] : 'daily';
		 $schedules = $this->get_cron_schedules();

		 echo "<select name='{$this->option_name}[frequency]'>";
		 foreach ( $schedules as $key => $details ) {
			 echo "<option value='" . esc_attr( $key ) . "' " . selected( $current_frequency, $key, false ) . ">" . esc_html( $details['display'] ) . "</option>";
		 }
		 echo "</select>";
		 echo "<p class='description'>" . __( 'Select how often the cache should be cleared automatically.', 'rankolab' ) . "</p>";
	 }

	 /**
	  * Display the settings page.
	  */
	 public function display_settings_page() {
		 ?>
		 <div class="wrap">
			 <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			 <form action="options.php" method="post">
				 <?php
				 settings_fields( $this->option_name . '_group' );
				 do_settings_sections( $this->option_name . '_page' );
				 submit_button( __( 'Save Settings', 'rankolab' ) );
				 ?>
			 </form>

			 <h2><?php _e( 'Manual Cache Clearing', 'rankolab' ); ?></h2>
			 <p><?php _e( 'Use this button to clear all supported caches immediately.', 'rankolab' ); ?></p>
			 <button id="rankolab-manual-cache-clear-btn" class="button button-secondary"><?php _e( 'Clear Cache Now', 'rankolab' ); ?></button>
			 <span id="rankolab-cache-clear-status" style="margin-left: 10px;"></span>
			 <p><?php _e( 'Last manual clear:', 'rankolab' ); ?> <span id="rankolab-last-manual-clear"><?php echo esc_html( get_option( 'rankolab_last_manual_cache_clear', __( 'Never', 'rankolab' ) ) ); ?></span></p>
		 </div>
		 <script type="text/javascript">
			 jQuery(document).ready(function($) {
				 $('#rankolab-manual-cache-clear-btn').on('click', function(e) {
					 e.preventDefault();
					 var $button = $(this);
					 var $status = $('#rankolab-cache-clear-status');
					 $button.prop('disabled', true);
					 $status.text('<?php _e( 'Clearing...', 'rankolab' ); ?>').css('color', 'orange');

					 $.post(ajaxurl, {
						 action: 'rankolab_manual_cache_clear',
						 _ajax_nonce: '<?php echo wp_create_nonce( 'rankolab_manual_cache_clear_nonce' ); ?>'
					 }, function(response) {
						 if (response.success) {
							 $status.text('<?php _e( 'Cache cleared successfully!', 'rankolab' ); ?>').css('color', 'green');
							 $('#rankolab-last-manual-clear').text(response.data.last_clear_time);
						 } else {
							 $status.text('<?php _e( 'Error clearing cache.', 'rankolab' ); ?>' + (response.data.message ? ' ' + response.data.message : '')).css('color', 'red');
						 }
						 $button.prop('disabled', false);
						 setTimeout(function(){ $status.text(''); }, 5000);
					 });
				 });
			 });
		 </script>
		 <?php
	 }

	 /**
	  * Handle AJAX request for manual cache clearing.
	  */
	 public function handle_manual_cache_clear_ajax() {
		 check_ajax_referer( 'rankolab_manual_cache_clear_nonce' );

		 if ( ! current_user_can( 'manage_options' ) ) {
			 wp_send_json_error( array( 'message' => __( 'Permission denied.', 'rankolab' ) ) );
		 }

		 $result = $this->clear_cache();

		 if ( $result ) {
			 $now = current_time( 'mysql' );
			 update_option( 'rankolab_last_manual_cache_clear', $now );
			 wp_send_json_success( array( 'last_clear_time' => $now ) );
		 } else {
			 wp_send_json_error( array( 'message' => __( 'Cache clearing function reported an issue.', 'rankolab' ) ) );
		 }
	 }

	 /**
	  * Core function to clear various caches.
	  * Returns true on success, false on failure (though success is generally assumed).
	  */
	 public function clear_cache() {
		 // 1. WordPress Object Cache
		 wp_cache_flush();

		 // 2. W3 Total Cache
		 if ( function_exists( 'w3tc_flush_all' ) ) {
			 w3tc_flush_all();
		 }

		 // 3. WP Super Cache
		 if ( function_exists( 'wp_cache_clear_cache' ) ) {
			 // WP Super Cache needs the global $file_prefix variable
			 global $file_prefix, $cache_path;
			 if ( empty( $cache_path ) ) {
				 $cache_path = WP_CONTENT_DIR . '/cache/';
			 }
			 wp_cache_clear_cache( $file_prefix );
		 }

		 // 4. WP Rocket
		 if ( function_exists( 'rocket_clean_domain' ) ) {
			 rocket_clean_domain();
		 }
		 // Also consider other WP Rocket functions if needed, e.g., rocket_clean_minify(), rocket_clean_cache_busting()

		 // 5. PHP OPcache (if available and enabled)
		 if ( function_exists( 'opcache_reset' ) && ini_get( 'opcache.enable' ) ) {
			 opcache_reset();
		 }

		 // 6. Action Hook for extensibility
		 do_action( 'rankolab_after_cache_clear' );

		 // Log the clearing action (optional, requires Error Logging module)
		 // Rankolab_Error_Logging::log( 'Cache cleared via Rankolab Cache Management.' );

		 return true; // Assume success unless a specific error is caught
	 }

	 /**
	  * Get available cron schedules.
	  */
	 private function get_cron_schedules() {
		 // Add custom schedules if needed, here using default WP schedules
		 $schedules = wp_get_schedules();
		 // Filter to common useful ones if desired
		 return array_intersect_key( $schedules, array_flip( array( 'hourly', 'twicedaily', 'daily' ) ) );
		 // Add weekly if needed: 'weekly' => array('interval' => 604800, 'display' => __('Once Weekly'))
	 }

	 /**
	  * Manage WP-Cron scheduling based on settings.
	  */
	 private function manage_cron_schedule( $settings = null ) {
		 if ( $settings === null ) {
			 $settings = $this->get_settings();
		 }

		 $timestamp = wp_next_scheduled( $this->cron_hook );

		 if ( isset( $settings['enabled'] ) && $settings['enabled'] ) {
			 $frequency = isset( $settings['frequency'] ) ? $settings['frequency'] : 'daily';
			 if ( ! $timestamp ) {
				 // Schedule if not already scheduled
				 wp_schedule_event( time(), $frequency, $this->cron_hook );
			 } else {
				 // Reschedule if frequency changed (check schedule associated with the timestamp)
				 $schedule = wp_get_schedule( $this->cron_hook );
				 if ( $schedule !== $frequency ) {
					 wp_clear_scheduled_hook( $this->cron_hook );
					 wp_schedule_event( time(), $frequency, $this->cron_hook );
				 }
			 }
		 } else {
			 // If disabled, clear any existing schedule
			 if ( $timestamp ) {
				 wp_clear_scheduled_hook( $this->cron_hook );
			 }
		 }
	 }
}

// Instantiate the class (assuming it's loaded correctly by the main plugin file)
// Example: Rankolab_Cache_Management::get_instance( RANKOLAB_PLUGIN_NAME, RANKOLAB_VERSION );

