<?php
/**
 * Deployment Configuration for Rankolab
 *
 * This file contains deployment-specific configuration settings.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

// Define deployment constants
define('RANKOLAB_DEPLOYMENT_VERSION', '1.0.0');
define('RANKOLAB_DEPLOYMENT_DATE', '2025-04-24');
define('RANKOLAB_BACKEND_URL', 'https://rankolab.com/api');
define('RANKOLAB_MASTER_KEY', 'RANKO-MASTER-2025-XYZ123');

// Define API endpoints
$rankolab_api_endpoints = array(
    'license_verify' => RANKOLAB_BACKEND_URL . '/license/verify',
    'license_deactivate' => RANKOLAB_BACKEND_URL . '/license/deactivate',
    'user_sync' => RANKOLAB_BACKEND_URL . '/users/sync',
    'content_templates' => RANKOLAB_BACKEND_URL . '/content/templates',
    'content_generate' => RANKOLAB_BACKEND_URL . '/content/generate',
    'domain_analyze' => RANKOLAB_BACKEND_URL . '/domain/analyze',
    'seo_recommendations' => RANKOLAB_BACKEND_URL . '/seo/recommendations',
    'design_templates' => RANKOLAB_BACKEND_URL . '/design/templates',
    'design_generate' => RANKOLAB_BACKEND_URL . '/design/generate',
    'social_suggestions' => RANKOLAB_BACKEND_URL . '/social/suggestions',
    'link_opportunities' => RANKOLAB_BACKEND_URL . '/links/opportunities',
    'monitoring_results' => RANKOLAB_BACKEND_URL . '/monitoring/results',
    'adsense_suggestions' => RANKOLAB_BACKEND_URL . '/adsense/suggestions',
    'assistant_query' => RANKOLAB_BACKEND_URL . '/assistant/query',
    'affiliate_register' => RANKOLAB_BACKEND_URL . '/affiliate/register',
    'stats_site' => RANKOLAB_BACKEND_URL . '/stats/site',
    'usage_track' => RANKOLAB_BACKEND_URL . '/usage/track',
    'updates_check' => RANKOLAB_BACKEND_URL . '/updates/check',
);

// Save API endpoints
update_option('rankolab_api_endpoints', $rankolab_api_endpoints);

// Define deployment settings
$rankolab_deployment_settings = array(
    'environment' => 'production',
    'debug_mode' => false,
    'api_timeout' => 30,
    'sync_interval' => 3600,
    'log_level' => 'error',
    'auto_updates' => true,
);

// Save deployment settings
update_option('rankolab_deployment_settings', $rankolab_deployment_settings);

// Define feature flags
$rankolab_feature_flags = array(
    'enable_ai_assistant' => true,
    'enable_advanced_seo' => true,
    'enable_social_posting' => true,
    'enable_affiliate_system' => true,
    'enable_adsense_optimization' => true,
    'enable_website_monitoring' => true,
);

// Save feature flags
update_option('rankolab_feature_flags', $rankolab_feature_flags);

// Set up initial admin notice
add_action('admin_notices', 'rankolab_deployment_admin_notice');

/**
 * Display admin notice after deployment.
 */
function rankolab_deployment_admin_notice() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e('Rankolab has been successfully deployed! Please verify your license to activate all features.', 'rankolab'); ?></p>
        <p><a href="<?php echo admin_url('admin.php?page=rankolab-settings'); ?>" class="button button-primary"><?php _e('Verify License', 'rankolab'); ?></a></p>
    </div>
    <?php
}
