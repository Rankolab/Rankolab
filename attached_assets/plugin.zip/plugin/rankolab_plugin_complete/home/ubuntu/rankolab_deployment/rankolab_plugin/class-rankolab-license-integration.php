<?php
/**
 * License Integration Class for Rankolab
 *
 * This class handles license verification and management between the WordPress plugin and the Rankolab backend website.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

class Rankolab_License_Integration {

    /**
     * The API integration instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_API_Integration    $api    The API integration instance.
     */
    private $api;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    Rankolab_API_Integration    $api    The API integration instance.
     */
    public function __construct($api) {
        $this->api = $api;
        
        // Add hooks for license management
        add_action('admin_init', array($this, 'check_license_status'));
        add_action('rankolab_daily_license_check', array($this, 'scheduled_license_check'));
        
        // Schedule daily license check
        if (!wp_next_scheduled('rankolab_daily_license_check')) {
            wp_schedule_event(time(), 'daily', 'rankolab_daily_license_check');
        }
    }

    /**
     * Verify a license key with the backend.
     *
     * @since    1.0.0
     * @param    string    $license_key    The license key to verify.
     * @return   array|WP_Error            The verification result or WP_Error on failure.
     */
    public function verify_license($license_key) {
        $result = $this->api->verify_license($license_key);
        
        if (!is_wp_error($result) && isset($result['success']) && $result['success']) {
            // Store license information
            update_option('rankolab_license_key', $license_key);
            update_option('rankolab_license_status', 'valid');
            update_option('rankolab_license_expiry', isset($result['expiry']) ? $result['expiry'] : '');
            update_option('rankolab_license_plan', isset($result['plan']) ? $result['plan'] : '');
            update_option('rankolab_license_features', isset($result['features']) ? $result['features'] : array());
            update_option('rankolab_license_limits', isset($result['limits']) ? $result['limits'] : array());
            update_option('rankolab_license_last_check', current_time('timestamp'));
            
            // Generate API key if needed
            if (empty(get_option('rankolab_api_key', ''))) {
                $this->api->generate_api_key();
            }
        }
        
        return $result;
    }

    /**
     * Check the current license status.
     *
     * @since    1.0.0
     */
    public function check_license_status() {
        $license_key = get_option('rankolab_license_key', '');
        $last_check = get_option('rankolab_license_last_check', 0);
        $current_time = current_time('timestamp');
        
        // Only check once per day
        if (empty($license_key) || ($current_time - $last_check) < DAY_IN_SECONDS) {
            return;
        }
        
        $this->verify_license($license_key);
    }

    /**
     * Perform scheduled license check.
     *
     * @since    1.0.0
     */
    public function scheduled_license_check() {
        $license_key = get_option('rankolab_license_key', '');
        
        if (!empty($license_key)) {
            $this->verify_license($license_key);
        }
    }

    /**
     * Deactivate the license.
     *
     * @since    1.0.0
     * @return   boolean    Whether the deactivation was successful.
     */
    public function deactivate_license() {
        $license_key = get_option('rankolab_license_key', '');
        
        if (empty($license_key)) {
            return false;
        }
        
        $result = $this->api->request('license/deactivate', array(
            'license_key' => $license_key,
            'domain' => get_site_url(),
        ), 'POST');
        
        if (!is_wp_error($result) && isset($result['success']) && $result['success']) {
            // Clear license information
            delete_option('rankolab_license_key');
            delete_option('rankolab_license_status');
            delete_option('rankolab_license_expiry');
            delete_option('rankolab_license_plan');
            delete_option('rankolab_license_features');
            delete_option('rankolab_license_limits');
            delete_option('rankolab_license_last_check');
            delete_option('rankolab_api_key');
            
            return true;
        }
        
        return false;
    }

    /**
     * Check if the license is valid.
     *
     * @since    1.0.0
     * @return   boolean    Whether the license is valid.
     */
    public function is_license_valid() {
        $status = get_option('rankolab_license_status', '');
        return $status === 'valid';
    }

    /**
     * Check if the license has expired.
     *
     * @since    1.0.0
     * @return   boolean    Whether the license has expired.
     */
    public function is_license_expired() {
        $expiry = get_option('rankolab_license_expiry', '');
        
        if (empty($expiry)) {
            return false;
        }
        
        $expiry_time = strtotime($expiry);
        $current_time = current_time('timestamp');
        
        return $expiry_time < $current_time;
    }

    /**
     * Get the license plan.
     *
     * @since    1.0.0
     * @return   string    The license plan.
     */
    public function get_license_plan() {
        return get_option('rankolab_license_plan', '');
    }

    /**
     * Check if the license has access to a specific feature.
     *
     * @since    1.0.0
     * @param    string    $feature    The feature to check.
     * @return   boolean               Whether the license has access to the feature.
     */
    public function has_feature_access($feature) {
        $features = get_option('rankolab_license_features', array());
        return in_array($feature, $features);
    }

    /**
     * Get the license usage limits.
     *
     * @since    1.0.0
     * @return   array    The license usage limits.
     */
    public function get_license_limits() {
        return get_option('rankolab_license_limits', array());
    }

    /**
     * Get the license expiry date.
     *
     * @since    1.0.0
     * @return   string    The license expiry date.
     */
    public function get_license_expiry() {
        return get_option('rankolab_license_expiry', '');
    }

    /**
     * Get the days remaining until license expiry.
     *
     * @since    1.0.0
     * @return   int    The days remaining until license expiry.
     */
    public function get_days_remaining() {
        $expiry = get_option('rankolab_license_expiry', '');
        
        if (empty($expiry)) {
            return 0;
        }
        
        $expiry_time = strtotime($expiry);
        $current_time = current_time('timestamp');
        
        if ($expiry_time < $current_time) {
            return 0;
        }
        
        return floor(($expiry_time - $current_time) / DAY_IN_SECONDS);
    }

    /**
     * Check if the license is about to expire.
     *
     * @since    1.0.0
     * @param    int       $days    The number of days to check.
     * @return   boolean            Whether the license is about to expire.
     */
    public function is_license_expiring_soon($days = 7) {
        $remaining_days = $this->get_days_remaining();
        return $remaining_days > 0 && $remaining_days <= $days;
    }
}
