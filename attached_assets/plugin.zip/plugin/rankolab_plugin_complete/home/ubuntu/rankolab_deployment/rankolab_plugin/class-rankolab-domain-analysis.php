<?php
/**
 * The file that defines the domain analysis module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The domain analysis module class.
 *
 * This class handles domain analysis functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Domain_Analysis {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_analyze_domain', array($this, 'ajax_analyze_domain'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_domain_analysis_page'), 20);
    }

    /**
     * Add domain analysis admin page.
     *
     * @since    1.0.0
     */
    public function add_domain_analysis_page() {
        add_submenu_page(
            'rankolab',
            'Domain Analysis',
            'Domain Analysis',
            'manage_options',
            'rankolab-domain-analysis',
            array($this, 'display_domain_analysis_page')
        );
    }

    /**
     * Display domain analysis admin page.
     *
     * @since    1.0.0
     */
    public function display_domain_analysis_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-domain-analysis.php';
    }

    /**
     * AJAX handler for domain analysis.
     *
     * @since    1.0.0
     */
    public function ajax_analyze_domain() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_domain_analysis_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get domain
        $domain = isset($_POST['domain']) ? sanitize_text_field($_POST['domain']) : '';
        
        if (empty($domain)) {
            wp_send_json_error('Please enter a domain.');
            return;
        }
        
        // Validate domain format
        if (!$this->is_valid_domain($domain)) {
            wp_send_json_error('Please enter a valid domain name.');
            return;
        }
        
        // Check if domain analysis exists in database
        $analysis = $this->get_domain_analysis($domain);
        
        if ($analysis) {
            // Check if analysis is recent (less than 7 days old)
            $last_updated = strtotime($analysis->last_updated);
            $days_diff = (time() - $last_updated) / (60 * 60 * 24);
            
            if ($days_diff < 7) {
                // Return cached analysis
                wp_send_json_success(array(
                    'domain' => $domain,
                    'domain_authority' => $analysis->domain_authority,
                    'backlinks' => $analysis->backlinks,
                    'spam_score' => $analysis->spam_score,
                    'analysis_data' => json_decode($analysis->analysis_data, true),
                    'last_updated' => $analysis->last_updated,
                    'cached' => true
                ));
                return;
            }
        }
        
        // Perform domain analysis
        $result = $this->analyze_domain($domain);
        
        if ($result['success']) {
            // Save analysis to database
            $this->save_domain_analysis($domain, $result['data']);
            
            // Return analysis
            wp_send_json_success(array(
                'domain' => $domain,
                'domain_authority' => $result['data']['domain_authority'],
                'backlinks' => $result['data']['backlinks'],
                'spam_score' => $result['data']['spam_score'],
                'analysis_data' => $result['data'],
                'last_updated' => current_time('mysql'),
                'cached' => false
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * Analyze a domain.
     *
     * @since    1.0.0
     * @param    string    $domain    The domain to analyze.
     * @return   array     The analysis result.
     */
    private function analyze_domain($domain) {
        // In a real implementation, this would make API calls to various services
        // For demonstration purposes, we'll simulate the analysis
        
        // Simulate API delay
        sleep(1);
        
        // Generate random data for demonstration
        $domain_authority = rand(1, 100);
        $backlinks = rand(10, 10000);
        $spam_score = rand(1, 100);
        
        // Generate detailed analysis data
        $analysis_data = array(
            'domain_authority' => $domain_authority,
            'backlinks' => $backlinks,
            'spam_score' => $spam_score,
            'top_keywords' => $this->generate_random_keywords(),
            'top_competitors' => $this->generate_random_competitors($domain),
            'seo_issues' => $this->generate_random_seo_issues(),
            'performance_metrics' => array(
                'page_speed' => rand(50, 100),
                'mobile_friendly' => (rand(0, 1) == 1),
                'ssl_enabled' => (rand(0, 10) > 2),
                'responsive' => (rand(0, 10) > 1)
            ),
            'social_metrics' => array(
                'facebook_shares' => rand(0, 5000),
                'twitter_shares' => rand(0, 3000),
                'linkedin_shares' => rand(0, 1000),
                'pinterest_shares' => rand(0, 500)
            ),
            'content_analysis' => array(
                'total_pages' => rand(10, 1000),
                'avg_word_count' => rand(300, 2000),
                'readability_score' => rand(50, 100),
                'content_quality' => rand(50, 100)
            )
        );
        
        return array(
            'success' => true,
            'data' => $analysis_data
        );
    }

    /**
     * Generate random keywords for demonstration.
     *
     * @since    1.0.0
     * @return   array    Random keywords.
     */
    private function generate_random_keywords() {
        $keywords = array(
            'seo', 'digital marketing', 'content marketing', 'social media', 'ppc', 
            'search engine optimization', 'web design', 'wordpress', 'ecommerce', 
            'online marketing', 'affiliate marketing', 'email marketing', 'conversion rate optimization',
            'local seo', 'mobile optimization', 'voice search', 'featured snippets', 'backlinks',
            'keyword research', 'content strategy'
        );
        
        $result = array();
        $count = rand(5, 10);
        
        for ($i = 0; $i < $count; $i++) {
            $keyword = $keywords[array_rand($keywords)];
            
            if (!in_array($keyword, $result)) {
                $result[] = array(
                    'keyword' => $keyword,
                    'volume' => rand(100, 10000),
                    'position' => rand(1, 100),
                    'difficulty' => rand(1, 100)
                );
            }
        }
        
        return $result;
    }

    /**
     * Generate random competitors for demonstration.
     *
     * @since    1.0.0
     * @param    string    $domain    The domain being analyzed.
     * @return   array     Random competitors.
     */
    private function generate_random_competitors($domain) {
        $domains = array(
            'example.com', 'competitor1.com', 'competitor2.com', 'competitor3.com',
            'industry-leader.com', 'topcompany.com', 'bestservice.com', 'premium-solution.com',
            'expert-advice.com', 'professional-service.com', 'top-rated.com', 'industry-best.com'
        );
        
        // Remove the domain being analyzed from the list
        $domains = array_filter($domains, function($item) use ($domain) {
            return $item !== $domain;
        });
        
        $result = array();
        $count = rand(3, 6);
        
        for ($i = 0; $i < $count; $i++) {
            $competitor_domain = $domains[array_rand($domains)];
            
            if (!in_array($competitor_domain, array_column($result, 'domain'))) {
                $result[] = array(
                    'domain' => $competitor_domain,
                    'domain_authority' => rand(1, 100),
                    'common_keywords' => rand(10, 500),
                    'backlinks' => rand(10, 10000),
                    'overlap_score' => rand(1, 100)
                );
            }
        }
        
        return $result;
    }

    /**
     * Generate random SEO issues for demonstration.
     *
     * @since    1.0.0
     * @return   array    Random SEO issues.
     */
    private function generate_random_seo_issues() {
        $issues = array(
            'missing_meta_descriptions' => array(
                'count' => rand(0, 50),
                'severity' => rand(1, 3),
                'impact' => rand(1, 10)
            ),
            'duplicate_title_tags' => array(
                'count' => rand(0, 20),
                'severity' => rand(1, 3),
                'impact' => rand(1, 10)
            ),
            'broken_links' => array(
                'count' => rand(0, 30),
                'severity' => rand(1, 3),
                'impact' => rand(1, 10)
            ),
            'slow_loading_pages' => array(
                'count' => rand(0, 15),
                'severity' => rand(1, 3),
                'impact' => rand(1, 10)
            ),
            'missing_alt_tags' => array(
                'count' => rand(0, 100),
                'severity' => rand(1, 3),
                'impact' => rand(1, 10)
            ),
            'thin_content' => array(
                'count' => rand(0, 25),
                'severity' => rand(1, 3),
                'impact' => rand(1, 10)
            )
        );
        
        return $issues;
    }

    /**
     * Get domain analysis from database.
     *
     * @since    1.0.0
     * @param    string    $domain    The domain to get analysis for.
     * @return   object|false    The analysis object or false if not found.
     */
    private function get_domain_analysis($domain) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rankolab_domain_analysis';
        
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE domain = %s", $domain));
    }

    /**
     * Save domain analysis to database.
     *
     * @since    1.0.0
     * @param    string    $domain         The domain being analyzed.
     * @param    array     $analysis_data  The analysis data.
     */
    private function save_domain_analysis($domain, $analysis_data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rankolab_domain_analysis';
        
        $existing = $this->get_domain_analysis($domain);
        
        if ($existing) {
            // Update existing record
            $wpdb->update(
                $table_name,
                array(
                    'domain_authority' => $analysis_data['domain_authority'],
                    'backlinks' => $analysis_data['backlinks'],
                    'spam_score' => $analysis_data['spam_score'],
                    'analysis_data' => json_encode($analysis_data),
                    'last_updated' => current_time('mysql')
                ),
                array('domain' => $domain),
                array('%d', '%d', '%d', '%s', '%s'),
                array('%s')
            );
        } else {
            // Insert new record
            $wpdb->insert(
                $table_name,
                array(
                    'domain' => $domain,
                    'domain_authority' => $analysis_data['domain_authority'],
                    'backlinks' => $analysis_data['backlinks'],
                    'spam_score' => $analysis_data['spam_score'],
                    'analysis_data' => json_encode($analysis_data),
                    'last_updated' => current_time('mysql')
                ),
                array('%s', '%d', '%d', '%d', '%s', '%s')
            );
        }
    }

    /**
     * Validate domain format.
     *
     * @since    1.0.0
     * @param    string    $domain    The domain to validate.
     * @return   boolean   True if valid, false otherwise.
     */
    private function is_valid_domain($domain) {
        return (preg_match("/^([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*$/i", $domain) //valid chars check
                && preg_match("/^.{1,253}$/", $domain) //overall length check
                && preg_match("/^[^\.]{1,63}(\.[^\.]{1,63})*$/", $domain)); //length of each label
    }
}
