<!-- Rankolab AI Charlotte Assistant Module Template -->
<div class="rankolab-ai-charlotte-assistant-module" id="rankolab-ai-charlotte-assistant">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>AI Charlotte Assistant</h2>
            <p>Your intelligent AI assistant for content creation, analysis, and optimization.</p>
        </div>
    </div>
    
    <!-- Charlotte Assistant Interface -->
    <div class="rankolab-row">
        <!-- Left Column: Chat Interface -->
        <div class="rankolab-col rankolab-col-8">
            <div class="rankolab-card rankolab-card-primary">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">
                        <i class="fas fa-robot"></i> Charlotte Assistant
                    </h3>
                    <div class="rankolab-card-actions">
                        <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-light" id="rankolab-charlotte-clear">
                            <i class="fas fa-eraser"></i> Clear Chat
                        </button>
                    </div>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-charlotte-chat-container">
                        <div class="rankolab-charlotte-chat" id="rankolab-charlotte-chat">
                            <!-- Welcome Message -->
                            <div class="rankolab-charlotte-message rankolab-charlotte-assistant">
                                <div class="rankolab-charlotte-avatar">
                                    <i class="fas fa-robot"></i>
                                </div>
                                <div class="rankolab-charlotte-message-content">
                                    <div class="rankolab-charlotte-message-text">
                                        <p>Hello! I'm Charlotte, your AI assistant for content creation and optimization. How can I help you today?</p>
                                    </div>
                                    <div class="rankolab-charlotte-message-time">Just now</div>
                                </div>
                            </div>
                            
                            <!-- Sample User Message -->
                            <?php if ($show_sample_conversation): ?>
                            <div class="rankolab-charlotte-message rankolab-charlotte-user">
                                <div class="rankolab-charlotte-avatar">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="rankolab-charlotte-message-content">
                                    <div class="rankolab-charlotte-message-text">
                                        <p>Can you help me optimize my latest blog post for SEO?</p>
                                    </div>
                                    <div class="rankolab-charlotte-message-time">Just now</div>
                                </div>
                            </div>
                            
                            <!-- Sample Assistant Response -->
                            <div class="rankolab-charlotte-message rankolab-charlotte-assistant">
                                <div class="rankolab-charlotte-avatar">
                                    <i class="fas fa-robot"></i>
                                </div>
                                <div class="rankolab-charlotte-message-content">
                                    <div class="rankolab-charlotte-message-text">
                                        <p>I'd be happy to help optimize your blog post for SEO! Please share the post URL or content, and let me know what keywords you're targeting.</p>
                                    </div>
                                    <div class="rankolab-charlotte-message-time">Just now</div>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <!-- Dynamic Messages Will Be Added Here -->
                        </div>
                    </div>
                    
                    <div class="rankolab-charlotte-input">
                        <form id="rankolab-charlotte-form">
                            <div class="rankolab-input-group">
                                <textarea id="rankolab-charlotte-prompt" class="rankolab-form-control" placeholder="Ask Charlotte anything about content creation, SEO, or website optimization..." rows="2"></textarea>
                                <div class="rankolab-input-group-append">
                                    <button type="submit" class="rankolab-btn rankolab-btn-primary">
                                        <i class="fas fa-paper-plane"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Content Analysis -->
            <div class="rankolab-card">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">Content Analysis</h3>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-content-analysis-form">
                        <div class="rankolab-form-group">
                            <label for="rankolab-content-url" class="rankolab-form-label">Analyze Content</label>
                            <div class="rankolab-input-group">
                                <input type="text" id="rankolab-content-url" class="rankolab-form-control" placeholder="Enter post URL or ID">
                                <div class="rankolab-input-group-append">
                                    <button id="rankolab-analyze-content" class="rankolab-btn rankolab-btn-primary">
                                        <i class="fas fa-search"></i> Analyze
                                    </button>
                                </div>
                            </div>
                            <div class="rankolab-form-text">Enter a post URL or ID to analyze its content quality, readability, and SEO performance.</div>
                        </div>
                    </div>
                    
                    <div id="rankolab-content-analysis-results" style="display: none;">
                        <div class="rankolab-content-analysis-summary">
                            <div class="rankolab-content-analysis-score">
                                <div class="rankolab-score-circle">
                                    <svg viewBox="0 0 36 36" class="rankolab-score-chart">
                                        <path class="rankolab-score-circle-bg"
                                            d="M18 2.0845
                                            a 15.9155 15.9155 0 0 1 0 31.831
                                            a 15.9155 15.9155 0 0 1 0 -31.831"
                                        />
                                        <path class="rankolab-score-circle-fill"
                                            stroke-dasharray="85, 100"
                                            d="M18 2.0845
                                            a 15.9155 15.9155 0 0 1 0 31.831
                                            a 15.9155 15.9155 0 0 1 0 -31.831"
                                        />
                                        <text x="18" y="20.35" class="rankolab-score-text">85</text>
                                    </svg>
                                </div>
                                <div class="rankolab-score-label">Overall Score</div>
                            </div>
                            <div class="rankolab-content-analysis-metrics">
                                <div class="rankolab-metric">
                                    <div class="rankolab-metric-value">92</div>
                                    <div class="rankolab-metric-label">Readability</div>
                                </div>
                                <div class="rankolab-metric">
                                    <div class="rankolab-metric-value">78</div>
                                    <div class="rankolab-metric-label">SEO</div>
                                </div>
                                <div class="rankolab-metric">
                                    <div class="rankolab-metric-value">88</div>
                                    <div class="rankolab-metric-label">Engagement</div>
                                </div>
                                <div class="rankolab-metric">
                                    <div class="rankolab-metric-value">82</div>
                                    <div class="rankolab-metric-label">Structure</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="rankolab-tabs" data-tab-group="content-analysis">
                            <div class="rankolab-tab-link active" data-tab-target="readability">Readability</div>
                            <div class="rankolab-tab-link" data-tab-target="seo">SEO</div>
                            <div class="rankolab-tab-link" data-tab-target="engagement">Engagement</div>
                            <div class="rankolab-tab-link" data-tab-target="structure">Structure</div>
                        </div>
                        
                        <div class="rankolab-tab-content active" data-tab-group="content-analysis" data-tab-id="readability">
                            <div class="rankolab-readability-analysis">
                                <div class="rankolab-readability-score">
                                    <div class="rankolab-readability-level">Very Good</div>
                                    <div class="rankolab-readability-grade">Grade Level: 7th-8th Grade</div>
                                </div>
                                
                                <div class="rankolab-readability-metrics">
                                    <div class="rankolab-readability-metric">
                                        <div class="rankolab-readability-metric-label">Average Sentence Length</div>
                                        <div class="rankolab-readability-metric-value">18 words</div>
                                        <div class="rankolab-readability-metric-bar">
                                            <div class="rankolab-progress">
                                                <div class="rankolab-progress-bar rankolab-bg-success" style="width: 75%"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="rankolab-readability-metric">
                                        <div class="rankolab-readability-metric-label">Complex Words</div>
                                        <div class="rankolab-readability-metric-value">12%</div>
                                        <div class="rankolab-readability-metric-bar">
                                            <div class="rankolab-progress">
                                                <div class="rankolab-progress-bar rankolab-bg-success" style="width: 88%"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="rankolab-readability-metric">
                                        <div class="rankolab-readability-metric-label">Passive Voice</div>
                                        <div class="rankolab-readability-metric-value">8%</div>
                                        <div class="rankolab-readability-metric-bar">
                                            <div class="rankolab-progress">
                                                <div class="rankolab-progress-bar rankolab-bg-success" style="width: 92%"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="rankolab-readability-metric">
                                        <div class="rankolab-readability-metric-label">Paragraph Length</div>
                                        <div class="rankolab-readability-metric-value">3.2 sentences</div>
                                        <div class="rankolab-readability-metric-bar">
                                            <div class="rankolab-progress">
                                                <div class="rankolab-progress-bar rankolab-bg-success" style="width: 95%"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="rankolab-readability-suggestions">
                                    <div class="rankolab-section-title">Improvement Suggestions</div>
                                    <div class="rankolab-suggestions-list">
                                        <div class="rankolab-suggestion-item">
                                            <div class="rankolab-suggestion-icon rankolab-suggestion-success">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <div class="rankolab-suggestion-content">
                                                <div class="rankolab-suggestion-title">Good sentence length variety</div>
                                                <div class="rankolab-suggestion-description">Your content has a good mix of short and long sentences, which improves readability and engagement.</div>
                                            </div>
                                        </div>
                                        <div class="rankolab-suggestion-item">
                                            <div class="rankolab-suggestion-icon rankolab-suggestion-warning">
                                                <i class="fas fa-exclamation-circle"></i>
                                            </div>
                                            <div class="rankolab-suggestion-content">
                                                <div class="rankolab-suggestion-title">Consider simplifying some complex words</div>
                                                <div class="rankolab-suggestion-description">Replace words like "utilization" with "use" and "implementation" with "setup" to improve readability.</div>
                                            </div>
                                        </div>
                                        <div class="rankolab-suggestion-item">
                                            <div class="rankolab-suggestion-icon rankolab-suggestion-success">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <div class="rankolab-suggestion-content">
                                                <div class="rankolab-suggestion-title">Good use of active voice</div>
                                                <div class="rankolab-suggestion-description">Your content primarily uses active voice, which makes it more engaging and easier to unders
(Content truncated due to size limit. Use line ranges to read in chunks)