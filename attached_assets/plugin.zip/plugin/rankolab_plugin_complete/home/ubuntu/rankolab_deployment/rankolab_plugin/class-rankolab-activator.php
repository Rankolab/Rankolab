<?php
/**
 * Fired during plugin activation
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Activator {

    /**
     * Activate the plugin.
     *
     * Sets up the database tables, default options, and activation hooks.
     *
     * @since    1.0.0
     */
    public static function activate() {
        global $wpdb;
        
        // Set activation flag to redirect to setup wizard
        set_transient('rankolab_activation_redirect', true, 30);
        
        // Create database tables if they don't exist
        self::create_tables();
        
        // Set default options
        self::set_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();

        // Call activate methods for modules that have them
        if (class_exists(\'Rankolab_Cache_Management\') && method_exists(\'Rankolab_Cache_Management\', \'activate\')) {
            Rankolab_Cache_Management::activate();
        }
        if (class_exists(\'Rankolab_Newsletter\') && method_exists(\'Rankolab_Newsletter\', \'activate\')) {
            Rankolab_Newsletter::activate();
        }
        if (class_exists(\'Rankolab_Error_Logging\') && method_exists(\'Rankolab_Error_Logging\', \'activate\')) {
            Rankolab_Error_Logging::activate();
        }
    }
    
    /**
     * Create the necessary database tables.
     *
     * @since    1.0.0
     */
    private static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // License keys table
        $table_name = $wpdb->prefix . 'rankolab_license_keys';
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            license_key varchar(255) NOT NULL,
            user_id bigint(20) UNSIGNED NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            created_date datetime NOT NULL,
            expiration_date datetime NOT NULL,
            last_verification datetime DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY license_key (license_key),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        // Subscriptions table
        $table_name = $wpdb->prefix . 'rankolab_subscriptions';
        
        $sql .= "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            plan_type varchar(50) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            start_date datetime NOT NULL,
            end_date datetime NOT NULL,
            payment_method varchar(50) DEFAULT NULL,
            payment_id varchar(255) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        // Affiliate tracking table
        $table_name = $wpdb->prefix . 'rankolab_affiliate_tracking';
        
        $sql .= "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            affiliate_id varchar(255) NOT NULL,
            network varchar(100) NOT NULL,
            clicks int(11) NOT NULL DEFAULT '0',
            conversions int(11) NOT NULL DEFAULT '0',
            earnings decimal(10,2) NOT NULL DEFAULT '0.00',
            last_updated datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        // Blog posts table
        $table_name = $wpdb->prefix . 'rankolab_blog_posts';
        
        $sql .= "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id bigint(20) UNSIGNED NOT NULL,
            author_id bigint(20) UNSIGNED NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'draft',
            social_shares int(11) NOT NULL DEFAULT '0',
            last_updated datetime NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY author_id (author_id)
        ) $charset_collate;";
        
        // Content generation table
        $table_name = $wpdb->prefix . 'rankolab_content_generation';
        
        $sql .= "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            title varchar(255) NOT NULL,
            content longtext NOT NULL,
            content_type varchar(50) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'draft',
            created_date datetime NOT NULL,
            modified_date datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        // SEO analysis table
        $table_name = $wpdb->prefix . 'rankolab_seo_analysis';
        
        $sql .= "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id bigint(20) UNSIGNED NOT NULL,
            focus_keyword varchar(255) NOT NULL,
            seo_score int(11) NOT NULL DEFAULT '0',
            readability_score int(11) NOT NULL DEFAULT '0',
            analysis_data longtext NOT NULL,
            last_updated datetime NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id)
        ) $charset_collate;";
        
        // Domain analysis table
        $table_name = $wpdb->prefix . 'rankolab_domain_analysis';
        
        $sql .= "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            domain varchar(255) NOT NULL,
            domain_authority int(11) NOT NULL DEFAULT '0',
            backlinks int(11) NOT NULL DEFAULT '0',
            spam_score int(11) NOT NULL DEFAULT '0',
            analysis_data longtext NOT NULL,
            last_updated datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY domain (domain)
        ) $charset_collate;";
        
        // Execute the SQL statements
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Insert master license key if it doesn't exist
        $table_name = $wpdb->prefix . 'rankolab_license_keys';
        $master_key = 'RANKO-MASTER-2025-XYZ123';
        
        $existing_key = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE license_key = %s", $master_key));
        
        if (!$existing_key) {
            $wpdb->insert(
                $table_name,
                array(
                    'license_key' => $master_key,
                    'user_id' => 1,
                    'status' => 'active',
                    'created_date' => current_time('mysql'),
                    'expiration_date' => date('Y-m-d H:i:s', strtotime('+10 years')),
                    'last_verification' => current_time('mysql')
                ),
                array('%s', '%d', '%s', '%s', '%s', '%s')
            );
        }
    }
    
    /**
     * Set default options.
     *
     * @since    1.0.0
     */
    private static function set_default_options() {
        // Plugin version
        if (!get_option('rankolab_version')) {
            add_option('rankolab_version', '1.0.0');
        }
        
        // Wizard completion status
        if (!get_option('rankolab_wizard_completed')) {
            add_option('rankolab_wizard_completed', 'no');
        }
        
        // License key
        if (!get_option('rankolab_license_key')) {
            add_option('rankolab_license_key', '');
        }
        
        // License status
        if (!get_option('rankolab_license_status')) {
            add_option('rankolab_license_status', '');
        }
        
        // Subscription plans
        if (!get_option('rankolab_subscription_plans')) {
            $plans = array(
                'trial' => array(
                    'price' => '1',
                    'duration' => '7day',
                    'features' => array(
                        'Content Generation',
                        'SEO Optimization'
                    )
                ),
                'monthly' => array(
                    'price' => '39',
                    'duration' => 'month',
                    'features' => array(
                        'Setup Wizard',
                        'License Verification',
                        'Domain Analysis',
                        'Niche Suggestion & Optimization',
                        'AI Website Design',
                        'Content Strategy & Keyword Analysis',
                        'Content Planning',
                        'Content Generation',
                        'SEO Optimization',
                        'Social Media Integration',
                        'Link Building',
                        'Website Monitoring & Maintenance',
                        'AdSense Optimization',
                        'AI Charlotte Assistant',
                        'Affiliate Management',
                        'Link Management',
                        'Dashboard'
                    )
                ),
                'yearly' => array(
                    'price' => '399',
                    'duration' => 'year',
                    'features' => array(
                        'Setup Wizard',
                        'License Verification',
                        'Domain Analysis',
                        'Niche Suggestion & Optimization',
                        'AI Website Design',
                        'Content Strategy & Keyword Analysis',
                        'Content Planning',
                        'Content Generation',
                        'SEO Optimization',
                        'Social Media Integration',
                        'Link Building',
                        'Website Monitoring & Maintenance',
                        'AdSense Optimization',
                        'AI Charlotte Assistant',
                        'Affiliate Management',
                        'Link Management',
                        'Dashboard'
                    )
                )
            );
            
            add_option('rankolab_subscription_plans', $plans);
        }
        
        // Demo site URL
        if (!get_option('rankolab_demo_site_url')) {
            add_option('rankolab_demo_site_url', 'https://demo.rankolab.com');
        }
        
        // API connections
        if (!get_option('rankolab_api_connections')) {
            $api_connections = array(
                'google_search_console' => array(
                    'connected' => false,
                    'api_key' => '',
                    'last_connected' => ''
                ),
                'unsplash' => array(
                    'connected' => false,
                    'api_key' => '',
                    'last_connected' => ''
                ),
                'social_media' => array(
                    'connected' => false,
                    'platforms' => array(
                        'facebook' => false,
                        'twitter' => false,
                        'linkedin' => false,
                        'instagram' => false
                    ),
                    'last_connected' => ''
                )
            );
            
            add_option('rankolab_api_connections', $api_connections);
        }
        
        // Content generation settings
        if (!get_option('rankolab_content_generation_settings')) {
            $content_settings = array(
                'default_length' => 'medium', // short, medium, long
                'default_tone' => 'professional', // casual, professional, conversational, formal
                'include_images' => true,
                'image_source' => 'unsplash',
                'plagiarism_check' => true,
                'readability_target' => 'grade8' // grade6, grade8, grade10, grade12
            );
            
            add_option('rankolab_content_generation_settings', $content_settings);
        }
        
        // SEO settings
        if (!get_option('rankolab_seo_settings')) {
            $seo_settings = array(
                'auto_optimize' => true,
                'focus_keyword_limit' => 5,
                'meta_description_length' => 160,
                'title_length' => 60,
                'auto_internal_linking' => true,
                'submit_to_search_console' => true
            );
            
            add_option('rankolab_seo_settings', $seo_settings);
        }
    }
}
