<?php
/**
 * Partial template for displaying the Cache Management settings page.
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin/partials
 * @since      1.1.0
 */

if (!defined(\'WPINC\')) {
    die;
}

// Ensure the class instance is available if needed for data (though most data comes from settings API)
// Example: global $rankolab_cache_management_instance;

?>
<div class="wrap rankolab-admin-page">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <form method="post" action="options.php">
        <?php
        settings_fields(\'rankolab_cache_options\'); // Must match register_setting group
        do_settings_sections(\'rankolab-cache-management\'); // Must match add_settings_section page slug
        submit_button();
        ?>
    </form>

    <hr>

    <h2><?php _e(\'Manual Cache Clearing\', \'rankolab\'); ?></h2>
    <p><?php _e(\'Manually clear all detected caches now.\', \'rankolab\'); ?></p>
    <button id="rankolab-manual-clear-cache" class="button button-secondary">
        <?php _e(\'Clear Cache Now\', \'rankolab\'); ?>
    </button>
    <span id="rankolab-clear-cache-status" style="margin-left: 10px;"></span>
    <p class="description"><?php _e(\'Last manual clear:\', \'rankolab\'); ?> <span id="rankolab-last-manual-clear"><?php echo esc_html(get_option(\'rankolab_last_manual_cache_clear\") ?: __(\'Never\', \'rankolab\')); ?></span></p>
</div>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(\'#rankolab-manual-clear-cache\').on(\'click\
            var button = $(this);
            var statusSpan = $(\'#rankolab-clear-cache-status\
            var lastClearSpan = $(\'#rankolab-last-manual-clear\

            button.prop(\'disabled\
            statusSpan.text(\'<?php echo esc_js(__("Clearing...\")); ?>\

            $.post(ajaxurl, {
                action: \'rankolab_manual_cache_clear\
                _ajax_nonce: \'<?php echo wp_create_nonce("rankolab_manual_cache_clear_nonce"); ?>\'
            }, function(response) {
                button.prop(\'disabled\
                if (response.success) {
                    statusSpan.text(response.data.message).css(\'color\
                    lastClearSpan.text(response.data.last_clear_time);
                } else {
                    statusSpan.text(response.data.message).css(\'color\
                }
                // Clear status message after 5 seconds
                setTimeout(function() {
                    statusSpan.text(\'\
                }, 5000);
            });
        });
    });
</script>

