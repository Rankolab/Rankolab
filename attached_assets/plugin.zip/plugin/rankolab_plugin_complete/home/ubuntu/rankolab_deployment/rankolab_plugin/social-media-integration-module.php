<!-- Rankolab Social Media Integration Module Template -->
<div class="rankolab-social-media-integration-module" id="rankolab-social-media-integration">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Social Media Integration</h2>
            <p>Connect, manage, and analyze your social media accounts to enhance your online presence.</p>
        </div>
    </div>
    
    <!-- Connected Accounts -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Connected Accounts</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-connect-account">
                    <i class="fas fa-plus"></i> Connect New Account
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <?php if (!empty($connected_accounts)): ?>
                <div class="rankolab-connected-accounts">
                    <?php foreach ($connected_accounts as $account): ?>
                        <div class="rankolab-connected-account">
                            <div class="rankolab-account-icon rankolab-platform-<?php echo esc_attr($account['platform']); ?>">
                                <i class="fab fa-<?php echo esc_attr($account['platform']); ?>"></i>
                            </div>
                            <div class="rankolab-account-info">
                                <div class="rankolab-account-name"><?php echo esc_html($account['name']); ?></div>
                                <div class="rankolab-account-handle"><?php echo esc_html($account['handle']); ?></div>
                            </div>
                            <div class="rankolab-account-status <?php echo $account['status'] === 'connected' ? 'connected' : 'error'; ?>">
                                <?php if ($account['status'] === 'connected'): ?>
                                    <i class="fas fa-check-circle"></i> Connected
                                <?php else: ?>
                                    <i class="fas fa-exclamation-circle"></i> Connection Error
                                <?php endif; ?>
                            </div>
                            <div class="rankolab-account-actions">
                                <div class="rankolab-btn-group">
                                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-account-settings" data-account-id="<?php echo esc_attr($account['id']); ?>">
                                        <i class="fas fa-cog"></i>
                                    </button>
                                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger rankolab-account-disconnect" data-account-id="<?php echo esc_attr($account['id']); ?>">
                                        <i class="fas fa-unlink"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="rankolab-empty-state">
                    <div class="rankolab-empty-state-icon">
                        <i class="fas fa-share-alt"></i>
                    </div>
                    <div class="rankolab-empty-state-text">No social media accounts connected yet. Click "Connect New Account" to get started.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Social Media Post Creator -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Create Social Media Post</h3>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-form-group">
                <label for="rankolab-post-content" class="rankolab-form-label">Post Content</label>
                <textarea id="rankolab-post-content" class="rankolab-form-control" rows="4" placeholder="Enter your post content here..."></textarea>
                <div class="rankolab-character-counter">
                    <span id="rankolab-character-count">0</span> / <span id="rankolab-character-limit">280</span> characters
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label class="rankolab-form-label">Add Media</label>
                <div class="rankolab-media-uploader">
                    <div class="rankolab-media-preview" id="rankolab-media-preview">
                        <div class="rankolab-media-placeholder">
                            <i class="fas fa-image"></i>
                            <span>Add images or videos</span>
                        </div>
                    </div>
                    <div class="rankolab-media-actions">
                        <button id="rankolab-upload-media" class="rankolab-btn rankolab-btn-outline-primary">
                            <i class="fas fa-upload"></i> Upload Media
                        </button>
                        <button id="rankolab-media-library" class="rankolab-btn rankolab-btn-outline-secondary">
                            <i class="fas fa-photo-video"></i> Media Library
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label class="rankolab-form-label">Post To</label>
                <div class="rankolab-post-platforms">
                    <?php if (!empty($connected_accounts)): ?>
                        <?php foreach ($connected_accounts as $account): ?>
                            <?php if ($account['status'] === 'connected'): ?>
                                <div class="rankolab-platform-option">
                                    <div class="rankolab-form-check">
                                        <input type="checkbox" id="rankolab-platform-<?php echo esc_attr($account['id']); ?>" class="rankolab-form-check-input" checked>
                                        <label for="rankolab-platform-<?php echo esc_attr($account['id']); ?>" class="rankolab-form-check-label">
                                            <i class="fab fa-<?php echo esc_attr($account['platform']); ?>"></i>
                                            <?php echo esc_html($account['name']); ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="rankolab-empty-state rankolab-empty-state-small">
                            No connected accounts available. Please connect at least one social media account.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="rankolab-row">
                <div class="rankolab-col rankolab-col-6">
                    <div class="rankolab-form-group">
                        <label for="rankolab-post-schedule" class="rankolab-form-label">Schedule Post</label>
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-post-schedule" class="rankolab-form-check-input">
                            <label for="rankolab-post-schedule" class="rankolab-form-check-label">Schedule for later</label>
                        </div>
                    </div>
                </div>
                <div class="rankolab-col rankolab-col-6" id="rankolab-schedule-options" style="display: none;">
                    <div class="rankolab-form-group">
                        <label for="rankolab-schedule-datetime" class="rankolab-form-label">Date & Time</label>
                        <input type="datetime-local" id="rankolab-schedule-datetime" class="rankolab-form-control">
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <div class="rankolab-form-check">
                    <input type="checkbox" id="rankolab-optimize-timing" class="rankolab-form-check-input">
                    <label for="rankolab-optimize-timing" class="rankolab-form-check-label">Optimize posting time for maximum engagement</label>
                </div>
            </div>
            
            <div class="rankolab-form-actions">
                <button id="rankolab-save-draft" class="rankolab-btn rankolab-btn-secondary">
                    <i class="fas fa-save"></i> Save as Draft
                </button>
                <button id="rankolab-post-now" class="rankolab-btn rankolab-btn-primary">
                    <i class="fas fa-paper-plane"></i> Post Now
                </button>
                <button id="rankolab-schedule-post" class="rankolab-btn rankolab-btn-success" style="display: none;">
                    <i class="fas fa-clock"></i> Schedule Post
                </button>
            </div>
        </div>
    </div>
    
    <!-- Post Calendar -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Post Calendar</h3>
            <div class="rankolab-card-actions">
                <div class="rankolab-btn-group">
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary active" id="rankolab-calendar-month">
                        Month
                    </button>
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" id="rankolab-calendar-week">
                        Week
                    </button>
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" id="rankolab-calendar-list">
                        List
                    </button>
                </div>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-calendar-container" id="rankolab-post-calendar">
                <!-- Calendar will be rendered here -->
                <div class="rankolab-calendar-loading">
                    <div class="rankolab-spinner"></div>
                    <div>Loading calendar...</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Social Media Analytics -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Social Media Analytics</h3>
            <div class="rankolab-card-actions">
                <div class="rankolab-form-group rankolab-mb-0">
                    <select id="rankolab-analytics-timeframe" class="rankolab-form-control rankolab-form-control-sm">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                        <option value="365">Last Year</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="rankolab-card-body">
            <!-- Analytics Overview -->
            <div class="rankolab-analytics-overview">
                <div class="rankolab-analytics-metric">
                    <div class="rankolab-analytics-metric-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="rankolab-analytics-metric-value">12,458</div>
                    <div class="rankolab-analytics-metric-label">Total Impressions</div>
                    <div class="rankolab-analytics-metric-change positive">
                        <i class="fas fa-arrow-up"></i> 8.3%
                    </div>
                </div>
                <div class="rankolab-analytics-metric">
                    <div class="rankolab-analytics-metric-icon">
                        <i class="fas fa-thumbs-up"></i>
                    </div>
                    <div class="rankolab-analytics-metric-value">3,271</div>
                    <div class="rankolab-analytics-metric-label">Total Engagements</div>
                    <div class="rankolab-analytics-metric-change positive">
                        <i class="fas fa-arrow-up"></i> 12.5%
                    </div>
                </div>
                <div class="rankolab-analytics-metric">
                    <div class="rankolab-analytics-metric-icon">
                        <i class="fas fa-share-alt"></i>
                    </div>
                    <div class="rankolab-analytics-metric-value">845</div>
                    <div class="rankolab-analytics-metric-label">Total Shares</div>
                    <div class="rankolab-analytics-metric-change positive">
                        <i class="fas fa-arrow-up"></i> 5.2%
                    </div>
                </div>
                <div class="rankolab-analytics-metric">
                    <div class="rankolab-analytics-metric-icon">
                        <i class="fas fa-link"></i>
                    </div>
                    <div class="rankolab-analytics-metric-value">1,892</div>
                    <div class="rankolab-analytics-metric-label">Link Clicks</div>
                    <div class="rankolab-analytics-metric-change positive">
                        <i class="fas fa-arrow-up"></i> 15.7%
                    </div>
                </div>
            </div>
            
            <!-- Analytics Charts -->
            <div class="rankolab-row">
                <div class="rankolab-col rankolab-col-6">
                    <div class="rankolab-chart-container">
                        <canvas id="rankolab-engagement-chart"></canvas>
                    </div>
                    <div class="rankolab-chart-title">Engagement by Platform</div>
                </div>
                <div class="rankolab-col rankolab-col-6">
                    <div class="rankolab-chart-container">
                        <canvas id="rankolab-impressions-chart"></canvas>
                    </div>
                    <div class="rankolab-chart-title">Impressions Over Time</div>
                </div>
            </div>
            
            <!-- Best Performing Posts -->
            <div class="rankolab-section-title">Best Performing Posts</div>
            <div class="rankolab-table-responsive">
                <table class="rankolab-table rankolab-table-hover">
                    <thead>
                        <tr>
                            <th>Post</th>
                            <th>Platform</th>
                            <th>Date</th>
                            <th>Impressions</th>
                            <th>Engagement</th>
                            <th>Engagement Rate</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($top_posts)): ?>
                            <?php foreach ($top_posts as $post): ?>
                                <tr>
                                    <td>
                                        <div class="rankolab-post-preview">
                                            <?php if (!empty($post['image'])): ?>
                                                <div class="rankolab-post-image">
                                                    <img src="<?php echo esc_url($post['image']); ?>" alt="Post image">
                                                </div>
                                            <?php endif; ?>
                                            <div
(Content truncated due to size limit. Use line ranges to read in chunks)