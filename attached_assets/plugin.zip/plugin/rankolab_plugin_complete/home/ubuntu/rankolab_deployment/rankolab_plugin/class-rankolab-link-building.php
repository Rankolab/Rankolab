<?php
/**
 * The file that defines the link building module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The link building module class.
 *
 * This class handles link building functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Link_Building {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_find_link_opportunities', array($this, 'ajax_find_link_opportunities'));
        add_action('wp_ajax_rankolab_analyze_backlinks', array($this, 'ajax_analyze_backlinks'));
        add_action('wp_ajax_rankolab_save_link_prospect', array($this, 'ajax_save_link_prospect'));
        add_action('wp_ajax_rankolab_update_prospect_status', array($this, 'ajax_update_prospect_status'));
        add_action('wp_ajax_rankolab_generate_outreach_email', array($this, 'ajax_generate_outreach_email'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_link_building_page'), 20);
        
        // Register post type for link prospects
        add_action('init', array($this, 'register_link_prospect_post_type'));
        
        // Add meta boxes
        add_action('add_meta_boxes', array($this, 'add_link_prospect_meta_boxes'));
        
        // Save post meta
        add_action('save_post_rankolab_prospect', array($this, 'save_link_prospect_meta'));
    }

    /**
     * Add link building admin page.
     *
     * @since    1.0.0
     */
    public function add_link_building_page() {
        add_submenu_page(
            'rankolab',
            'Link Building',
            'Link Building',
            'manage_options',
            'rankolab-link-building',
            array($this, 'display_link_building_page')
        );
    }

    /**
     * Display link building admin page.
     *
     * @since    1.0.0
     */
    public function display_link_building_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-link-building.php';
    }

    /**
     * Register link prospect post type.
     *
     * @since    1.0.0
     */
    public function register_link_prospect_post_type() {
        $labels = array(
            'name'                  => _x('Link Prospects', 'Post type general name', 'rankolab'),
            'singular_name'         => _x('Link Prospect', 'Post type singular name', 'rankolab'),
            'menu_name'             => _x('Link Prospects', 'Admin Menu text', 'rankolab'),
            'name_admin_bar'        => _x('Link Prospect', 'Add New on Toolbar', 'rankolab'),
            'add_new'               => __('Add New', 'rankolab'),
            'add_new_item'          => __('Add New Link Prospect', 'rankolab'),
            'new_item'              => __('New Link Prospect', 'rankolab'),
            'edit_item'             => __('Edit Link Prospect', 'rankolab'),
            'view_item'             => __('View Link Prospect', 'rankolab'),
            'all_items'             => __('All Link Prospects', 'rankolab'),
            'search_items'          => __('Search Link Prospects', 'rankolab'),
            'parent_item_colon'     => __('Parent Link Prospects:', 'rankolab'),
            'not_found'             => __('No link prospects found.', 'rankolab'),
            'not_found_in_trash'    => __('No link prospects found in Trash.', 'rankolab'),
            'featured_image'        => _x('Website Screenshot', 'Overrides the "Featured Image" phrase', 'rankolab'),
            'set_featured_image'    => _x('Set website screenshot', 'Overrides the "Set featured image" phrase', 'rankolab'),
            'remove_featured_image' => _x('Remove website screenshot', 'Overrides the "Remove featured image" phrase', 'rankolab'),
            'use_featured_image'    => _x('Use as website screenshot', 'Overrides the "Use as featured image" phrase', 'rankolab'),
            'archives'              => _x('Link Prospect archives', 'The post type archive label used in nav menus', 'rankolab'),
            'insert_into_item'      => _x('Insert into link prospect', 'Overrides the "Insert into post" phrase', 'rankolab'),
            'uploaded_to_this_item' => _x('Uploaded to this link prospect', 'Overrides the "Uploaded to this post" phrase', 'rankolab'),
            'filter_items_list'     => _x('Filter link prospects list', 'Screen reader text for the filter links heading on the post type listing screen', 'rankolab'),
            'items_list_navigation' => _x('Link Prospects list navigation', 'Screen reader text for the pagination heading on the post type listing screen', 'rankolab'),
            'items_list'            => _x('Link Prospects list', 'Screen reader text for the items list heading on the post type listing screen', 'rankolab'),
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => false,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'link-prospect'),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array('title', 'editor', 'thumbnail'),
        );
        
        register_post_type('rankolab_prospect', $args);
        
        // Register taxonomy for prospect status
        $status_labels = array(
            'name'              => _x('Statuses', 'taxonomy general name', 'rankolab'),
            'singular_name'     => _x('Status', 'taxonomy singular name', 'rankolab'),
            'search_items'      => __('Search Statuses', 'rankolab'),
            'all_items'         => __('All Statuses', 'rankolab'),
            'parent_item'       => __('Parent Status', 'rankolab'),
            'parent_item_colon' => __('Parent Status:', 'rankolab'),
            'edit_item'         => __('Edit Status', 'rankolab'),
            'update_item'       => __('Update Status', 'rankolab'),
            'add_new_item'      => __('Add New Status', 'rankolab'),
            'new_item_name'     => __('New Status Name', 'rankolab'),
            'menu_name'         => __('Status', 'rankolab'),
        );
        
        $status_args = array(
            'hierarchical'      => true,
            'labels'            => $status_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'prospect-status'),
        );
        
        register_taxonomy('prospect_status', array('rankolab_prospect'), $status_args);
        
        // Add default statuses
        $default_statuses = array(
            'new' => 'New',
            'contacted' => 'Contacted',
            'negotiating' => 'Negotiating',
            'accepted' => 'Accepted',
            'rejected' => 'Rejected',
            'completed' => 'Completed'
        );
        
        foreach ($default_statuses as $slug => $name) {
            if (!term_exists($name, 'prospect_status')) {
                wp_insert_term($name, 'prospect_status', array('slug' => $slug));
            }
        }
    }

    /**
     * Add meta boxes for link prospect post type.
     *
     * @since    1.0.0
     */
    public function add_link_prospect_meta_boxes() {
        add_meta_box(
            'rankolab_prospect_details',
            __('Prospect Details', 'rankolab'),
            array($this, 'render_prospect_details_meta_box'),
            'rankolab_prospect',
            'normal',
            'high'
        );
        
        add_meta_box(
            'rankolab_prospect_metrics',
            __('Website Metrics', 'rankolab'),
            array($this, 'render_prospect_metrics_meta_box'),
            'rankolab_prospect',
            'side',
            'default'
        );
        
        add_meta_box(
            'rankolab_prospect_outreach',
            __('Outreach History', 'rankolab'),
            array($this, 'render_prospect_outreach_meta_box'),
            'rankolab_prospect',
            'normal',
            'default'
        );
    }

    /**
     * Render prospect details meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_prospect_details_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('rankolab_prospect_details', 'rankolab_prospect_details_nonce');
        
        // Get saved meta
        $website_url = get_post_meta($post->ID, '_rankolab_website_url', true);
        $contact_name = get_post_meta($post->ID, '_rankolab_contact_name', true);
        $contact_email = get_post_meta($post->ID, '_rankolab_contact_email', true);
        $contact_phone = get_post_meta($post->ID, '_rankolab_contact_phone', true);
        $target_page = get_post_meta($post->ID, '_rankolab_target_page', true);
        $target_keywords = get_post_meta($post->ID, '_rankolab_target_keywords', true);
        $notes = get_post_meta($post->ID, '_rankolab_notes', true);
        
        ?>
        <div class="rankolab-meta-box">
            <div class="rankolab-meta-box-field">
                <label for="rankolab_website_url">Website URL:</label>
                <input type="url" id="rankolab_website_url" name="rankolab_website_url" value="<?php echo esc_url($website_url); ?>" class="widefat">
            </div>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_contact_name">Contact Name:</label>
                <input type="text" id="rankolab_contact_name" name="rankolab_contact_name" value="<?php echo esc_attr($contact_name); ?>" class="widefat">
            </div>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_contact_email">Contact Email:</label>
                <input type="email" id="rankolab_contact_email" name="rankolab_contact_email" value="<?php echo esc_attr($contact_email); ?>" class="widefat">
            </div>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_contact_phone">Contact Phone:</label>
                <input type="text" id="rankolab_contact_phone" name="rankolab_contact_phone" value="<?php echo esc_attr($contact_phone); ?>" class="widefat">
            </div>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_target_page">Target Page URL:</label>
                <input type="url" id="rankolab_target_page" name="rankolab_target_page" value="<?php echo esc_url($target_page); ?>" class="widefat">
                <p class="description">The page on your website that you want to get a backlink to.</p>
            </div>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_target_keywords">Target Keywords:</label>
                <input type="text" id="rankolab_target_keywords" name="rankolab_target_keywords" value="<?php echo esc_attr($target_keywords); ?>" class="widefat">
                <p class="description">Comma-separated keywords you want to target with this backlink.</p>
            </div>
            
            <div class="rankolab-meta-box-field">
                <label for="rankolab_notes">Notes:</label>
                <textarea id="rankolab_notes" name="rankolab_notes" class="widefat" rows="5"><?php echo esc_textarea($notes); ?></textarea>
            </div>
        </div>
        
        <style>
            .rankolab-meta-box {
                margin-bottom: 15px;
            }
            
            .rankolab-meta-box-field {
                margin-bottom: 15px;
            }
            
            .rankolab-meta-box-field label {
                display: block;
                margin-bottom: 5px;
                font-weight: 600;
            }
        </style>
        <?php
    }

    /**
     * Render prospect metrics meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_prospect_metrics_meta_box($post) {
        // Get saved meta
        $domain_authority = get_post_meta($post->ID, '_rankolab_domain_authority', true);
        $page_authority = get_post_meta($post->ID, '_rankolab_page_authority', true);
        $backlinks = get_post_meta($post->ID, '_rankolab_backlinks', true);
        $organic_traffic = get_post_meta($post->ID, '_rankolab_organic_traffic', true);
        $spam_score = get_post_meta($post->ID, '_rankolab_spam_score', true);
        $last_updated = get_post_meta($post->ID, '_rankolab_metrics_updated', true);
        
        ?>
        <div class="rankolab-metrics-box">
            <div class="rankolab-metric">
                <span class="rankolab-metric-label">Domain Authority:</span>
                <span class="rankolab-metric-value"><?php echo esc_html($domain_authority ? $domain_authority : 'N/A'); ?></span>
            </div>
            
            <div class="rankolab-metric">
                <span class="rankolab-metric-label">Page Authority:</span>
                <span class="rankolab-metric-value"><?php echo esc_html($page_authority ? $page_authority : 'N/A'); ?></span>
            </div>
            
            <div class="rankolab-metric">
                <span class="rankolab-metric-label">Backlinks:</span>
                <span class="rankolab-metric-value"><?php echo esc_html($backlinks ? number_format($backlinks) : 'N/A'); ?></span>
            </div>
            
            <div class="rankolab-metric">
                <span class="rankolab-metric-label">Organic Traffic:</span>
                <span class="rankolab-metric-value"><?php echo esc_html($organic_traffic ? number_format($organic_traffic) : 'N/A'); ?></span>
            </div>
            
            <div class="rankolab-metric">
                <span class="rankolab-metric-label">Spam Score:</span>
                <span class="rankolab-metric-value"><?php echo esc_html($spam_score !== '' ? $spam_score . '%' : 'N/A'); ?></span>
            </div>
            
            <?php if ($last_updated) : ?>
                <div class="rankolab-metrics-updated">
                    Last updated: <?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_updated))); ?>
                </div>
            <?php endif; ?>
            
            <div class="rankolab-metrics-actions">
                <button type="button" id="rankolab_update_metrics" class="button">Update Metrics</button>
                <span class="spinner" style="float: none; margin-top: 0;"></span>
            </div>
        </div>
        
        <script>
            jQuery(document).ready(function($) {
                $('#rankolab_update_metrics').on('click', function() {
                    // Show spinner
                    $(this).prop('disabl
(Content truncated due to size limit. Use line ranges to read in chunks)