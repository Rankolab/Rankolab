<!-- Rankolab Affiliate Management Module Template -->
<div class="rankolab-affiliate-management-module" id="rankolab-affiliate-management">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Affiliate Management</h2>
            <p>Manage your affiliate program, track commissions, and grow your affiliate network.</p>
        </div>
    </div>
    
    <!-- Dashboard Overview -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Affiliate Dashboard</h3>
            <div class="rankolab-card-actions">
                <div class="rankolab-form-group rankolab-mb-0">
                    <select id="rankolab-affiliate-timeframe" class="rankolab-form-control rankolab-form-control-sm">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                        <option value="365">Last Year</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-affiliate-metrics">
                <div class="rankolab-affiliate-metric">
                    <div class="rankolab-affiliate-metric-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="rankolab-affiliate-metric-value"><?php echo esc_html($total_affiliates); ?></div>
                    <div class="rankolab-affiliate-metric-label">Total Affiliates</div>
                    <div class="rankolab-affiliate-metric-change <?php echo $affiliates_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $affiliates_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($affiliates_change)); ?>%
                    </div>
                </div>
                <div class="rankolab-affiliate-metric">
                    <div class="rankolab-affiliate-metric-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="rankolab-affiliate-metric-value"><?php echo esc_html($total_referrals); ?></div>
                    <div class="rankolab-affiliate-metric-label">Total Referrals</div>
                    <div class="rankolab-affiliate-metric-change <?php echo $referrals_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $referrals_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($referrals_change)); ?>%
                    </div>
                </div>
                <div class="rankolab-affiliate-metric">
                    <div class="rankolab-affiliate-metric-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="rankolab-affiliate-metric-value"><?php echo esc_html($total_commissions); ?></div>
                    <div class="rankolab-affiliate-metric-label">Total Commissions</div>
                    <div class="rankolab-affiliate-metric-change <?php echo $commissions_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $commissions_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($commissions_change)); ?>%
                    </div>
                </div>
                <div class="rankolab-affiliate-metric">
                    <div class="rankolab-affiliate-metric-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="rankolab-affiliate-metric-value"><?php echo esc_html($conversion_rate); ?>%</div>
                    <div class="rankolab-affiliate-metric-label">Conversion Rate</div>
                    <div class="rankolab-affiliate-metric-change <?php echo $conversion_change >= 0 ? 'positive' : 'negative'; ?>">
                        <i class="fas <?php echo $conversion_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($conversion_change)); ?>%
                    </div>
                </div>
            </div>
            
            <div class="rankolab-chart-container">
                <canvas id="rankolab-affiliate-performance-chart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Affiliate Management Tabs -->
    <div class="rankolab-tabs" data-tab-group="affiliate-management">
        <div class="rankolab-tab-link active" data-tab-target="affiliates">Affiliates</div>
        <div class="rankolab-tab-link" data-tab-target="commissions">Commissions</div>
        <div class="rankolab-tab-link" data-tab-target="payouts">Payouts</div>
        <div class="rankolab-tab-link" data-tab-target="settings">Settings</div>
    </div>
    
    <!-- Affiliates Tab -->
    <div class="rankolab-tab-content active" data-tab-group="affiliate-management" data-tab-id="affiliates">
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Manage Affiliates</h3>
                <div class="rankolab-card-actions">
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-add-affiliate">
                        <i class="fas fa-plus"></i> Add Affiliate
                    </button>
                </div>
            </div>
            <div class="rankolab-card-body">
                <div class="rankolab-filters">
                    <div class="rankolab-row">
                        <div class="rankolab-col rankolab-col-4">
                            <div class="rankolab-form-group">
                                <input type="text" id="rankolab-affiliate-search" class="rankolab-form-control" placeholder="Search affiliates...">
                            </div>
                        </div>
                        <div class="rankolab-col rankolab-col-3">
                            <div class="rankolab-form-group">
                                <select id="rankolab-affiliate-status-filter" class="rankolab-form-control">
                                    <option value="">All Statuses</option>
                                    <option value="active">Active</option>
                                    <option value="pending">Pending</option>
                                    <option value="suspended">Suspended</option>
                                </select>
                            </div>
                        </div>
                        <div class="rankolab-col rankolab-col-3">
                            <div class="rankolab-form-group">
                                <select id="rankolab-affiliate-sort" class="rankolab-form-control">
                                    <option value="name">Sort by Name</option>
                                    <option value="date">Sort by Date</option>
                                    <option value="earnings">Sort by Earnings</option>
                                    <option value="referrals">Sort by Referrals</option>
                                </select>
                            </div>
                        </div>
                        <div class="rankolab-col rankolab-col-2">
                            <button id="rankolab-reset-filters" class="rankolab-btn rankolab-btn-outline-secondary rankolab-btn-block">
                                Reset
                            </button>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($affiliates)): ?>
                    <div class="rankolab-table-responsive">
                        <table class="rankolab-table rankolab-table-hover">
                            <thead>
                                <tr>
                                    <th>Affiliate</th>
                                    <th>Status</th>
                                    <th>Referrals</th>
                                    <th>Earnings</th>
                                    <th>Conversion Rate</th>
                                    <th>Joined</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($affiliates as $affiliate): ?>
                                    <tr>
                                        <td>
                                            <div class="rankolab-affiliate-info">
                                                <div class="rankolab-affiliate-avatar">
                                                    <?php echo get_avatar($affiliate['email'], 40); ?>
                                                </div>
                                                <div class="rankolab-affiliate-details">
                                                    <div class="rankolab-affiliate-name"><?php echo esc_html($affiliate['name']); ?></div>
                                                    <div class="rankolab-affiliate-email"><?php echo esc_html($affiliate['email']); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="rankolab-status-badge rankolab-status-<?php echo esc_attr($affiliate['status']); ?>">
                                                <?php echo ucfirst(esc_html($affiliate['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html($affiliate['referrals']); ?></td>
                                        <td><?php echo esc_html($affiliate['earnings']); ?></td>
                                        <td><?php echo esc_html($affiliate['conversion_rate']); ?>%</td>
                                        <td><?php echo esc_html($affiliate['joined_date']); ?></td>
                                        <td>
                                            <div class="rankolab-btn-group">
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-view-affiliate" data-affiliate-id="<?php echo esc_attr($affiliate['id']); ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary rankolab-edit-affiliate" data-affiliate-id="<?php echo esc_attr($affiliate['id']); ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger rankolab-delete-affiliate" data-affiliate-id="<?php echo esc_attr($affiliate['id']); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="rankolab-pagination">
                        <div class="rankolab-pagination-info">
                            Showing <?php echo esc_html($pagination['showing_start']); ?> to <?php echo esc_html($pagination['showing_end']); ?> of <?php echo esc_html($pagination['total']); ?> affiliates
                        </div>
                        <div class="rankolab-pagination-controls">
                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary <?php echo $pagination['current_page'] <= 1 ? 'disabled' : ''; ?>" <?php echo $pagination['current_page'] <= 1 ? 'disabled' : ''; ?> data-page="<?php echo esc_attr($pagination['current_page'] - 1); ?>">
                                <i class="fas fa-chevron-left"></i> Previous
                            </button>
                            <span class="rankolab-pagination-pages">
                                Page <?php echo esc_html($pagination['current_page']); ?> of <?php echo esc_html($pagination['total_pages']); ?>
                            </span>
                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary <?php echo $pagination['current_page'] >= $pagination['total_pages'] ? 'disabled' : ''; ?>" <?php echo $pagination['current_page'] >= $pagination['total_pages'] ? 'disabled' : ''; ?> data-page="<?php echo esc_attr($pagination['current_page'] + 1); ?>">
                                Next <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="rankolab-empty-state">
                        <div class="rankolab-empty-state-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="rankolab-empty-state-text">No affiliates found. Click "Add Affiliate" to get started.</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Top Performing Affiliates -->
        <div class="rankolab-card">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Top Performing Affiliates</h3>
            </div>
            <div class="rankolab-card-body">
                <?php if (!empty($top_affiliates)): ?>
                    <div class="rankolab-top-affiliates">
                        <?php foreach ($top_affiliates as $index => $affiliate): ?>
                            <div class="rankolab-top-affiliate">
                                <div class="rankolab-top-affiliate-rank"><?php echo esc_html($index + 1); ?></div>
                                <div class="rankolab-top-affiliate-info">
                                    <div class="rankolab-top-affiliate-avatar">
                                        <?php echo get_avatar($affiliate['email'], 50); ?>
                                    </div>
                                    <div class="rankolab-top-affiliate-details">
                                        <div class="rankolab-top-affiliate-name"><?php echo esc_html($affiliate['name']); ?></div>
                                        <div class="rankolab-top-affiliate-stats">
                                            <span><i class="fas fa-shopping-cart"></i> <?php echo esc_html($affiliate['referrals']); ?> referrals</span>
                                            <span><i class="fas fa-dollar-sign"></i> <?php echo esc_html($affiliate['earnings']); ?> earned</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="rankolab-top-affiliate-performance">
                                    <div class="rankolab-progress">
                                        <div class="rankolab-progress-bar rankolab-bg-success" style="width: <?php echo esc_attr($affiliate['performance_percentage']); ?>%"></div>
                                    </div>
                                </div>
                            </div>
(Content truncated due to size limit. Use line ranges to read in chunks)