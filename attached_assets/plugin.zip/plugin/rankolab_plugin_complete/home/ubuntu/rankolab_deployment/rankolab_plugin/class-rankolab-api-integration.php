<?php
/**
 * API Integration Class for Rankolab
 *
 * This class handles all API connections between the WordPress plugin and the Rankolab backend website.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

class Rankolab_API_Integration {

    /**
     * The API endpoint URL.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $api_url    The URL of the API endpoint.
     */
    private $api_url;

    /**
     * The API key for authentication.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $api_key    The API key for authentication.
     */
    private $api_key;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->api_url = 'https://rankolab.com/api/v1';
        $this->api_key = get_option('rankolab_api_key', '');
        
        // If API key is not set, try to generate one
        if (empty($this->api_key)) {
            $this->generate_api_key();
        }
    }

    /**
     * Generate an API key by authenticating with the backend.
     *
     * @since    1.0.0
     * @return   boolean    Whether the API key was successfully generated.
     */
    public function generate_api_key() {
        $license_key = get_option('rankolab_license_key', '');
        
        if (empty($license_key)) {
            return false;
        }
        
        $response = wp_remote_post($this->api_url . '/auth/generate-api-key', array(
            'method' => 'POST',
            'timeout' => 45,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'license_key' => $license_key,
                'domain' => get_site_url(),
                'email' => get_option('admin_email'),
            )),
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['success']) && $body['success'] && isset($body['api_key'])) {
            $this->api_key = $body['api_key'];
            update_option('rankolab_api_key', $this->api_key);
            return true;
        }
        
        return false;
    }

    /**
     * Make an API request to the backend.
     *
     * @since    1.0.0
     * @param    string    $endpoint    The API endpoint.
     * @param    array     $data        The data to send with the request.
     * @param    string    $method      The HTTP method to use.
     * @return   array|WP_Error         The API response or WP_Error on failure.
     */
    public function request($endpoint, $data = array(), $method = 'GET') {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('No API key available. Please verify your license.', 'rankolab'));
        }
        
        $url = $this->api_url . '/' . ltrim($endpoint, '/');
        $args = array(
            'method' => $method,
            'timeout' => 45,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
            ),
        );
        
        if ($method === 'GET') {
            $url = add_query_arg($data, $url);
        } else {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('api_error', $body['error']);
        }
        
        return $body;
    }

    /**
     * Verify the license with the backend.
     *
     * @since    1.0.0
     * @param    string    $license_key    The license key to verify.
     * @return   array|WP_Error            The verification result or WP_Error on failure.
     */
    public function verify_license($license_key) {
        return $this->request('license/verify', array(
            'license_key' => $license_key,
            'domain' => get_site_url(),
            'product' => 'rankolab',
        ), 'POST');
    }

    /**
     * Sync user data with the backend.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID to sync.
     * @return   array|WP_Error        The sync result or WP_Error on failure.
     */
    public function sync_user($user_id) {
        $user = get_userdata($user_id);
        
        if (!$user) {
            return new WP_Error('invalid_user', __('Invalid user ID.', 'rankolab'));
        }
        
        return $this->request('users/sync', array(
            'user_id' => $user_id,
            'email' => $user->user_email,
            'username' => $user->user_login,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'role' => implode(',', $user->roles),
        ), 'POST');
    }

    /**
     * Get content generation templates from the backend.
     *
     * @since    1.0.0
     * @return   array|WP_Error    The templates or WP_Error on failure.
     */
    public function get_content_templates() {
        return $this->request('content/templates');
    }

    /**
     * Generate content using the backend API.
     *
     * @since    1.0.0
     * @param    array     $params    The content generation parameters.
     * @return   array|WP_Error       The generated content or WP_Error on failure.
     */
    public function generate_content($params) {
        return $this->request('content/generate', $params, 'POST');
    }

    /**
     * Analyze a domain using the backend API.
     *
     * @since    1.0.0
     * @param    string    $domain    The domain to analyze.
     * @return   array|WP_Error       The domain analysis or WP_Error on failure.
     */
    public function analyze_domain($domain) {
        return $this->request('domain/analyze', array('domain' => $domain), 'POST');
    }

    /**
     * Get SEO recommendations for a post.
     *
     * @since    1.0.0
     * @param    int       $post_id    The post ID.
     * @param    string    $keyword    The target keyword.
     * @return   array|WP_Error        The SEO recommendations or WP_Error on failure.
     */
    public function get_seo_recommendations($post_id, $keyword) {
        $post = get_post($post_id);
        
        if (!$post) {
            return new WP_Error('invalid_post', __('Invalid post ID.', 'rankolab'));
        }
        
        return $this->request('seo/recommendations', array(
            'content' => $post->post_content,
            'title' => $post->post_title,
            'excerpt' => $post->post_excerpt,
            'keyword' => $keyword,
        ), 'POST');
    }

    /**
     * Get website design templates from the backend.
     *
     * @since    1.0.0
     * @param    string    $industry    The industry category.
     * @return   array|WP_Error         The design templates or WP_Error on failure.
     */
    public function get_design_templates($industry = '') {
        $params = array();
        
        if (!empty($industry)) {
            $params['industry'] = $industry;
        }
        
        return $this->request('design/templates', $params);
    }

    /**
     * Generate a website design using the backend API.
     *
     * @since    1.0.0
     * @param    array     $params    The design generation parameters.
     * @return   array|WP_Error       The generated design or WP_Error on failure.
     */
    public function generate_design($params) {
        return $this->request('design/generate', $params, 'POST');
    }

    /**
     * Get social media post suggestions from the backend.
     *
     * @since    1.0.0
     * @param    int       $post_id    The post ID to generate suggestions for.
     * @return   array|WP_Error        The post suggestions or WP_Error on failure.
     */
    public function get_social_post_suggestions($post_id) {
        $post = get_post($post_id);
        
        if (!$post) {
            return new WP_Error('invalid_post', __('Invalid post ID.', 'rankolab'));
        }
        
        return $this->request('social/suggestions', array(
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'url' => get_permalink($post_id),
        ), 'POST');
    }

    /**
     * Find link building opportunities using the backend API.
     *
     * @since    1.0.0
     * @param    string    $keyword    The keyword to find opportunities for.
     * @return   array|WP_Error        The link opportunities or WP_Error on failure.
     */
    public function find_link_opportunities($keyword) {
        return $this->request('links/opportunities', array('keyword' => $keyword), 'POST');
    }

    /**
     * Get website monitoring results from the backend.
     *
     * @since    1.0.0
     * @return   array|WP_Error    The monitoring results or WP_Error on failure.
     */
    public function get_monitoring_results() {
        return $this->request('monitoring/results', array('domain' => get_site_url()));
    }

    /**
     * Get AdSense optimization suggestions from the backend.
     *
     * @since    1.0.0
     * @return   array|WP_Error    The AdSense suggestions or WP_Error on failure.
     */
    public function get_adsense_suggestions() {
        return $this->request('adsense/suggestions', array('domain' => get_site_url()));
    }

    /**
     * Get a response from the AI Charlotte Assistant.
     *
     * @since    1.0.0
     * @param    string    $query    The user query.
     * @return   array|WP_Error      The assistant response or WP_Error on failure.
     */
    public function get_assistant_response($query) {
        return $this->request('assistant/query', array('query' => $query), 'POST');
    }

    /**
     * Register an affiliate using the backend API.
     *
     * @since    1.0.0
     * @param    array     $affiliate_data    The affiliate data.
     * @return   array|WP_Error              The registration result or WP_Error on failure.
     */
    public function register_affiliate($affiliate_data) {
        return $this->request('affiliate/register', $affiliate_data, 'POST');
    }

    /**
     * Track an affiliate conversion using the backend API.
     *
     * @since    1.0.0
     * @param    string    $referral_code    The referral code.
     * @param    float     $amount           The conversion amount.
     * @return   array|WP_Error              The tracking result or WP_Error on failure.
     */
    public function track_affiliate_conversion($referral_code, $amount) {
        return $this->request('affiliate/conversion', array(
            'referral_code' => $referral_code,
            'amount' => $amount,
            'domain' => get_site_url(),
        ), 'POST');
    }

    /**
     * Check if a link is broken using the backend API.
     *
     * @since    1.0.0
     * @param    string    $url    The URL to check.
     * @return   array|WP_Error    The check result or WP_Error on failure.
     */
    public function check_broken_link($url) {
        return $this->request('links/check', array('url' => $url), 'POST');
    }

    /**
     * Send plugin usage statistics to the backend.
     *
     * @since    1.0.0
     * @param    array     $stats    The usage statistics.
     * @return   array|WP_Error      The result or WP_Error on failure.
     */
    public function send_usage_stats($stats) {
        return $this->request('stats/usage', $stats, 'POST');
    }

    /**
     * Get plugin updates information from the backend.
     *
     * @since    1.0.0
     * @param    string    $current_version    The current plugin version.
     * @return   array|WP_Error                The update information or WP_Error on failure.
     */
    public function get_update_info($current_version) {
        return $this->request('updates/check', array(
            'version' => $current_version,
            'domain' => get_site_url(),
        ));
    }
}
