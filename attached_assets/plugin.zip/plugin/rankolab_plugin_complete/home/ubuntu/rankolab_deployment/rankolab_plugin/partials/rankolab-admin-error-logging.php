<?php
/**
 * Partial template for displaying the Error Logging settings and viewer page.
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin/partials
 * @since      1.1.0
 */

if (!defined(\'WPINC\')) {
    die;
}

// Get available log levels from the class if possible, or redefine here
$log_levels = array(
    \'debug\'   => \'Debug\',
    \'info\'    => \'Info\',
    \'warning\' => \'Warning\',
    \'error\'   => \'Error\',
    \'critical\'=> \'Critical\'
);

?>
<div class="wrap rankolab-admin-page rankolab-logging-page">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <div id="rankolab-log-viewer">
        <h2><?php _e(\'Log Viewer\', \'rankolab\'); ?></h2>
        <div class="log-controls">
            <label for="log-level-filter"><?php _e(\'Filter by Level:\', \'rankolab\'); ?></label>
            <select id="log-level-filter">
                <option value="all"><?php _e(\'All Levels\', \'rankolab\'); ?></option>
                <?php foreach ($log_levels as $value => $label): ?>
                    <option value="<?php echo esc_attr($value); ?>"><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>

            <label for="log-date-filter"><?php _e(\'Filter by Date:\', \'rankolab\'); ?></label>
            <input type="date" id="log-date-filter" />

            <button id="refresh-logs" class="button button-secondary"><?php _e(\'Refresh Logs\', \'rankolab\'); ?></button>
            <span id="log-status" style="margin-left: 10px;"></span>
        </div>
        <pre id="log-content" class="log-box"><?php _e(\'Loading logs...\', \'rankolab\'); ?></pre>
        <div class="log-actions">
            <form method="post" action="<?php echo esc_url(admin_url(\'admin-post.php\')); ?>" style="display: inline-block;">
                <input type="hidden" name="action" value="rankolab_download_logs"> 
                <?php wp_nonce_field(\'rankolab_download_logs_nonce\', \'_wpnonce_download_logs\'); ?>
                <button type="submit" class="button button-primary"><?php _e(\'Download Log File\', \'rankolab\'); ?></button>
            </form>
            <button id="clear-logs" class="button button-danger" style="margin-left: 10px;"><?php _e(\'Clear Log File\', \'rankolab\'); ?></button>
        </div>
    </div>

    <hr style="margin: 20px 0;">

    <div id="rankolab-log-settings">
        <h2><?php _e(\'Logging Settings\', \'rankolab\'); ?></h2>
        <form method="post" action="options.php">
            <?php
            settings_fields(\'rankolab_logging_options\'); // Must match register_setting group
            do_settings_sections(\'rankolab-logging\'); // Must match add_settings_section page slug
            submit_button();
            ?>
        </form>
    </div>

</div>
<style>
    .rankolab-logging-page .log-controls label {
        margin-left: 15px;
        margin-right: 5px;
    }
    .rankolab-logging-page .log-controls label:first-child {
        margin-left: 0;
    }
    .rankolab-logging-page .log-box {
        background-color: #f9f9f9;
        border: 1px solid #ccc;
        padding: 10px;
        height: 400px;
        overflow-y: scroll;
        white-space: pre-wrap;
        word-wrap: break-word;
        margin-top: 10px;
        font-family: monospace;
        font-size: 12px;
    }
    .rankolab-logging-page .log-actions {
        margin-top: 10px;
    }
    .rankolab-logging-page .button-danger {
        background-color: #dc3545;
        border-color: #dc3545;
        color: white;
    }
    .rankolab-logging-page .button-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
        color: white;
    }
</style>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        var logContent = $(\'#log-content\');
        var statusSpan = $(\'#log-status\');

        function fetchLogs() {
            statusSpan.text(\'<?php echo esc_js(__("Loading...\")); ?>\').css(\'color\', \'orange\');
            logContent.text(\'<?php echo esc_js(__("Loading logs...\")); ?>\');

            $.post(ajaxurl, {
                action: \'rankolab_get_logs\',
                _ajax_nonce: \'<?php echo wp_create_nonce("rankolab_get_logs_nonce"); ?>\',
                level: $(\'#log-level-filter\').val(),
                date: $(\'#log-date-filter\').val()
            }, function(response) {
                if (response.success) {
                    logContent.text(response.data.logs || \'<?php echo esc_js(__("Log file is empty or filters matched no entries.\")); ?>\');
                    statusSpan.text(\'<?php echo esc_js(__("Logs loaded.\")); ?>\').css(\'color\', \'green\');
                    // Scroll to bottom
                    logContent.scrollTop(logContent[0].scrollHeight);
                } else {
                    logContent.text(\'<?php echo esc_js(__("Error loading logs: \")); ?>\\' + response.data.message);
                    statusSpan.text(\'<?php echo esc_js(__("Error.\")); ?>\').css(\'color\', \'red\');
                }
                setTimeout(function() { statusSpan.text(\'\'); }, 3000);
            });
        }

        // Initial load
        fetchLogs();

        // Refresh button and filters
        $(\'#refresh-logs, #log-level-filter, #log-date-filter\').on(\'click change\', function(e) {
            // Prevent button click from submitting form if it were inside one
            if (e.type === \'click\') e.preventDefault(); 
            fetchLogs();
        });

        // Clear logs button
        $(\'#clear-logs\').on(\'click\', function() {
            if (!confirm(\'<?php echo esc_js(__("Are you sure you want to permanently clear the log file? This action cannot be undone.\")); ?>\')) {
                return;
            }
            var button = $(this);
            button.prop(\'disabled\', true);
            statusSpan.text(\'<?php echo esc_js(__("Clearing...\")); ?>\').css(\'color\', \'orange\');

            $.post(ajaxurl, {
                action: \'rankolab_clear_logs\',
                _ajax_nonce: \'<?php echo wp_create_nonce("rankolab_clear_logs_nonce"); ?>\'
            }, function(response) {
                button.prop(\'disabled\', false);
                if (response.success) {
                    statusSpan.text(response.data.message).css(\'color\', \'green\');
                    fetchLogs(); // Refresh view to show empty log
                } else {
                    statusSpan.text(response.data.message).css(\'color\', \'red\');
                }
                setTimeout(function() { statusSpan.text(\'\'); }, 3000);
            });
        });
    });
</script>

