<?php
/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Rankolab_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * The license manager instance.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Rankolab_License    $license    The license manager instance.
     */
    protected $license;

    /**
     * Instances of the plugin modules.
     *
     * @since    1.1.0
     * @access   protected
     * @var      array    $modules    Instances of the plugin modules.
     */
    protected $modules = array();

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if (defined('RANKOLAB_VERSION')) {
            $this->version = RANKOLAB_VERSION;
        } else {
            $this->version = '1.1.0'; // Updated version
        }
        $this->plugin_name = 'rankolab';

        $this->load_dependencies();
        $this->instantiate_modules(); // Instantiate modules after loading dependencies
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks(); // Assuming public hooks might be needed later
        $this->init_module_hooks(); // Initialize hooks for all modules
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Rankolab_Loader. Orchestrates the hooks of the plugin.
     * - Rankolab_i18n. Defines internationalization functionality.
     * - Rankolab_Admin. Defines all hooks for the admin area.
     * - Rankolab_Public. Defines all hooks for the public side.
     * - Core module classes.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {

        // Core framework classes (assuming flat structure for now based on analysis)
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-loader.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-i18n.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-admin.php';
        // require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-public.php'; // Assuming a public class might exist or be needed

        // Core feature classes
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-license.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-api-integration.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-data-sync.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-integration-manager.php';
        require_once plugin_dir_path( __FILE__ ) . 'class-rankolab-user-integration.php';

        // Module classes (Existing 17 + New 3)
        $modules_to_load = array(
            'Setup_Wizard', 'Domain_Analysis', 'AI_Website_Design', 
            'Content_Generation', 'SEO_Optimization', 'Social_Media_Integration',
            'Link_Building', 'Website_Monitoring', 'AdSense_Optimization',
            'AI_Charlotte_Assistant', 'Affiliate_Management', 'Link_Management',
            'Dashboard', // Assuming these map to class names
            // Placeholder names for potentially missing classes from the 17 claimed
            'Niche_Suggestion', 'Content_Strategy', 'Content_Planning', 'Module_Testing', 
            // New Modules
            'Cache_Management', 'Newsletter', 'Error_Logging'
        );

        foreach ($modules_to_load as $module_name) {
            $class_file = plugin_dir_path( __FILE__ ) . 'class-rankolab-' . strtolower(str_replace('_', '-', $module_name)) . '.php';
            if (file_exists($class_file)) {
                require_once $class_file;
            } else {
                // Log error if a module file is expected but not found (using new logger if available)
                if (class_exists('Rankolab_Error_Logging')) {
                    Rankolab_Error_Logging::log('Module file not found: ' . $class_file, 'warning', 'Core Loader');
                }
            }
        }

        $this->loader = new Rankolab_Loader();
    }

    /**
     * Instantiate core components and modules.
     *
     * @since    1.1.0
     * @access   private
     */
    private function instantiate_modules() {
        $this->license = new Rankolab_License($this->get_plugin_name(), $this->get_version());

        // Instantiate modules (add all expected modules here)
        $module_classes = array(
            'Rankolab_Setup_Wizard', 'Rankolab_Domain_Analysis', 'Rankolab_AI_Website_Design',
            'Rankolab_Content_Generation', 'Rankolab_SEO_Optimization', 'Rankolab_Social_Media_Integration',
            'Rankolab_Link_Building', 'Rankolab_Website_Monitoring', 'Rankolab_AdSense_Optimization',
            'Rankolab_AI_Charlotte_Assistant', 'Rankolab_Affiliate_Management', 'Rankolab_Link_Management',
            'Rankolab_Dashboard', 
            // Placeholders - replace with actual class names if they exist
            // 'Rankolab_Niche_Suggestion', 'Rankolab_Content_Strategy', 'Rankolab_Content_Planning', 'Rankolab_Module_Testing',
            // New Modules
            'Rankolab_Cache_Management', 'Rankolab_Newsletter', 'Rankolab_Error_Logging'
        );

        foreach ($module_classes as $class_name) {
            if (class_exists($class_name)) {
                $this->modules[$class_name] = new $class_name($this->get_plugin_name(), $this->get_version());
            }
        }
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the Rankolab_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale() {
        $plugin_i18n = new Rankolab_i18n();
        $this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        // Pass license object to admin class if needed for license page
        $plugin_admin = new Rankolab_Admin($this->get_plugin_name(), $this->get_version(), $this->license);

        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
        $this->loader->add_action( 'admin_menu', $plugin_admin, 'add_plugin_admin_menu' );

        // Add hooks related to license management (example)
        $this->loader->add_action( 'admin_init', $this->license, 'register_settings' );
        $this->loader->add_action( 'admin_notices', $this->license, 'display_license_notices' );
        // Add AJAX handlers if the license class has them
        // $this->loader->add_action( 'wp_ajax_rankolab_activate_license', $this->license, 'handle_ajax_activation' );

        // Add hooks for other core features like API integration, Data Sync etc. if they have admin components
        // Example:
        // if (class_exists('Rankolab_API_Integration') && isset($this->modules['Rankolab_API_Integration'])) {
        //     $api_integration = $this->modules['Rankolab_API_Integration'];
        //     $this->loader->add_action('admin_init', $api_integration, 'register_api_settings');
        // }
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        // Example: If there's a public class
        // $plugin_public = new Rankolab_Public( $this->get_plugin_name(), $this->get_version() );
        // $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        // $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
    }

    /**
     * Initialize hooks for all instantiated modules.
     *
     * @since    1.1.0
     * @access   private
     */
    private function init_module_hooks() {
        foreach ($this->modules as $module) {
            if (method_exists($module, 'init_hooks')) {
                // Pass the loader to the module if it needs to add hooks directly
                if (method_exists($module, 'set_loader')) {
                     $module->set_loader($this->loader);
                }
                $module->init_hooks(); // Let each module register its own hooks
            }
        }
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    Rankolab_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }

    /**
     * Get the license manager instance.
     *
     * @since     1.0.0
     * @return    Rankolab_License    The license manager instance.
     */
    public function get_license() {
        return $this->license;
    }
}

