<?php
/**
 * The file that defines the link management module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The link management module class.
 *
 * This class handles link management functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Link_Management {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_get_links', array($this, 'ajax_get_links'));
        add_action('wp_ajax_rankolab_add_link', array($this, 'ajax_add_link'));
        add_action('wp_ajax_rankolab_update_link', array($this, 'ajax_update_link'));
        add_action('wp_ajax_rankolab_delete_link', array($this, 'ajax_delete_link'));
        add_action('wp_ajax_rankolab_check_link_status', array($this, 'ajax_check_link_status'));
        add_action('wp_ajax_rankolab_bulk_check_links', array($this, 'ajax_bulk_check_links'));
        add_action('wp_ajax_rankolab_import_links', array($this, 'ajax_import_links'));
        add_action('wp_ajax_rankolab_export_links', array($this, 'ajax_export_links'));
        add_action('wp_ajax_rankolab_save_link_settings', array($this, 'ajax_save_link_settings'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_link_management_page'), 20);
        
        // Register settings
        add_action('admin_init', array($this, 'register_link_settings'));
        
        // Add shortcodes
        add_shortcode('rankolab_link_display', array($this, 'link_display_shortcode'));
        add_shortcode('rankolab_link_redirect', array($this, 'link_redirect_shortcode'));
        
        // Add frontend hooks
        add_action('init', array($this, 'register_link_endpoints'));
        add_action('template_redirect', array($this, 'handle_link_endpoints'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        
        // Add cron job for link checking
        add_action('rankolab_check_links_cron', array($this, 'check_links_cron_job'));
        
        // Add filter for content links
        add_filter('the_content', array($this, 'process_content_links'));
        
        // Register custom post type for links
        add_action('init', array($this, 'register_link_post_type'));
        
        // Add meta boxes for link post type
        add_action('add_meta_boxes', array($this, 'add_link_meta_boxes'));
        
        // Save link meta data
        add_action('save_post_rankolab_link', array($this, 'save_link_meta'));
        
        // Schedule cron job if not already scheduled
        if (!wp_next_scheduled('rankolab_check_links_cron')) {
            wp_schedule_event(time(), 'daily', 'rankolab_check_links_cron');
        }
    }

    /**
     * Register custom post type for links.
     *
     * @since    1.0.0
     */
    public function register_link_post_type() {
        $labels = array(
            'name'                  => _x('Links', 'Post type general name', 'rankolab'),
            'singular_name'         => _x('Link', 'Post type singular name', 'rankolab'),
            'menu_name'             => _x('Links', 'Admin Menu text', 'rankolab'),
            'name_admin_bar'        => _x('Link', 'Add New on Toolbar', 'rankolab'),
            'add_new'               => __('Add New', 'rankolab'),
            'add_new_item'          => __('Add New Link', 'rankolab'),
            'new_item'              => __('New Link', 'rankolab'),
            'edit_item'             => __('Edit Link', 'rankolab'),
            'view_item'             => __('View Link', 'rankolab'),
            'all_items'             => __('All Links', 'rankolab'),
            'search_items'          => __('Search Links', 'rankolab'),
            'parent_item_colon'     => __('Parent Links:', 'rankolab'),
            'not_found'             => __('No links found.', 'rankolab'),
            'not_found_in_trash'    => __('No links found in Trash.', 'rankolab'),
            'featured_image'        => _x('Link Image', 'Overrides the "Featured Image" phrase', 'rankolab'),
            'set_featured_image'    => _x('Set link image', 'Overrides the "Set featured image" phrase', 'rankolab'),
            'remove_featured_image' => _x('Remove link image', 'Overrides the "Remove featured image" phrase', 'rankolab'),
            'use_featured_image'    => _x('Use as link image', 'Overrides the "Use as featured image" phrase', 'rankolab'),
            'archives'              => _x('Link archives', 'The post type archive label used in nav menus', 'rankolab'),
            'insert_into_item'      => _x('Insert into link', 'Overrides the "Insert into post" phrase', 'rankolab'),
            'uploaded_to_this_item' => _x('Uploaded to this link', 'Overrides the "Uploaded to this post" phrase', 'rankolab'),
            'filter_items_list'     => _x('Filter links list', 'Screen reader text for the filter links heading', 'rankolab'),
            'items_list_navigation' => _x('Links list navigation', 'Screen reader text for the pagination heading', 'rankolab'),
            'items_list'            => _x('Links list', 'Screen reader text for the items list heading', 'rankolab'),
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => 'rankolab',
            'query_var'          => true,
            'rewrite'            => array('slug' => 'rankolab-link'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
            'show_in_rest'       => true,
        );
        
        register_post_type('rankolab_link', $args);
        
        // Register taxonomies for links
        $category_labels = array(
            'name'              => _x('Link Categories', 'taxonomy general name', 'rankolab'),
            'singular_name'     => _x('Link Category', 'taxonomy singular name', 'rankolab'),
            'search_items'      => __('Search Link Categories', 'rankolab'),
            'all_items'         => __('All Link Categories', 'rankolab'),
            'parent_item'       => __('Parent Link Category', 'rankolab'),
            'parent_item_colon' => __('Parent Link Category:', 'rankolab'),
            'edit_item'         => __('Edit Link Category', 'rankolab'),
            'update_item'       => __('Update Link Category', 'rankolab'),
            'add_new_item'      => __('Add New Link Category', 'rankolab'),
            'new_item_name'     => __('New Link Category Name', 'rankolab'),
            'menu_name'         => __('Categories', 'rankolab'),
        );
        
        $category_args = array(
            'hierarchical'      => true,
            'labels'            => $category_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'link-category'),
            'show_in_rest'      => true,
        );
        
        register_taxonomy('rankolab_link_category', array('rankolab_link'), $category_args);
        
        $tag_labels = array(
            'name'              => _x('Link Tags', 'taxonomy general name', 'rankolab'),
            'singular_name'     => _x('Link Tag', 'taxonomy singular name', 'rankolab'),
            'search_items'      => __('Search Link Tags', 'rankolab'),
            'all_items'         => __('All Link Tags', 'rankolab'),
            'parent_item'       => __('Parent Link Tag', 'rankolab'),
            'parent_item_colon' => __('Parent Link Tag:', 'rankolab'),
            'edit_item'         => __('Edit Link Tag', 'rankolab'),
            'update_item'       => __('Update Link Tag', 'rankolab'),
            'add_new_item'      => __('Add New Link Tag', 'rankolab'),
            'new_item_name'     => __('New Link Tag Name', 'rankolab'),
            'menu_name'         => __('Tags', 'rankolab'),
        );
        
        $tag_args = array(
            'hierarchical'      => false,
            'labels'            => $tag_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'link-tag'),
            'show_in_rest'      => true,
        );
        
        register_taxonomy('rankolab_link_tag', array('rankolab_link'), $tag_args);
    }

    /**
     * Add meta boxes for link post type.
     *
     * @since    1.0.0
     */
    public function add_link_meta_boxes() {
        add_meta_box(
            'rankolab_link_details',
            __('Link Details', 'rankolab'),
            array($this, 'render_link_details_meta_box'),
            'rankolab_link',
            'normal',
            'high'
        );
        
        add_meta_box(
            'rankolab_link_status',
            __('Link Status', 'rankolab'),
            array($this, 'render_link_status_meta_box'),
            'rankolab_link',
            'side',
            'default'
        );
        
        add_meta_box(
            'rankolab_link_analytics',
            __('Link Analytics', 'rankolab'),
            array($this, 'render_link_analytics_meta_box'),
            'rankolab_link',
            'normal',
            'default'
        );
    }

    /**
     * Render link details meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_link_details_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('rankolab_link_meta_box', 'rankolab_link_meta_box_nonce');
        
        // Get link details
        $url = get_post_meta($post->ID, '_rankolab_link_url', true);
        $type = get_post_meta($post->ID, '_rankolab_link_type', true);
        $nofollow = get_post_meta($post->ID, '_rankolab_link_nofollow', true);
        $sponsored = get_post_meta($post->ID, '_rankolab_link_sponsored', true);
        $ugc = get_post_meta($post->ID, '_rankolab_link_ugc', true);
        $target = get_post_meta($post->ID, '_rankolab_link_target', true);
        $redirect = get_post_meta($post->ID, '_rankolab_link_redirect', true);
        $short_url = get_post_meta($post->ID, '_rankolab_link_short_url', true);
        
        // Set default values
        if (empty($type)) {
            $type = 'external';
        }
        
        if (empty($target)) {
            $target = '_blank';
        }
        
        // Output fields
        ?>
        <p>
            <label for="rankolab_link_url"><strong><?php _e('URL:', 'rankolab'); ?></strong></label>
            <input type="url" id="rankolab_link_url" name="rankolab_link_url" value="<?php echo esc_url($url); ?>" style="width: 100%;" required />
            <span class="description"><?php _e('Enter the full URL including http:// or https://', 'rankolab'); ?></span>
        </p>
        
        <p>
            <label for="rankolab_link_type"><strong><?php _e('Link Type:', 'rankolab'); ?></strong></label>
            <select id="rankolab_link_type" name="rankolab_link_type">
                <option value="external" <?php selected($type, 'external'); ?>><?php _e('External', 'rankolab'); ?></option>
                <option value="internal" <?php selected($type, 'internal'); ?>><?php _e('Internal', 'rankolab'); ?></option>
                <option value="affiliate" <?php selected($type, 'affiliate'); ?>><?php _e('Affiliate', 'rankolab'); ?></option>
                <option value="resource" <?php selected($type, 'resource'); ?>><?php _e('Resource', 'rankolab'); ?></option>
                <option value="social" <?php selected($type, 'social'); ?>><?php _e('Social Media', 'rankolab'); ?></option>
            </select>
        </p>
        
        <p>
            <label><strong><?php _e('Link Attributes:', 'rankolab'); ?></strong></label><br>
            <label>
                <input type="checkbox" name="rankolab_link_nofollow" value="1" <?php checked($nofollow, '1'); ?> />
                <?php _e('Add nofollow attribute', 'rankolab'); ?>
            </label><br>
            <label>
                <input type="checkbox" name="rankolab_link_sponsored" value="1" <?php checked($sponsored, '1'); ?> />
                <?php _e('Add sponsored attribute', 'rankolab'); ?>
            </label><br>
            <label>
                <input type="checkbox" name="rankolab_link_ugc" value="1" <?php checked($ugc, '1'); ?> />
                <?php _e('Add UGC (User Generated Content) attribute', 'rankolab'); ?>
            </label>
        </p>
        
        <p>
            <label for="rankolab_link_target"><strong><?php _e('Target:', 'rankolab'); ?></strong></label>
            <select id="rankolab_link_target" name="rankolab_link_target">
                <option value="_blank" <?php selected($target, '_blank'); ?>><?php _e('New Window (_blank)', 'rankolab'); ?></option>
                <option value="_self" <?php selected($target, '_self'); ?>><?php _e('Same Window (_self)', 'rankolab'); ?></option>
            </select>
        </p>
        
        <p>
            <label>
                <input type="checkbox" name="rankolab_link_redirect" value="1" <?php checked($redirect, '1'); ?> />
                <?php _e('Use redirect for this link', 'rankolab'); ?>
            </label>
            <span class="description"><?php _e('Redirects through your site for click tracking and masking affiliate links', 'rankolab'); ?></span>
        </p>
        
        <?php if (!empty($short_url)) : ?>
        <p>
            <label><strong><?php _e('Short URL:', 'rankolab'); ?></strong></label>
            <input type="text" value="<?php echo esc_url($short_url); ?>" readonly style="width: 100%;" />
            <button type="button" class="button" onclick="navigator.clipboard.writeText('<?php echo esc_url($short_url); ?>')">
                <?php _e('Copy to Clipboard', 'rankolab'); ?>
            </button>
        </p>
        <?php endif; ?>
        <?php
    }

    /**
     * Render link status meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_link_status_meta_box($post) {
        // Get link status
        $status = get_post_meta($post->ID, '_rankolab_link_status', true);
        $status_code = get_post_meta($post->ID, '_rankolab_link_status_code', true);
        $last_checked = get_post_meta($post->ID, '_rankolab_link_last_checked', true);
        
        // Set default values
        if (empty($status)) {
            $status = 'unknown';
        }
        
        // Output fields
        ?>
        <p>
            <label><strong><?php _e('Status:', 'rankolab'); ?></strong></label>
            <?php
            $status_label = '';
            $status_color = 
(Content truncated due to size limit. Use line ranges to read in chunks)