<!-- Rankolab Domain Analysis Module Template -->
<div class="rankolab-domain-analysis-module" id="rankolab-domain-analysis">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Domain Analysis</h2>
            <p>Analyze your domain's performance, authority, and competitive landscape.</p>
        </div>
    </div>
    
    <!-- Domain Analysis Form -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Analyze Domain</h3>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-form-group">
                <label for="rankolab-domain-url" class="rankolab-form-label">Domain URL</label>
                <div class="rankolab-input-group">
                    <input type="text" id="rankolab-domain-url" class="rankolab-form-control" placeholder="Enter domain URL (e.g., example.com)" value="<?php echo esc_attr($current_domain); ?>">
                    <div class="rankolab-input-group-append">
                        <button id="rankolab-analyze-domain" class="rankolab-btn rankolab-btn-primary">
                            <i class="fas fa-search"></i> Analyze
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="rankolab-form-group">
                <label class="rankolab-form-label">Analysis Options</label>
                <div class="rankolab-row">
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-analyze-authority" class="rankolab-form-check-input" checked>
                            <label for="rankolab-analyze-authority" class="rankolab-form-check-label">Domain Authority</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-analyze-backlinks" class="rankolab-form-check-input" checked>
                            <label for="rankolab-analyze-backlinks" class="rankolab-form-check-label">Backlink Profile</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-analyze-competitors" class="rankolab-form-check-input" checked>
                            <label for="rankolab-analyze-competitors" class="rankolab-form-check-label">Competitor Analysis</label>
                        </div>
                    </div>
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-form-check">
                            <input type="checkbox" id="rankolab-analyze-keywords" class="rankolab-form-check-input" checked>
                            <label for="rankolab-analyze-keywords" class="rankolab-form-check-label">Keyword Rankings</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Domain Analysis Results -->
    <div id="rankolab-domain-analysis-results" style="display: <?php echo $has_analysis ? 'block' : 'none'; ?>;">
        <!-- Domain Overview -->
        <div class="rankolab-card rankolab-card-primary">
            <div class="rankolab-card-header">
                <h3 class="rankolab-card-title">Domain Overview: <span id="rankolab-analyzed-domain"><?php echo esc_html($analyzed_domain); ?></span></h3>
                <div class="rankolab-card-actions">
                    <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-export-domain-analysis">
                        <i class="fas fa-download"></i> Export Report
                    </button>
                </div>
            </div>
            <div class="rankolab-card-body">
                <div class="rankolab-row">
                    <!-- Domain Authority -->
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-domain-metric">
                            <div class="rankolab-domain-metric-title">Domain Authority</div>
                            <div class="rankolab-domain-metric-value">
                                <div class="rankolab-score-circle" style="--score-percentage: <?php echo esc_attr($domain_authority); ?>%;">
                                    <div class="rankolab-score-value"><?php echo esc_html($domain_authority); ?></div>
                                </div>
                            </div>
                            <div class="rankolab-domain-metric-change positive">
                                <i class="fas fa-arrow-up"></i> 3 points in 3 months
                            </div>
                        </div>
                    </div>
                    
                    <!-- Backlinks -->
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-domain-metric">
                            <div class="rankolab-domain-metric-title">Total Backlinks</div>
                            <div class="rankolab-domain-metric-value-large"><?php echo number_format($backlinks_count); ?></div>
                            <div class="rankolab-domain-metric-change positive">
                                <i class="fas fa-arrow-up"></i> 127 new in 30 days
                            </div>
                        </div>
                    </div>
                    
                    <!-- Referring Domains -->
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-domain-metric">
                            <div class="rankolab-domain-metric-title">Referring Domains</div>
                            <div class="rankolab-domain-metric-value-large"><?php echo number_format($referring_domains); ?></div>
                            <div class="rankolab-domain-metric-change positive">
                                <i class="fas fa-arrow-up"></i> 18 new in 30 days
                            </div>
                        </div>
                    </div>
                    
                    <!-- Organic Keywords -->
                    <div class="rankolab-col rankolab-col-3">
                        <div class="rankolab-domain-metric">
                            <div class="rankolab-domain-metric-title">Organic Keywords</div>
                            <div class="rankolab-domain-metric-value-large"><?php echo number_format($organic_keywords); ?></div>
                            <div class="rankolab-domain-metric-change positive">
                                <i class="fas fa-arrow-up"></i> 42 new in 30 days
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="rankolab-row rankolab-mt-3">
                    <!-- Domain Age -->
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-domain-info-item">
                            <div class="rankolab-domain-info-icon">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div class="rankolab-domain-info-content">
                                <div class="rankolab-domain-info-label">Domain Age</div>
                                <div class="rankolab-domain-info-value"><?php echo esc_html($domain_age); ?> years</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- IP Location -->
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-domain-info-item">
                            <div class="rankolab-domain-info-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="rankolab-domain-info-content">
                                <div class="rankolab-domain-info-label">IP Location</div>
                                <div class="rankolab-domain-info-value"><?php echo esc_html($ip_location); ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Indexed Pages -->
                    <div class="rankolab-col rankolab-col-4">
                        <div class="rankolab-domain-info-item">
                            <div class="rankolab-domain-info-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <div class="rankolab-domain-info-content">
                                <div class="rankolab-domain-info-label">Indexed Pages</div>
                                <div class="rankolab-domain-info-value"><?php echo number_format($indexed_pages); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Detailed Analysis Tabs -->
        <div class="rankolab-tabs" data-tab-group="domain-analysis">
            <div class="rankolab-tab-link active" data-tab-target="backlinks">Backlink Analysis</div>
            <div class="rankolab-tab-link" data-tab-target="competitors">Competitor Analysis</div>
            <div class="rankolab-tab-link" data-tab-target="keywords">Keyword Rankings</div>
            <div class="rankolab-tab-link" data-tab-target="issues">Technical Issues</div>
        </div>
        
        <!-- Backlink Analysis Tab -->
        <div class="rankolab-tab-content active" data-tab-group="domain-analysis" data-tab-id="backlinks">
            <div class="rankolab-row">
                <!-- Backlink Metrics -->
                <div class="rankolab-col rankolab-col-4">
                    <div class="rankolab-card">
                        <div class="rankolab-card-header">
                            <h3 class="rankolab-card-title">Backlink Metrics</h3>
                        </div>
                        <div class="rankolab-card-body">
                            <div class="rankolab-backlink-metrics">
                                <div class="rankolab-backlink-metric-item">
                                    <div class="rankolab-backlink-metric-label">Total Backlinks</div>
                                    <div class="rankolab-backlink-metric-value"><?php echo number_format($backlinks_count); ?></div>
                                </div>
                                <div class="rankolab-backlink-metric-item">
                                    <div class="rankolab-backlink-metric-label">Referring Domains</div>
                                    <div class="rankolab-backlink-metric-value"><?php echo number_format($referring_domains); ?></div>
                                </div>
                                <div class="rankolab-backlink-metric-item">
                                    <div class="rankolab-backlink-metric-label">Referring IPs</div>
                                    <div class="rankolab-backlink-metric-value"><?php echo number_format($referring_ips); ?></div>
                                </div>
                                <div class="rankolab-backlink-metric-item">
                                    <div class="rankolab-backlink-metric-label">Follow vs Nofollow</div>
                                    <div class="rankolab-backlink-metric-value"><?php echo esc_html($follow_ratio); ?></div>
                                </div>
                                <div class="rankolab-backlink-metric-item">
                                    <div class="rankolab-backlink-metric-label">Text vs Image Links</div>
                                    <div class="rankolab-backlink-metric-value"><?php echo esc_html($text_image_ratio); ?></div>
                                </div>
                                <div class="rankolab-backlink-metric-item">
                                    <div class="rankolab-backlink-metric-label">Average Domain Authority</div>
                                    <div class="rankolab-backlink-metric-value"><?php echo esc_html($avg_domain_authority); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Backlink Distribution -->
                <div class="rankolab-col rankolab-col-8">
                    <div class="rankolab-card">
                        <div class="rankolab-card-header">
                            <h3 class="rankolab-card-title">Backlink Distribution</h3>
                        </div>
                        <div class="rankolab-card-body">
                            <div class="rankolab-row">
                                <div class="rankolab-col rankolab-col-6">
                                    <div class="rankolab-chart-container">
                                        <canvas id="rankolab-backlink-types-chart"></canvas>
                                    </div>
                                    <div class="rankolab-chart-title">Backlink Types</div>
                                </div>
                                <div class="rankolab-col rankolab-col-6">
                                    <div class="rankolab-chart-container">
                                        <canvas id="rankolab-backlink-authority-chart"></canvas>
                                    </div>
                                    <div class="rankolab-chart-title">Referring Domain Authority</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Top Backlinks -->
            <div class="rankolab-card">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">Top Backlinks</h3>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-table-responsive">
                        <table class="rankolab-table rankolab-table-hover">
                            <thead>
                                <tr>
                                    <th>Source URL</th>
                                    <th>Domain Authority</th>
                                    <th>Link Type</th>
                                    <th>Anchor Text</th>
                                    <th>First Seen</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($top_backlinks)): ?>
                                    <?php foreach ($top_backlinks as $backlink): ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo esc_url($backlink['source_url']); ?>" target="_blank" rel="noopener noreferrer">
                                                    <?php echo esc_html($backlink['source_domain']); ?>
                                                </a>
                                            </td>
                                            <td><?php echo esc_html($backlink['domain_authority']); ?></td>
                                            <td><?php echo esc_ht
(Content truncated due to size limit. Use line ranges to read in chunks)