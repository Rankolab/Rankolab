<?php
/**
 * The file that defines the SEO optimization module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The SEO optimization module class.
 *
 * This class handles SEO optimization functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_SEO_Optimization {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_optimize_seo', array($this, 'ajax_optimize_seo'));
        add_action('wp_ajax_rankolab_analyze_post_seo', array($this, 'ajax_analyze_post_seo'));
        add_action('wp_ajax_rankolab_get_seo_recommendations', array($this, 'ajax_get_seo_recommendations'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_seo_optimization_page'), 20);
        
        // Add meta box for post editor
        add_action('add_meta_boxes', array($this, 'add_seo_optimization_meta_box'));
        
        // Save post meta
        add_action('save_post', array($this, 'save_seo_meta'), 10, 2);
        
        // Add SEO columns to post list
        add_filter('manage_posts_columns', array($this, 'add_seo_columns'));
        add_action('manage_posts_custom_column', array($this, 'display_seo_column_content'), 10, 2);
    }

    /**
     * Add SEO optimization admin page.
     *
     * @since    1.0.0
     */
    public function add_seo_optimization_page() {
        add_submenu_page(
            'rankolab',
            'SEO Optimization',
            'SEO Optimization',
            'manage_options',
            'rankolab-seo-optimization',
            array($this, 'display_seo_optimization_page')
        );
    }

    /**
     * Display SEO optimization admin page.
     *
     * @since    1.0.0
     */
    public function display_seo_optimization_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-seo-optimization.php';
    }

    /**
     * Add SEO optimization meta box to post editor.
     *
     * @since    1.0.0
     */
    public function add_seo_optimization_meta_box() {
        add_meta_box(
            'rankolab_seo_optimization',
            'Rankolab SEO Optimization',
            array($this, 'render_seo_optimization_meta_box'),
            'post',
            'normal',
            'high'
        );
    }

    /**
     * Render SEO optimization meta box.
     *
     * @since    1.0.0
     * @param    WP_Post    $post    The post object.
     */
    public function render_seo_optimization_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('rankolab_seo_optimization_meta_box', 'rankolab_seo_optimization_nonce');
        
        // Get saved meta
        $focus_keyword = get_post_meta($post->ID, '_rankolab_focus_keyword', true);
        $meta_description = get_post_meta($post->ID, '_rankolab_meta_description', true);
        $seo_score = get_post_meta($post->ID, '_rankolab_seo_score', true);
        $readability_score = get_post_meta($post->ID, '_rankolab_readability_score', true);
        
        ?>
        <div class="rankolab-seo-meta-box">
            <div class="rankolab-seo-meta-box-scores">
                <div class="rankolab-seo-score <?php echo $this->get_score_class($seo_score); ?>">
                    <div class="rankolab-score-circle">
                        <span class="rankolab-score-value"><?php echo intval($seo_score); ?></span>
                    </div>
                    <div class="rankolab-score-label">SEO Score</div>
                </div>
                
                <div class="rankolab-readability-score <?php echo $this->get_score_class($readability_score); ?>">
                    <div class="rankolab-score-circle">
                        <span class="rankolab-score-value"><?php echo intval($readability_score); ?></span>
                    </div>
                    <div class="rankolab-score-label">Readability</div>
                </div>
            </div>
            
            <div class="rankolab-seo-meta-box-fields">
                <div class="rankolab-meta-box-field">
                    <label for="rankolab_focus_keyword">Focus Keyword:</label>
                    <input type="text" id="rankolab_focus_keyword" name="rankolab_focus_keyword" value="<?php echo esc_attr($focus_keyword); ?>" class="widefat">
                    <p class="description">Enter the main keyword or phrase for this content.</p>
                </div>
                
                <div class="rankolab-meta-box-field">
                    <label for="rankolab_meta_description">Meta Description:</label>
                    <textarea id="rankolab_meta_description" name="rankolab_meta_description" class="widefat" rows="3"><?php echo esc_textarea($meta_description); ?></textarea>
                    <div class="rankolab-meta-description-counter <?php echo (strlen($meta_description) > 160) ? 'too-long' : ''; ?>">
                        <span class="rankolab-character-count"><?php echo strlen($meta_description); ?></span>/160
                    </div>
                    <p class="description">Write a compelling meta description to improve click-through rates from search results.</p>
                </div>
            </div>
            
            <div class="rankolab-seo-analysis">
                <h3>SEO Analysis</h3>
                <div id="rankolab_seo_analysis_results">
                    <p class="rankolab-loading-message">Click "Analyze Content" to get SEO recommendations.</p>
                </div>
                
                <div class="rankolab-meta-box-actions">
                    <button type="button" id="rankolab_analyze_seo_btn" class="button button-primary">Analyze Content</button>
                    <button type="button" id="rankolab_optimize_seo_btn" class="button">Auto-Optimize</button>
                    <span class="spinner" style="float: none; margin-top: 0;"></span>
                </div>
            </div>
        </div>
        
        <script>
            jQuery(document).ready(function($) {
                // Character counter for meta description
                $('#rankolab_meta_description').on('input', function() {
                    var count = $(this).val().length;
                    $('.rankolab-character-count').text(count);
                    
                    if (count > 160) {
                        $('.rankolab-meta-description-counter').addClass('too-long');
                    } else {
                        $('.rankolab-meta-description-counter').removeClass('too-long');
                    }
                });
                
                // Analyze SEO
                $('#rankolab_analyze_seo_btn').on('click', function() {
                    var focusKeyword = $('#rankolab_focus_keyword').val();
                    
                    if (!focusKeyword) {
                        alert('Please enter a focus keyword.');
                        return;
                    }
                    
                    // Show spinner
                    $(this).prop('disabled', true);
                    $(this).next().prop('disabled', true);
                    $('.spinner').css('visibility', 'visible');
                    
                    // Get content from editor
                    var content = '';
                    
                    if (wp.data && wp.data.select('core/editor')) {
                        // Gutenberg editor
                        content = wp.data.select('core/editor').getEditedPostContent();
                    } else {
                        // Classic editor
                        if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
                            content = tinyMCE.activeEditor.getContent();
                        } else {
                            content = $('#content').val();
                        }
                    }
                    
                    // Analyze SEO
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'rankolab_analyze_post_seo',
                            nonce: '<?php echo wp_create_nonce('rankolab_seo_optimization_nonce'); ?>',
                            post_id: <?php echo $post->ID; ?>,
                            focus_keyword: focusKeyword,
                            meta_description: $('#rankolab_meta_description').val(),
                            content: content,
                            title: $('#title').val() || wp.data.select('core/editor').getEditedPostAttribute('title')
                        },
                        success: function(response) {
                            // Hide spinner
                            $('#rankolab_analyze_seo_btn').prop('disabled', false);
                            $('#rankolab_optimize_seo_btn').prop('disabled', false);
                            $('.spinner').css('visibility', 'hidden');
                            
                            if (response.success) {
                                // Update analysis results
                                $('#rankolab_seo_analysis_results').html(response.data.analysis_html);
                                
                                // Update scores
                                $('.rankolab-seo-score .rankolab-score-value').text(response.data.seo_score);
                                $('.rankolab-seo-score').removeClass('poor fair good excellent').addClass(getScoreClass(response.data.seo_score));
                                
                                $('.rankolab-readability-score .rankolab-score-value').text(response.data.readability_score);
                                $('.rankolab-readability-score').removeClass('poor fair good excellent').addClass(getScoreClass(response.data.readability_score));
                            } else {
                                alert(response.data);
                            }
                        },
                        error: function() {
                            // Hide spinner
                            $('#rankolab_analyze_seo_btn').prop('disabled', false);
                            $('#rankolab_optimize_seo_btn').prop('disabled', false);
                            $('.spinner').css('visibility', 'hidden');
                            
                            alert('An error occurred. Please try again.');
                        }
                    });
                });
                
                // Auto-optimize SEO
                $('#rankolab_optimize_seo_btn').on('click', function() {
                    var focusKeyword = $('#rankolab_focus_keyword').val();
                    
                    if (!focusKeyword) {
                        alert('Please enter a focus keyword.');
                        return;
                    }
                    
                    if (confirm('Auto-optimization will modify your content to improve SEO. Continue?')) {
                        // Show spinner
                        $(this).prop('disabled', true);
                        $(this).prev().prop('disabled', true);
                        $('.spinner').css('visibility', 'visible');
                        
                        // Get content from editor
                        var content = '';
                        
                        if (wp.data && wp.data.select('core/editor')) {
                            // Gutenberg editor
                            content = wp.data.select('core/editor').getEditedPostContent();
                        } else {
                            // Classic editor
                            if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
                                content = tinyMCE.activeEditor.getContent();
                            } else {
                                content = $('#content').val();
                            }
                        }
                        
                        // Optimize SEO
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'rankolab_optimize_seo',
                                nonce: '<?php echo wp_create_nonce('rankolab_seo_optimization_nonce'); ?>',
                                post_id: <?php echo $post->ID; ?>,
                                focus_keyword: focusKeyword,
                                meta_description: $('#rankolab_meta_description').val(),
                                content: content,
                                title: $('#title').val() || wp.data.select('core/editor').getEditedPostAttribute('title')
                            },
                            success: function(response) {
                                // Hide spinner
                                $('#rankolab_analyze_seo_btn').prop('disabled', false);
                                $('#rankolab_optimize_seo_btn').prop('disabled', false);
                                $('.spinner').css('visibility', 'hidden');
                                
                                if (response.success) {
                                    // Update content in editor
                                    if (wp.data && wp.data.select('core/editor')) {
                                        // Gutenberg editor
                                        wp.data.dispatch('core/editor').editPost({
                                            content: response.data.optimized_content
                                        });
                                        
                                        if (response.data.optimized_title) {
                                            wp.data.dispatch('core/editor').editPost({
                                                title: response.data.optimized_title
                                            });
                                        }
                                    } else {
                                        // Classic editor
                                        if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
                                            tinyMCE.activeEditor.setContent(response.data.optimized_content);
                                        } else {
                                            $('#content').val(response.data.optimized_content);
                                        }
                                        
                                        if (response.data.optimized_title) {
                                            $('#title').val(response.data.optimized_title);
                                        }
                                    }
                                    
                   
(Content truncated due to size limit. Use line ranges to read in chunks)