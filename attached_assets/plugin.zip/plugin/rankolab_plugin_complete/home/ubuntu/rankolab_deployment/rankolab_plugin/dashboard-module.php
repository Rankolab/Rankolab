<!-- Rankolab Dashboard Module Template -->
<div class="rankolab-dashboard-module" id="rankolab-dashboard">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Rankolab Dashboard</h2>
            <p>Your complete SEO and content optimization command center.</p>
        </div>
        <div class="rankolab-module-actions">
            <button class="rankolab-btn rankolab-btn-primary" id="rankolab-refresh-dashboard">
                <i class="fas fa-sync-alt"></i> Refresh Data
            </button>
            <div class="rankolab-dropdown">
                <button class="rankolab-btn rankolab-btn-outline-primary rankolab-dropdown-toggle">
                    <i class="fas fa-calendar-alt"></i> Time Period <i class="fas fa-chevron-down"></i>
                </button>
                <div class="rankolab-dropdown-menu">
                    <a href="#" class="rankolab-dropdown-item" data-period="7">Last 7 Days</a>
                    <a href="#" class="rankolab-dropdown-item active" data-period="30">Last 30 Days</a>
                    <a href="#" class="rankolab-dropdown-item" data-period="90">Last 90 Days</a>
                    <a href="#" class="rankolab-dropdown-item" data-period="365">Last Year</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Dashboard Overview -->
    <div class="rankolab-dashboard-overview">
        <div class="rankolab-row">
            <div class="rankolab-col rankolab-col-3">
                <div class="rankolab-card rankolab-card-primary">
                    <div class="rankolab-card-body">
                        <div class="rankolab-metric">
                            <div class="rankolab-metric-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div class="rankolab-metric-content">
                                <div class="rankolab-metric-value"><?php echo esc_html($seo_score); ?>/100</div>
                                <div class="rankolab-metric-label">SEO Score</div>
                                <div class="rankolab-metric-change <?php echo $seo_score_change >= 0 ? 'positive' : 'negative'; ?>">
                                    <i class="fas <?php echo $seo_score_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($seo_score_change)); ?>%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rankolab-col rankolab-col-3">
                <div class="rankolab-card rankolab-card-success">
                    <div class="rankolab-card-body">
                        <div class="rankolab-metric">
                            <div class="rankolab-metric-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="rankolab-metric-content">
                                <div class="rankolab-metric-value"><?php echo esc_html(number_format($visitors)); ?></div>
                                <div class="rankolab-metric-label">Total Visitors</div>
                                <div class="rankolab-metric-change <?php echo $visitors_change >= 0 ? 'positive' : 'negative'; ?>">
                                    <i class="fas <?php echo $visitors_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($visitors_change)); ?>%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rankolab-col rankolab-col-3">
                <div class="rankolab-card rankolab-card-info">
                    <div class="rankolab-card-body">
                        <div class="rankolab-metric">
                            <div class="rankolab-metric-icon">
                                <i class="fas fa-search"></i>
                            </div>
                            <div class="rankolab-metric-content">
                                <div class="rankolab-metric-value"><?php echo esc_html(number_format($keywords_ranking)); ?></div>
                                <div class="rankolab-metric-label">Keywords Ranking</div>
                                <div class="rankolab-metric-change <?php echo $keywords_change >= 0 ? 'positive' : 'negative'; ?>">
                                    <i class="fas <?php echo $keywords_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($keywords_change)); ?>%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rankolab-col rankolab-col-3">
                <div class="rankolab-card rankolab-card-warning">
                    <div class="rankolab-card-body">
                        <div class="rankolab-metric">
                            <div class="rankolab-metric-icon">
                                <i class="fas fa-link"></i>
                            </div>
                            <div class="rankolab-metric-content">
                                <div class="rankolab-metric-value"><?php echo esc_html(number_format($backlinks)); ?></div>
                                <div class="rankolab-metric-label">Total Backlinks</div>
                                <div class="rankolab-metric-change <?php echo $backlinks_change >= 0 ? 'positive' : 'negative'; ?>">
                                    <i class="fas <?php echo $backlinks_change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down'; ?>"></i> <?php echo abs(esc_html($backlinks_change)); ?>%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Dashboard Main Content -->
    <div class="rankolab-row">
        <!-- Left Column -->
        <div class="rankolab-col rankolab-col-8">
            <!-- Traffic Overview -->
            <div class="rankolab-card">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">Traffic Overview</h3>
                    <div class="rankolab-card-actions">
                        <div class="rankolab-btn-group">
                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary active" data-chart-view="visitors">Visitors</button>
                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" data-chart-view="pageviews">Pageviews</button>
                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" data-chart-view="sessions">Sessions</button>
                        </div>
                    </div>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-chart-container">
                        <canvas id="rankolab-traffic-chart"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Content Performance -->
            <div class="rankolab-card">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">Content Performance</h3>
                    <div class="rankolab-card-actions">
                        <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" id="rankolab-view-all-content">
                            View All Content
                        </button>
                    </div>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-table-responsive">
                        <table class="rankolab-table rankolab-table-hover">
                            <thead>
                                <tr>
                                    <th>Page</th>
                                    <th>Visitors</th>
                                    <th>Avg. Time</th>
                                    <th>Bounce Rate</th>
                                    <th>SEO Score</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_content as $content): ?>
                                    <tr>
                                        <td>
                                            <div class="rankolab-content-info">
                                                <div class="rankolab-content-title"><?php echo esc_html($content['title']); ?></div>
                                                <div class="rankolab-content-url"><?php echo esc_html($content['url']); ?></div>
                                            </div>
                                        </td>
                                        <td><?php echo esc_html(number_format($content['visitors'])); ?></td>
                                        <td><?php echo esc_html($content['avg_time']); ?></td>
                                        <td><?php echo esc_html($content['bounce_rate']); ?>%</td>
                                        <td>
                                            <div class="rankolab-progress">
                                                <div class="rankolab-progress-bar rankolab-bg-<?php echo esc_attr($content['seo_score_class']); ?>" style="width: <?php echo esc_attr($content['seo_score']); ?>%">
                                                    <?php echo esc_html($content['seo_score']); ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="rankolab-btn-group">
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-analyze-content" data-content-id="<?php echo esc_attr($content['id']); ?>">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary rankolab-optimize-content" data-content-id="<?php echo esc_attr($content['id']); ?>">
                                                    <i class="fas fa-magic"></i>
                                                </button>
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-info rankolab-view-content" data-content-url="<?php echo esc_url($content['url']); ?>">
                                                    <i class="fas fa-external-link-alt"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activities -->
            <div class="rankolab-card">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">Recent Activities</h3>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-activities">
                        <?php foreach ($recent_activities as $activity): ?>
                            <div class="rankolab-activity">
                                <div class="rankolab-activity-icon rankolab-activity-icon-<?php echo esc_attr($activity['type']); ?>">
                                    <i class="fas <?php echo esc_attr($activity['icon']); ?>"></i>
                                </div>
                                <div class="rankolab-activity-content">
                                    <div class="rankolab-activity-title"><?php echo esc_html($activity['title']); ?></div>
                                    <div class="rankolab-activity-description"><?php echo esc_html($activity['description']); ?></div>
                                    <div class="rankolab-activity-time"><?php echo esc_html($activity['time']); ?></div>
                                </div>
                                <?php if (!empty($activity['action'])): ?>
                                    <div class="rankolab-activity-action">
                                        <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary" data-action="<?php echo esc_attr($activity['action_type']); ?>" data-id="<?php echo esc_attr($activity['action_id']); ?>">
                                            <?php echo esc_html($activity['action']); ?>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Column -->
        <div class="rankolab-col rankolab-col-4">
            <!-- SEO Health -->
            <div class="rankolab-card">
                <div class="rankolab-card-header">
                    <h3 class="rankolab-card-title">SEO Health</h3>
                </div>
                <div class="rankolab-card-body">
                    <div class="rankolab-seo-score-chart">
                        <canvas id="rankolab-seo-score-chart"></canvas>
                    </div>
                    
                    <div class="rankolab-seo-issues">
                        <div class="rankolab-seo-issue-category">
                            <div class="rankolab-seo-issue-header">
                                <div class="rankolab-seo-issue-title">
                                    <i class="fas fa-exclamation-circle rankolab-text-danger"></i> Critical Issues
                                </div>
                                <div class="rankolab-seo-issue-count rankolab-badge rankolab-badge-danger">
                                    <?php echo esc_html($seo_issues['critical']); ?>
                                </div>
                            </div>
                            <?php if ($seo_issues['critical'] > 0): ?>
                                <div class="rankolab-seo-issue-list">
                                    <?php foreach ($critical_issues as $issue): ?>
                                        <div class="rankolab-seo-issue">
                                            <div class="rankolab-seo-issue-info">
                                                <div class="rankolab-seo-issue-name"><?php echo esc_html($issue['name']); ?></div>
                                                <div class="rankolab-seo-issue-pages"><?php echo esc_html($issue['pages']); ?> pages affected</div>
                                            </div>
                                            <div class="rankolab-seo-issue-action">
                                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger" data-issue-id="<?php echo esc_attr($issue['id']); ?>">
                                                    Fix
                                                </button>
                                            </div>
                                        </div>
                                
(Content truncated due to size limit. Use line ranges to read in chunks)