<?php
/**
 * User Management Integration Class for Rankolab
 *
 * This class handles user management integration between the WordPress plugin and the Rankolab backend website.
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes
 */

class Rankolab_User_Integration {

    /**
     * The API integration instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      Rankolab_API_Integration    $api    The API integration instance.
     */
    private $api;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    Rankolab_API_Integration    $api    The API integration instance.
     */
    public function __construct($api) {
        $this->api = $api;
        
        // Add hooks for user management
        add_action('user_register', array($this, 'sync_new_user'), 10, 1);
        add_action('profile_update', array($this, 'sync_updated_user'), 10, 2);
        add_action('delete_user', array($this, 'handle_user_deletion'), 10, 1);
        add_action('wp_login', array($this, 'track_user_login'), 10, 2);
        
        // Add hooks for subscription management
        add_action('rankolab_subscription_created', array($this, 'handle_subscription_created'), 10, 2);
        add_action('rankolab_subscription_updated', array($this, 'handle_subscription_updated'), 10, 2);
        add_action('rankolab_subscription_cancelled', array($this, 'handle_subscription_cancelled'), 10, 2);
    }

    /**
     * Sync a new user with the backend.
     *
     * @since    1.0.0
     * @param    int    $user_id    The user ID.
     */
    public function sync_new_user($user_id) {
        $this->api->sync_user($user_id);
    }

    /**
     * Sync an updated user with the backend.
     *
     * @since    1.0.0
     * @param    int       $user_id      The user ID.
     * @param    WP_User   $old_user_data    The old user data.
     */
    public function sync_updated_user($user_id, $old_user_data) {
        $this->api->sync_user($user_id);
    }

    /**
     * Handle user deletion.
     *
     * @since    1.0.0
     * @param    int    $user_id    The user ID.
     */
    public function handle_user_deletion($user_id) {
        $this->api->request('users/delete', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
        ), 'POST');
    }

    /**
     * Track user login.
     *
     * @since    1.0.0
     * @param    string    $user_login    The user login.
     * @param    WP_User   $user          The user object.
     */
    public function track_user_login($user_login, $user) {
        $this->api->request('users/login', array(
            'user_id' => $user->ID,
            'domain' => get_site_url(),
        ), 'POST');
    }

    /**
     * Handle subscription creation.
     *
     * @since    1.0.0
     * @param    int       $user_id           The user ID.
     * @param    array     $subscription_data    The subscription data.
     */
    public function handle_subscription_created($user_id, $subscription_data) {
        $this->api->request('subscriptions/create', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
            'subscription' => $subscription_data,
        ), 'POST');
    }

    /**
     * Handle subscription update.
     *
     * @since    1.0.0
     * @param    int       $user_id           The user ID.
     * @param    array     $subscription_data    The subscription data.
     */
    public function handle_subscription_updated($user_id, $subscription_data) {
        $this->api->request('subscriptions/update', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
            'subscription' => $subscription_data,
        ), 'POST');
    }

    /**
     * Handle subscription cancellation.
     *
     * @since    1.0.0
     * @param    int       $user_id           The user ID.
     * @param    array     $subscription_data    The subscription data.
     */
    public function handle_subscription_cancelled($user_id, $subscription_data) {
        $this->api->request('subscriptions/cancel', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
            'subscription' => $subscription_data,
        ), 'POST');
    }

    /**
     * Get user subscription details.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @return   array|WP_Error        The subscription details or WP_Error on failure.
     */
    public function get_subscription_details($user_id) {
        return $this->api->request('subscriptions/details', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
        ));
    }

    /**
     * Check if a user has an active subscription.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @return   boolean               Whether the user has an active subscription.
     */
    public function has_active_subscription($user_id) {
        $subscription = $this->get_subscription_details($user_id);
        
        if (is_wp_error($subscription)) {
            return false;
        }
        
        return isset($subscription['active']) && $subscription['active'];
    }

    /**
     * Get the subscription plan for a user.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @return   string                The subscription plan or empty string on failure.
     */
    public function get_subscription_plan($user_id) {
        $subscription = $this->get_subscription_details($user_id);
        
        if (is_wp_error($subscription)) {
            return '';
        }
        
        return isset($subscription['plan']) ? $subscription['plan'] : '';
    }

    /**
     * Check if a user has access to a specific feature.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @param    string    $feature    The feature to check.
     * @return   boolean               Whether the user has access to the feature.
     */
    public function has_feature_access($user_id, $feature) {
        $subscription = $this->get_subscription_details($user_id);
        
        if (is_wp_error($subscription)) {
            return false;
        }
        
        return isset($subscription['features']) && in_array($feature, $subscription['features']);
    }

    /**
     * Get the usage limits for a user.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @return   array                 The usage limits or empty array on failure.
     */
    public function get_usage_limits($user_id) {
        $subscription = $this->get_subscription_details($user_id);
        
        if (is_wp_error($subscription)) {
            return array();
        }
        
        return isset($subscription['limits']) ? $subscription['limits'] : array();
    }

    /**
     * Track feature usage for a user.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @param    string    $feature    The feature being used.
     * @param    int       $amount     The amount of usage to track.
     * @return   array|WP_Error        The tracking result or WP_Error on failure.
     */
    public function track_feature_usage($user_id, $feature, $amount = 1) {
        return $this->api->request('usage/track', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
            'feature' => $feature,
            'amount' => $amount,
        ), 'POST');
    }

    /**
     * Get the current usage for a user.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @return   array                 The current usage or empty array on failure.
     */
    public function get_current_usage($user_id) {
        $usage = $this->api->request('usage/current', array(
            'user_id' => $user_id,
            'domain' => get_site_url(),
        ));
        
        if (is_wp_error($usage)) {
            return array();
        }
        
        return $usage;
    }

    /**
     * Check if a user has exceeded their usage limit for a feature.
     *
     * @since    1.0.0
     * @param    int       $user_id    The user ID.
     * @param    string    $feature    The feature to check.
     * @return   boolean               Whether the user has exceeded their limit.
     */
    public function has_exceeded_limit($user_id, $feature) {
        $limits = $this->get_usage_limits($user_id);
        $usage = $this->get_current_usage($user_id);
        
        if (empty($limits) || empty($usage)) {
            return false;
        }
        
        if (!isset($limits[$feature]) || !isset($usage[$feature])) {
            return false;
        }
        
        return $usage[$feature] >= $limits[$feature];
    }
}
