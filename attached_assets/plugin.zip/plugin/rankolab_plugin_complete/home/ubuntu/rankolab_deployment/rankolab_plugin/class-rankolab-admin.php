<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and hooks for the admin area.
 * Responsible for adding the main admin menu item.
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * The license manager instance.
     *
     * @since    1.1.0
     * @access   private
     * @var      Rankolab_License    $license    The license manager instance.
     */
    private $license;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    string    $plugin_name       The name of this plugin.
     * @param    string    $version    The version of this plugin.
     * @param    Rankolab_License $license The license manager instance.
     */
    public function __construct($plugin_name, $version, $license) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->license = $license; // Store the license object
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     * @param string $hook_suffix The current admin page hook.
     */
    public function enqueue_styles($hook_suffix) {
        // Only load on Rankolab pages (check if hook contains \'rankolab\
        if (strpos($hook_suffix, \"page_rankolab\") !== false) {
            // Use constant RANKOLAB_PLUGIN_URL defined in the main plugin file
            wp_enqueue_style($this->plugin_name . \"-admin-styles\", RANKOLAB_PLUGIN_URL . \"css/rankolab-admin.css\", array(), $this->version, \"all\");
            // Example: Enqueue setup wizard styles only on its page
            if ($hook_suffix === \"admin_page_rankolab-setup-wizard\") { // Assuming slug is rankolab-setup-wizard
                 wp_enqueue_style($this->plugin_name . \"-setup-wizard-styles\", RANKOLAB_PLUGIN_URL . \"css/rankolab-setup-wizard.css\", array(), $this->version, \"all\");
            }
        }
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     * @param string $hook_suffix The current admin page hook.
     */
    public function enqueue_scripts($hook_suffix) {
        // Only load on Rankolab pages
        if (strpos($hook_suffix, \"page_rankolab\") !== false) {
            // Use constant RANKOLAB_PLUGIN_URL defined in the main plugin file
            wp_enqueue_script($this->plugin_name . \"-admin-scripts\", RANKOLAB_PLUGIN_URL . \"js/rankolab-admin.js\", array(\"jquery\"), $this->version, true); // Load in footer

            // Example: Enqueue setup wizard script only on its page
            if ($hook_suffix === \"admin_page_rankolab-setup-wizard\") {
                 wp_enqueue_script($this->plugin_name . \"-setup-wizard-scripts\", RANKOLAB_PLUGIN_URL . \"js/rankolab-setup-wizard.js\", array(\"jquery\"), $this->version, true);
            }

            // Pass ajax url and nonces to scripts if needed
            wp_localize_script($this->plugin_name . \"-admin-scripts\", \"rankolab_admin_params\", array(
                \"ajax_url\" => admin_url(\"admin-ajax.php\"),
                // Add other nonces or data as needed by JS files
                // \"some_nonce\" => wp_create_nonce(\"some_action_nonce\") 
            ));
        }
    }

    /**
     * Add the main menu item to the admin area.
     * Submenus should be added by individual modules using add_submenu_page(\"rankolab\", ...).
     *
     * @since    1.0.0
     */
    public function add_plugin_admin_menu() {
        // Main menu item - points to the main dashboard (or a fallback if dashboard module fails)
        // The callback function here might be overridden by the Dashboard module if it uses the same slug \'rankolab\'.
        add_menu_page(
            __(\"Rankolab - SEO & Content Suite\", \"rankolab\"), // Page Title
            __(\"Rankolab\", \"rankolab\"), // Menu Title
            \"manage_options\", // Capability
            \"rankolab\", // Menu Slug (used as parent slug by modules)
            array($this, \"display_fallback_dashboard_page\"), // Callback function (fallback)
            \"dashicons-chart-line\", // Icon
            30 // Position
        );
        
        // Note: Individual modules (like Dashboard, Cache, Newsletter, Logging, License, etc.)
        // MUST use add_submenu_page(\"rankolab\", ...) to add their pages under this main menu.
        // Example (in Dashboard module): 
        // add_submenu_page(
        //     \"rankolab\", 
        //     __(\"Dashboard\", \"rankolab\"), 
        //     __(\"Dashboard\", \"rankolab\"), 
        //     \"manage_options\", 
        //     \"rankolab\", // Use parent slug to make it the default page
        //     array($this, \"display_dashboard_page\") 
        // );
        // Example (in Cache module):
        // add_submenu_page(
        //     \"rankolab\", 
        //     __(\"Cache Management\", \"rankolab\"), 
        //     __(\"Cache Management\", \"rankolab\"), 
        //     \"manage_options\", 
        //     \"rankolab-cache-management\", 
        //     array($this, \"display_settings_page\") 
        // );
    }

    /**
     * Display a fallback dashboard page if the main Dashboard module fails or is missing,
     * or if accessed directly via the main menu slug before the Dashboard module overrides it.
     *
     * @since    1.1.0
     */
    public function display_fallback_dashboard_page() {
        ?>
        <div class="wrap rankolab-admin-page">
            <h1><?php _e(\"Welcome to Rankolab\", \"rankolab\"); ?></h1>
            <p><?php _e(\"Please navigate using the submenus. If you don\\'t see any submenus, there might be an issue with module loading.\", \"rankolab\"); ?></p>
            <?php
            // Check license status and display a notice if needed
            if ($this->license && method_exists($this->license, \"get_license_status\")) {
                $status = $this->license->get_license_status();
                if ($status !== \"valid\") {
                    echo \"<div class=\"notice notice-warning\"><p>\";
                    printf(
                        __(\"Your Rankolab license is not active. Please %sactivate your license%s to unlock all features.\", \"rankolab\"),
                        \"<a href=\"\" . admin_url(\"admin.php?page=rankolab-license\") . \"\">\", // Assuming license module uses slug \'rankolab-license\'
                        \"</a>\"
                    );
                    echo \"</p></div>\";
                }
            }
            ?>
            <!-- Basic info or links could go here -->
        </div>
        <?php
    }

    // Removed placeholder display functions like display_plugin_content_page, display_plugin_seo_page etc.
    // These should be handled by their respective modules which add their own submenu pages.
}

