/**
 * Rankolab Setup Wizard JavaScript
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin/js
 */

jQuery(document).ready(function($) {
    // Initialize the wizard
    const RankolabWizard = {
        init: function() {
            this.bindEvents();
            this.initializeSteps();
            this.checkLicenseStatus();
        },

        bindEvents: function() {
            // Next button click
            $('.rankolab-wizard-next').on('click', this.handleNextStep.bind(this));
            
            // Previous button click
            $('.rankolab-wizard-prev').on('click', this.handlePrevStep.bind(this));
            
            // Skip button click
            $('.rankolab-wizard-skip').on('click', this.handleSkipWizard.bind(this));
            
            // Plan selection
            $(document).on('click', '.rankolab-select-plan', this.handlePlanSelection.bind(this));
            
            // API connection
            $(document).on('click', '.rankolab-connect-api', this.handleApiConnection.bind(this));
            
            // License verification
            $(document).on('click', '#rankolab-verify-license', this.verifyLicense.bind(this));
        },

        initializeSteps: function() {
            // Set initial step
            const currentStep = parseInt($('#rankolab_wizard_step').val());
            this.updateStepIndicators(currentStep);
            
            // Initialize form validation
            this.initFormValidation();
        },

        handleNextStep: function() {
            const step = parseInt($('#rankolab_wizard_step').val());
            const nonce = $('#rankolab_wizard_nonce').val();
            
            // Validate current step
            if (!this.validateStep(step)) {
                return;
            }
            
            // Collect step data
            const data = {
                action: 'rankolab_wizard_next_step',
                step: step,
                nonce: nonce
            };
            
            // Add step-specific data
            this.addStepData(data, step);
            
            // Show loading indicator
            this.showLoading();
            
            // Send AJAX request
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: data,
                success: this.handleStepResponse.bind(this),
                error: this.handleAjaxError.bind(this)
            });
        },

        handlePrevStep: function() {
            const step = parseInt($('#rankolab_wizard_step').val());
            const nonce = $('#rankolab_wizard_nonce').val();
            
            // Show loading indicator
            this.showLoading();
            
            // Send AJAX request
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'rankolab_wizard_prev_step',
                    step: step,
                    nonce: nonce
                },
                success: this.handleStepResponse.bind(this),
                error: this.handleAjaxError.bind(this)
            });
        },

        handleSkipWizard: function(e) {
            e.preventDefault();
            
            if (confirm('Are you sure you want to skip the setup wizard? You can access it later from the Settings page.')) {
                const nonce = $('#rankolab_wizard_nonce').val();
                
                // Show loading indicator
                this.showLoading();
                
                // Send AJAX request
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'rankolab_wizard_skip',
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.href = response.data.redirect;
                        } else {
                            this.hideLoading();
                            this.showError(response.data);
                        }
                    }.bind(this),
                    error: this.handleAjaxError.bind(this)
                });
            }
        },

        handlePlanSelection: function(e) {
            $('.rankolab-select-plan').removeClass('selected');
            $(e.currentTarget).addClass('selected');
            $('#rankolab_selected_plan').val($(e.currentTarget).data('plan'));
        },

        handleApiConnection: function(e) {
            const api = $(e.currentTarget).data('api');
            const $button = $(e.currentTarget);
            
            // Show loading state
            $button.prop('disabled', true).text('Connecting...');
            
            // Simulate API connection (in real implementation, this would connect to the actual API)
            setTimeout(function() {
                $button.text('Connected').addClass('connected');
                
                // Store the connection status
                $('#rankolab_' + api + '_connected').val('yes');
                
                // Show success message
                this.showNotice('Successfully connected to ' + this.formatApiName(api) + ' API.', 'success');
            }.bind(this), 1500);
        },

        verifyLicense: function() {
            const licenseKey = $('#rankolab_license_key').val();
            
            if (!licenseKey) {
                this.showError('Please enter a license key.');
                return;
            }
            
            const $button = $('#rankolab-verify-license');
            
            // Show loading state
            $button.prop('disabled', true).text('Verifying...');
            
            // Send AJAX request
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'rankolab_verify_license',
                    license_key: licenseKey,
                    nonce: $('#rankolab_wizard_nonce').val()
                },
                success: function(response) {
                    $button.prop('disabled', false).text('Verify License');
                    
                    if (response.success) {
                        $('#rankolab-license-status')
                            .removeClass('invalid expired')
                            .addClass('valid')
                            .html('<p class="rankolab-license-valid">' + response.data.message + '</p>');
                        
                        this.showNotice(response.data.message, 'success');
                    } else {
                        $('#rankolab-license-status')
                            .removeClass('valid expired')
                            .addClass('invalid')
                            .html('<p class="rankolab-license-invalid">' + response.data + '</p>');
                        
                        this.showError(response.data);
                    }
                }.bind(this),
                error: function() {
                    $button.prop('disabled', false).text('Verify License');
                    this.showError('An error occurred while verifying the license. Please try again.');
                }.bind(this)
            });
        },

        handleStepResponse: function(response) {
            this.hideLoading();
            
            if (response.success) {
                // Update step
                $('#rankolab_wizard_step').val(response.data.step);
                
                // Update content
                $('.rankolab-wizard-content').html(response.data.content);
                
                // Update steps
                this.updateStepIndicators(response.data.step);
                
                // Update buttons
                this.updateNavigationButtons(response.data.step);
                
                // Scroll to top
                $('.rankolab-wizard-wrap').animate({ scrollTop: 0 }, 300);
                
                // Initialize form validation for the new step
                this.initFormValidation();
            } else {
                this.showError(response.data);
            }
        },

        handleAjaxError: function() {
            this.hideLoading();
            this.showError('An error occurred. Please try again.');
        },

        addStepData: function(data, step) {
            switch (step) {
                case 2:
                    data.rankolab_license_key = $('#rankolab_license_key').val();
                    break;
                case 3:
                    data.rankolab_selected_plan = $('#rankolab_selected_plan').val();
                    break;
                case 4:
                    data.rankolab_website_url = $('#rankolab_website_url').val();
                    data.rankolab_website_niche = $('#rankolab_website_niche').val();
                    break;
                case 5:
                    // Collect API connection statuses
                    data.rankolab_google_search_console_connected = $('#rankolab_google_search_console_connected').val();
                    data.rankolab_unsplash_connected = $('#rankolab_unsplash_connected').val();
                    data.rankolab_social_media_connected = $('#rankolab_social_media_connected').val();
                    break;
            }
        },

        validateStep: function(step) {
            switch (step) {
                case 2:
                    // License key validation
                    const licenseKey = $('#rankolab_license_key').val();
                    if (!licenseKey) {
                        this.showError('Please enter a license key.');
                        return false;
                    }
                    break;
                case 3:
                    // Plan selection validation
                    const selectedPlan = $('#rankolab_selected_plan').val();
                    if (!selectedPlan) {
                        this.showError('Please select a subscription plan.');
                        return false;
                    }
                    break;
                case 4:
                    // Website details validation
                    const websiteUrl = $('#rankolab_website_url').val();
                    if (!websiteUrl) {
                        this.showError('Please enter your website URL.');
                        return false;
                    }
                    
                    // Simple URL validation
                    if (!this.isValidUrl(websiteUrl)) {
                        this.showError('Please enter a valid website URL.');
                        return false;
                    }
                    break;
            }
            
            return true;
        },

        updateStepIndicators: function(currentStep) {
            $('.rankolab-wizard-step').removeClass('active completed');
            
            for (let i = 1; i <= 6; i++) {
                if (i === currentStep) {
                    $('.rankolab-wizard-step:nth-child(' + i + ')').addClass('active');
                } else if (i < currentStep) {
                    $('.rankolab-wizard-step:nth-child(' + i + ')').addClass('completed');
                }
            }
        },

        updateNavigationButtons: function(step) {
            if (step > 1) {
                $('.rankolab-wizard-prev').show();
            } else {
                $('.rankolab-wizard-prev').hide();
            }
            
            if (step < 6) {
                $('.rankolab-wizard-next').show();
                $('.rankolab-wizard-skip').show();
            } else {
                $('.rankolab-wizard-next').hide();
                $('.rankolab-wizard-skip').hide();
            }
        },

        showLoading: function() {
            // Add loading overlay if it doesn't exist
            if ($('.rankolab-wizard-loading').length === 0) {
                $('<div class="rankolab-wizard-loading"><div class="rankolab-wizard-loading-spinner"></div></div>').appendTo('.rankolab-wizard-container');
            }
            
            $('.rankolab-wizard-loading').fadeIn(200);
        },

        hideLoading: function() {
            $('.rankolab-wizard-loading').fadeOut(200);
        },

        showError: function(message) {
            this.showNotice(message, 'error');
        },

        showNotice: function(message, type) {
            // Remove existing notices
            $('.rankolab-wizard-notice').remove();
            
            // Create notice
            const $notice = $('<div class="rankolab-wizard-notice rankolab-wizard-notice-' + type + '"><p>' + message + '</p></div>');
            
            // Add close button
            const $closeButton = $('<button type="button" class="rankolab-wizard-notice-close"><span class="dashicons dashicons-dismiss"></span></button>');
            $closeButton.on('click', function() {
                $notice.fadeOut(200, function() {
                    $(this).remove();
                });
            });
            
            $notice.append($closeButton);
            
            // Add to page
            $notice.prependTo('.rankolab-wizard-content').hide().fadeIn(200);
            
            // Auto-hide after 5 seconds for success notices
            if (type === 'success') {
                setTimeout(function() {
                    $notice.fadeOut(200, function() {
                        $(this).remove();
                    });
                }, 5000);
            }
        },

        initFormValidation: function() {
            // Add validation classes and event listeners to form fields
            $('.rankolab-wizard-form-field input, .rankolab-wizard-form-field select').on('change', function() {
                $(this).removeClass('invalid');
            });
        },

        checkLicenseStatus: function() {
            // Check if license key is already verified
            const licenseStatus = $('#rankolab-license-status').attr('class');
            
            if (licenseStatus === 'valid') {
                this.showNotice('License is active and valid.', 'success');
            } else if (licenseStatus === 'invalid') {
                this.showNotice('License is invalid. Please check your key and try again.', 'error');
            } else if (licenseStatus === 'expired') {
                this.showNotice('License has expired. Please renew your license.', 'error');
            }
        },

        isValidUrl: function(url) {
            try {
                new URL(url);
                return true;
            } catch (e) {
                return false;
            }
        },

        formatApiName: function(apiSlug) {
            // Convert api_name to API Name
            return apiSlug.split('_').map(function(word) {
                return word.charAt(0).toUpperCase() + word.slice(1);
            }).join(' ');
        }
    };

    // Initialize the wizard
    RankolabWizard.init();
});

// Add loading spinner and notice styles
jQuery(document).ready(function($) {
    const styles = `
        .rankolab-wizard-loading {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
        
        .rankolab-wizard-loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #0073aa;
            border-radius: 50%;
            animation: rankolab-spin 1s linear infinite;
        }
        
        @keyframes rankolab-spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg)
(Content truncated due to size limit. Use line ranges to read in chunks)