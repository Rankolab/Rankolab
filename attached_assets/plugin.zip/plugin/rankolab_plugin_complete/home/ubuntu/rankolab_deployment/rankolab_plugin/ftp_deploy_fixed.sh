#!/bin/bash

# FTP Deployment Script for Rankolab
# This script uploads the Rankolab plugin to the production server

# FTP credentials
FTP_SERVER="ftp.rankolab.com"
FTP_USER="rankolab.com"
FTP_PASS="Rankolab@0309"
REMOTE_DIR="/public_html/wp-content/plugins"

# Local package path
LOCAL_PACKAGE="/home/ubuntu/rankolab_dev/rankolab_deployment_package.zip"
LOCAL_EXTRACTED="/home/ubuntu/rankolab_dev/deployment_package"

echo "Starting Rankolab deployment to $FTP_SERVER..."

# Create lftp script with certificate verification disabled
cat > /tmp/lftp_commands.txt << EOF
set ssl:verify-certificate no
open $FTP_SERVER
user $FTP_USER $FTP_PASS
cd $REMOTE_DIR
mkdir -p rankolab
cd rankolab
mirror -R $LOCAL_EXTRACTED .
bye
EOF

# Execute lftp script
lftp -f /tmp/lftp_commands.txt

# Check if deployment was successful
if [ $? -eq 0 ]; then
    echo "Deployment completed successfully!"
else
    echo "Deployment failed. Please check the error messages above."
    exit 1
fi

# Clean up
rm /tmp/lftp_commands.txt

echo "Rankolab plugin has been deployed to $FTP_SERVER$REMOTE_DIR/rankolab/"
echo "Please activate the plugin through the WordPress admin interface."
