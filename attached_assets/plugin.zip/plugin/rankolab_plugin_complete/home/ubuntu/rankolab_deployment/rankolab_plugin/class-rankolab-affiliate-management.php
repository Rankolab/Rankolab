<?php
/**
 * The file that defines the affiliate management module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The affiliate management module class.
 *
 * This class handles affiliate management functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Affiliate_Management {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_get_affiliates', array($this, 'ajax_get_affiliates'));
        add_action('wp_ajax_rankolab_add_affiliate', array($this, 'ajax_add_affiliate'));
        add_action('wp_ajax_rankolab_update_affiliate', array($this, 'ajax_update_affiliate'));
        add_action('wp_ajax_rankolab_delete_affiliate', array($this, 'ajax_delete_affiliate'));
        add_action('wp_ajax_rankolab_get_affiliate_stats', array($this, 'ajax_get_affiliate_stats'));
        add_action('wp_ajax_rankolab_generate_affiliate_report', array($this, 'ajax_generate_affiliate_report'));
        add_action('wp_ajax_rankolab_save_affiliate_settings', array($this, 'ajax_save_affiliate_settings'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_affiliate_page'), 20);
        
        // Register settings
        add_action('admin_init', array($this, 'register_affiliate_settings'));
        
        // Add shortcodes
        add_shortcode('rankolab_affiliate_signup', array($this, 'affiliate_signup_shortcode'));
        add_shortcode('rankolab_affiliate_login', array($this, 'affiliate_login_shortcode'));
        add_shortcode('rankolab_affiliate_dashboard', array($this, 'affiliate_dashboard_shortcode'));
        
        // Add frontend hooks
        add_action('init', array($this, 'register_affiliate_endpoints'));
        add_action('template_redirect', array($this, 'handle_affiliate_endpoints'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        
        // Add tracking hooks
        add_action('init', array($this, 'track_affiliate_visit'));
        add_action('woocommerce_order_status_completed', array($this, 'track_affiliate_conversion'), 10, 1);
    }

    /**
     * Add affiliate management admin page.
     *
     * @since    1.0.0
     */
    public function add_affiliate_page() {
        add_submenu_page(
            'rankolab',
            'Affiliate Management',
            'Affiliates',
            'manage_options',
            'rankolab-affiliates',
            array($this, 'display_affiliate_page')
        );
    }

    /**
     * Display affiliate management admin page.
     *
     * @since    1.0.0
     */
    public function display_affiliate_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-affiliates.php';
    }

    /**
     * Register affiliate management settings.
     *
     * @since    1.0.0
     */
    public function register_affiliate_settings() {
        register_setting('rankolab_affiliates', 'rankolab_affiliate_settings');
        
        add_settings_section(
            'rankolab_affiliate_general',
            'General Settings',
            array($this, 'affiliate_general_section_callback'),
            'rankolab_affiliates'
        );
        
        add_settings_field(
            'enable_affiliate_program',
            'Enable Affiliate Program',
            array($this, 'enable_affiliate_program_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_general'
        );
        
        add_settings_field(
            'affiliate_commission_rate',
            'Default Commission Rate',
            array($this, 'affiliate_commission_rate_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_general'
        );
        
        add_settings_field(
            'affiliate_cookie_duration',
            'Cookie Duration',
            array($this, 'affiliate_cookie_duration_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_general'
        );
        
        add_settings_section(
            'rankolab_affiliate_registration',
            'Registration Settings',
            array($this, 'affiliate_registration_section_callback'),
            'rankolab_affiliates'
        );
        
        add_settings_field(
            'enable_public_registration',
            'Enable Public Registration',
            array($this, 'enable_public_registration_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_registration'
        );
        
        add_settings_field(
            'require_approval',
            'Require Admin Approval',
            array($this, 'require_approval_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_registration'
        );
        
        add_settings_field(
            'registration_fields',
            'Registration Fields',
            array($this, 'registration_fields_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_registration'
        );
        
        add_settings_section(
            'rankolab_affiliate_payout',
            'Payout Settings',
            array($this, 'affiliate_payout_section_callback'),
            'rankolab_affiliates'
        );
        
        add_settings_field(
            'minimum_payout',
            'Minimum Payout Amount',
            array($this, 'minimum_payout_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_payout'
        );
        
        add_settings_field(
            'payout_methods',
            'Payout Methods',
            array($this, 'payout_methods_callback'),
            'rankolab_affiliates',
            'rankolab_affiliate_payout'
        );
    }

    /**
     * Affiliate general section callback.
     *
     * @since    1.0.0
     */
    public function affiliate_general_section_callback() {
        echo '<p>Configure general settings for the affiliate program.</p>';
    }

    /**
     * Enable affiliate program callback.
     *
     * @since    1.0.0
     */
    public function enable_affiliate_program_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $value = isset($options['enable_affiliate_program']) ? $options['enable_affiliate_program'] : 1;
        
        echo '<input type="checkbox" id="enable_affiliate_program" name="rankolab_affiliate_settings[enable_affiliate_program]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_affiliate_program">Enable the affiliate program on your site</label>';
    }

    /**
     * Affiliate commission rate callback.
     *
     * @since    1.0.0
     */
    public function affiliate_commission_rate_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $value = isset($options['affiliate_commission_rate']) ? $options['affiliate_commission_rate'] : 20;
        
        echo '<input type="number" id="affiliate_commission_rate" name="rankolab_affiliate_settings[affiliate_commission_rate]" value="' . esc_attr($value) . '" min="1" max="100" step="0.1" style="width: 70px;">%';
        echo '<p class="description">Default commission rate for affiliates (percentage)</p>';
    }

    /**
     * Affiliate cookie duration callback.
     *
     * @since    1.0.0
     */
    public function affiliate_cookie_duration_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $value = isset($options['affiliate_cookie_duration']) ? $options['affiliate_cookie_duration'] : 30;
        
        echo '<input type="number" id="affiliate_cookie_duration" name="rankolab_affiliate_settings[affiliate_cookie_duration]" value="' . esc_attr($value) . '" min="1" max="365" style="width: 70px;"> days';
        echo '<p class="description">How long the affiliate cookie should last</p>';
    }

    /**
     * Affiliate registration section callback.
     *
     * @since    1.0.0
     */
    public function affiliate_registration_section_callback() {
        echo '<p>Configure settings for affiliate registration.</p>';
    }

    /**
     * Enable public registration callback.
     *
     * @since    1.0.0
     */
    public function enable_public_registration_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $value = isset($options['enable_public_registration']) ? $options['enable_public_registration'] : 1;
        
        echo '<input type="checkbox" id="enable_public_registration" name="rankolab_affiliate_settings[enable_public_registration]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_public_registration">Allow users to register as affiliates from the frontend</label>';
    }

    /**
     * Require approval callback.
     *
     * @since    1.0.0
     */
    public function require_approval_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $value = isset($options['require_approval']) ? $options['require_approval'] : 1;
        
        echo '<input type="checkbox" id="require_approval" name="rankolab_affiliate_settings[require_approval]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="require_approval">Require admin approval before affiliates can start promoting</label>';
    }

    /**
     * Registration fields callback.
     *
     * @since    1.0.0
     */
    public function registration_fields_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $fields = isset($options['registration_fields']) ? $options['registration_fields'] : array('name', 'email', 'website', 'payment_info');
        
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[registration_fields][]" value="name" ' . checked(in_array('name', $fields), true, false) . '> Name</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[registration_fields][]" value="email" ' . checked(in_array('email', $fields), true, false) . '> Email</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[registration_fields][]" value="website" ' . checked(in_array('website', $fields), true, false) . '> Website</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[registration_fields][]" value="payment_info" ' . checked(in_array('payment_info', $fields), true, false) . '> Payment Information</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[registration_fields][]" value="tax_info" ' . checked(in_array('tax_info', $fields), true, false) . '> Tax Information</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[registration_fields][]" value="promotion_methods" ' . checked(in_array('promotion_methods', $fields), true, false) . '> Promotion Methods</label><br>';
    }

    /**
     * Affiliate payout section callback.
     *
     * @since    1.0.0
     */
    public function affiliate_payout_section_callback() {
        echo '<p>Configure settings for affiliate payouts.</p>';
    }

    /**
     * Minimum payout callback.
     *
     * @since    1.0.0
     */
    public function minimum_payout_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $value = isset($options['minimum_payout']) ? $options['minimum_payout'] : 50;
        
        echo '<input type="number" id="minimum_payout" name="rankolab_affiliate_settings[minimum_payout]" value="' . esc_attr($value) . '" min="1" max="1000" style="width: 70px;">$';
        echo '<p class="description">Minimum amount required for payout</p>';
    }

    /**
     * Payout methods callback.
     *
     * @since    1.0.0
     */
    public function payout_methods_callback() {
        $options = get_option('rankolab_affiliate_settings');
        $methods = isset($options['payout_methods']) ? $options['payout_methods'] : array('paypal', 'bank_transfer');
        
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[payout_methods][]" value="paypal" ' . checked(in_array('paypal', $methods), true, false) . '> PayPal</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[payout_methods][]" value="bank_transfer" ' . checked(in_array('bank_transfer', $methods), true, false) . '> Bank Transfer</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[payout_methods][]" value="stripe" ' . checked(in_array('stripe', $methods), true, false) . '> Stripe</label><br>';
        echo '<label><input type="checkbox" name="rankolab_affiliate_settings[payout_methods][]" value="payoneer" ' . checked(in_array('payoneer', $methods), true, false) . '> Payoneer</label><br>';
    }

    /**
     * Register affiliate endpoints.
     *
     * @since    1.0.0
     */
    public function register_affiliate_endpoints() {
        add_rewrite_endpoint('affiliate-dashboard', EP_ROOT | EP_PAGES);
        add_rewrite_endpoint('affiliate-register', EP_ROOT | EP_PAGES);
        add_rewrite_endpoint('affiliate-login', EP_ROOT | EP_PAGES);
        
        // Flush rewrite rules only once
        if (get_option('rankolab_affiliate_flush_rewrite_rules', false) === false) {
            flush_rewrite_rules();
            update_option('rankolab_affiliate_flush_rewrite_rules', true);
        }
    }

    /**
     * Handle affiliate endpoints.
     *
     * @since    1.0.0
     */
    public function handle_affiliate_endpoints() {
        global $wp_query;
        
        // Check if we're on an affiliate endpoint
        if (isset($wp_query->query_vars['affiliate-dashboard'])) {
            // Check if user is logged in and is an affiliate
            if (!is_user_logged_in()) {
                wp_redirect(home_url('/affiliate-login/'));
                exit;
            }
            
            $user_id = get_current_user_id();
            $is_affiliate = get_user_meta($user_id, 'rankolab_is_affiliate', true);
            
            if (!$is_affiliate) {
                wp_redirect(home_url('/affiliate-register/'));
                exit;
            }
        }
    }

    /**
     * Enqueue frontend scripts.
     *
     * @since    1.0.0
     */
    public function enqueue_frontend_scripts() {
        // Check if we're on an affiliate page
        global $wp_query;
        
        if (isset($wp_query->query_vars['affiliate-dashboard']) || 
            isset($wp_query->query_vars['affiliate-register']) || 
            isset($wp_query->query_vars['affiliate-login']) ||
            has_shortcode(get_post()->post_content, 'rankolab_affiliate_signup') ||
            has_shortcode(get_post()->post_content, 'rankolab_affiliate_login') ||
            has_shortcode(get_post()->post_content, 'rankolab_affiliate_dashboard')) {
            
            // Enqueue styles
            wp_enqueue_style(
                'rankolab-affiliate-frontend',
                plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/css/rankolab-
(Content truncated due to size limit. Use line ranges to read in chunks)