<!-- Rankolab Link Building Module Template -->
<div class="rankolab-link-building-module" id="rankolab-link-building">
    <!-- Module Header -->
    <div class="rankolab-module-header">
        <div class="rankolab-module-title">
            <h2>Link Building</h2>
            <p>Find link opportunities, manage outreach campaigns, and track your backlink profile.</p>
        </div>
    </div>
    
    <!-- Link Opportunities -->
    <div class="rankolab-card rankolab-card-primary">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Link Opportunities</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-find-opportunities">
                    <i class="fas fa-search"></i> Find New Opportunities
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <div class="rankolab-table-responsive">
                <table class="rankolab-table rankolab-table-hover">
                    <thead>
                        <tr>
                            <th>Website</th>
                            <th>Domain Authority</th>
                            <th>Opportunity Type</th>
                            <th>Relevance</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($link_opportunities)): ?>
                            <?php foreach ($link_opportunities as $opportunity): ?>
                                <tr>
                                    <td>
                                        <div class="rankolab-website-info">
                                            <div class="rankolab-website-favicon">
                                                <img src="<?php echo esc_url($opportunity['favicon']); ?>" alt="Favicon">
                                            </div>
                                            <div class="rankolab-website-details">
                                                <div class="rankolab-website-name"><?php echo esc_html($opportunity['name']); ?></div>
                                                <div class="rankolab-website-url"><?php echo esc_html($opportunity['url']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="rankolab-domain-authority">
                                            <div class="rankolab-authority-badge <?php echo $opportunity['domain_authority'] >= 50 ? 'high' : ($opportunity['domain_authority'] >= 30 ? 'medium' : 'low'); ?>">
                                                <?php echo esc_html($opportunity['domain_authority']); ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo esc_html($opportunity['type']); ?></td>
                                    <td>
                                        <div class="rankolab-relevance-score">
                                            <div class="rankolab-relevance-stars">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <?php if ($i <= $opportunity['relevance']): ?>
                                                        <i class="fas fa-star"></i>
                                                    <?php else: ?>
                                                        <i class="far fa-star"></i>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="rankolab-status-badge rankolab-status-<?php echo esc_attr(strtolower($opportunity['status'])); ?>">
                                            <?php echo esc_html($opportunity['status']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="rankolab-btn-group">
                                            <a href="<?php echo esc_url($opportunity['url']); ?>" target="_blank" rel="noopener noreferrer" class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary">
                                                <i class="fas fa-external-link-alt"></i>
                                            </a>
                                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-success rankolab-start-outreach" data-opportunity-id="<?php echo esc_attr($opportunity['id']); ?>">
                                                <i class="fas fa-envelope"></i> Outreach
                                            </button>
                                            <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger rankolab-dismiss-opportunity" data-opportunity-id="<?php echo esc_attr($opportunity['id']); ?>">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="rankolab-empty-state">No link opportunities found. Click "Find New Opportunities" to discover potential backlink sources.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Outreach Campaigns -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Outreach Campaigns</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-new-campaign">
                    <i class="fas fa-plus"></i> New Campaign
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <?php if (!empty($outreach_campaigns)): ?>
                <div class="rankolab-campaigns">
                    <?php foreach ($outreach_campaigns as $campaign): ?>
                        <div class="rankolab-campaign-item">
                            <div class="rankolab-campaign-header">
                                <div class="rankolab-campaign-title"><?php echo esc_html($campaign['name']); ?></div>
                                <div class="rankolab-campaign-status rankolab-status-<?php echo esc_attr(strtolower($campaign['status'])); ?>">
                                    <?php echo esc_html($campaign['status']); ?>
                                </div>
                            </div>
                            <div class="rankolab-campaign-metrics">
                                <div class="rankolab-campaign-metric">
                                    <div class="rankolab-campaign-metric-value"><?php echo esc_html($campaign['prospects']); ?></div>
                                    <div class="rankolab-campaign-metric-label">Prospects</div>
                                </div>
                                <div class="rankolab-campaign-metric">
                                    <div class="rankolab-campaign-metric-value"><?php echo esc_html($campaign['sent']); ?></div>
                                    <div class="rankolab-campaign-metric-label">Sent</div>
                                </div>
                                <div class="rankolab-campaign-metric">
                                    <div class="rankolab-campaign-metric-value"><?php echo esc_html($campaign['opened']); ?></div>
                                    <div class="rankolab-campaign-metric-label">Opened</div>
                                </div>
                                <div class="rankolab-campaign-metric">
                                    <div class="rankolab-campaign-metric-value"><?php echo esc_html($campaign['replied']); ?></div>
                                    <div class="rankolab-campaign-metric-label">Replied</div>
                                </div>
                                <div class="rankolab-campaign-metric">
                                    <div class="rankolab-campaign-metric-value"><?php echo esc_html($campaign['converted']); ?></div>
                                    <div class="rankolab-campaign-metric-label">Converted</div>
                                </div>
                            </div>
                            <div class="rankolab-campaign-progress">
                                <div class="rankolab-progress">
                                    <div class="rankolab-progress-bar" style="width: <?php echo esc_attr($campaign['progress']); ?>%;"><?php echo esc_html($campaign['progress']); ?>%</div>
                                </div>
                            </div>
                            <div class="rankolab-campaign-actions">
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-view-campaign" data-campaign-id="<?php echo esc_attr($campaign['id']); ?>">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-success rankolab-send-emails" data-campaign-id="<?php echo esc_attr($campaign['id']); ?>">
                                    <i class="fas fa-paper-plane"></i> Send Emails
                                </button>
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-info rankolab-campaign-settings" data-campaign-id="<?php echo esc_attr($campaign['id']); ?>">
                                    <i class="fas fa-cog"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="rankolab-empty-state">
                    <div class="rankolab-empty-state-icon">
                        <i class="fas fa-envelope-open-text"></i>
                    </div>
                    <div class="rankolab-empty-state-text">No outreach campaigns created yet. Click "New Campaign" to get started.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Email Templates -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Email Templates</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-new-template">
                    <i class="fas fa-plus"></i> New Template
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <?php if (!empty($email_templates)): ?>
                <div class="rankolab-email-templates">
                    <?php foreach ($email_templates as $template): ?>
                        <div class="rankolab-template-item">
                            <div class="rankolab-template-header">
                                <div class="rankolab-template-title"><?php echo esc_html($template['name']); ?></div>
                                <div class="rankolab-template-type"><?php echo esc_html($template['type']); ?></div>
                            </div>
                            <div class="rankolab-template-preview">
                                <?php echo wp_kses_post($template['preview']); ?>
                            </div>
                            <div class="rankolab-template-metrics">
                                <div class="rankolab-template-metric">
                                    <div class="rankolab-template-metric-label">Open Rate</div>
                                    <div class="rankolab-template-metric-value"><?php echo esc_html($template['open_rate']); ?>%</div>
                                </div>
                                <div class="rankolab-template-metric">
                                    <div class="rankolab-template-metric-label">Reply Rate</div>
                                    <div class="rankolab-template-metric-value"><?php echo esc_html($template['reply_rate']); ?>%</div>
                                </div>
                                <div class="rankolab-template-metric">
                                    <div class="rankolab-template-metric-label">Conversion Rate</div>
                                    <div class="rankolab-template-metric-value"><?php echo esc_html($template['conversion_rate']); ?>%</div>
                                </div>
                            </div>
                            <div class="rankolab-template-actions">
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-primary rankolab-edit-template" data-template-id="<?php echo esc_attr($template['id']); ?>">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-secondary rankolab-duplicate-template" data-template-id="<?php echo esc_attr($template['id']); ?>">
                                    <i class="fas fa-copy"></i> Duplicate
                                </button>
                                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-outline-danger rankolab-delete-template" data-template-id="<?php echo esc_attr($template['id']); ?>">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="rankolab-empty-state">
                    <div class="rankolab-empty-state-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="rankolab-empty-state-text">No email templates created yet. Click "New Template" to create your first template.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Backlink Tracker -->
    <div class="rankolab-card">
        <div class="rankolab-card-header">
            <h3 class="rankolab-card-title">Backlink Tracker</h3>
            <div class="rankolab-card-actions">
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-primary" id="rankolab-add-backlink">
                    <i class="fas fa-plus"></i> Add Backlink
                </button>
                <button class="rankolab-btn rankolab-btn-sm rankolab-btn-secondary" id="rankolab-refresh-backlinks">
                    <i class="fas fa-sync-alt"></i> Refresh Data
                </button>
            </div>
        </div>
        <div class="rankolab-card-body">
            <!-- Backlink Summary -->
            <div class="rankolab-backlink-summary">
                <div class="rankolab-backlink-metric">
       
(Content truncated due to size limit. Use line ranges to read in chunks)