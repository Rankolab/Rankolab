<?php
/**
 * The file that defines the website monitoring module
 *
 * @link       https://rankolab.com
 * @since      1.0.0
 *
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 */

/**
 * The website monitoring module class.
 *
 * This class handles website monitoring and maintenance functionality.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/includes/modules
 * @author     Rankolab Development Team <support@rankolab.com>
 */
class Rankolab_Website_Monitoring {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_run_site_audit', array($this, 'ajax_run_site_audit'));
        add_action('wp_ajax_rankolab_get_uptime_data', array($this, 'ajax_get_uptime_data'));
        add_action('wp_ajax_rankolab_check_broken_links', array($this, 'ajax_check_broken_links'));
        add_action('wp_ajax_rankolab_optimize_database', array($this, 'ajax_optimize_database'));
        add_action('wp_ajax_rankolab_check_security', array($this, 'ajax_check_security'));
        add_action('wp_ajax_rankolab_get_performance_data', array($this, 'ajax_get_performance_data'));
        
        // Add admin page
        add_action('admin_menu', array($this, 'add_monitoring_page'), 20);
        
        // Add scheduled tasks
        add_action('rankolab_daily_monitoring_check', array($this, 'scheduled_monitoring_check'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_monitoring_settings'));
    }

    /**
     * Add monitoring admin page.
     *
     * @since    1.0.0
     */
    public function add_monitoring_page() {
        add_submenu_page(
            'rankolab',
            'Website Monitoring',
            'Monitoring',
            'manage_options',
            'rankolab-monitoring',
            array($this, 'display_monitoring_page')
        );
    }

    /**
     * Display monitoring admin page.
     *
     * @since    1.0.0
     */
    public function display_monitoring_page() {
        include_once plugin_dir_path(dirname(dirname(__FILE__))) . 'admin/partials/rankolab-admin-monitoring.php';
    }

    /**
     * Register monitoring settings.
     *
     * @since    1.0.0
     */
    public function register_monitoring_settings() {
        register_setting('rankolab_monitoring', 'rankolab_monitoring_settings');
        
        add_settings_section(
            'rankolab_monitoring_general',
            'General Settings',
            array($this, 'monitoring_general_section_callback'),
            'rankolab_monitoring'
        );
        
        add_settings_field(
            'enable_uptime_monitoring',
            'Enable Uptime Monitoring',
            array($this, 'enable_uptime_monitoring_callback'),
            'rankolab_monitoring',
            'rankolab_monitoring_general'
        );
        
        add_settings_field(
            'enable_broken_link_check',
            'Enable Broken Link Checking',
            array($this, 'enable_broken_link_check_callback'),
            'rankolab_monitoring',
            'rankolab_monitoring_general'
        );
        
        add_settings_field(
            'enable_security_scan',
            'Enable Security Scanning',
            array($this, 'enable_security_scan_callback'),
            'rankolab_monitoring',
            'rankolab_monitoring_general'
        );
        
        add_settings_field(
            'enable_performance_monitoring',
            'Enable Performance Monitoring',
            array($this, 'enable_performance_monitoring_callback'),
            'rankolab_monitoring',
            'rankolab_monitoring_general'
        );
        
        add_settings_field(
            'notification_email',
            'Notification Email',
            array($this, 'notification_email_callback'),
            'rankolab_monitoring',
            'rankolab_monitoring_general'
        );
        
        add_settings_field(
            'monitoring_frequency',
            'Monitoring Frequency',
            array($this, 'monitoring_frequency_callback'),
            'rankolab_monitoring',
            'rankolab_monitoring_general'
        );
    }

    /**
     * Monitoring general section callback.
     *
     * @since    1.0.0
     */
    public function monitoring_general_section_callback() {
        echo '<p>Configure website monitoring and maintenance settings.</p>';
    }

    /**
     * Enable uptime monitoring callback.
     *
     * @since    1.0.0
     */
    public function enable_uptime_monitoring_callback() {
        $options = get_option('rankolab_monitoring_settings');
        $value = isset($options['enable_uptime_monitoring']) ? $options['enable_uptime_monitoring'] : 1;
        
        echo '<input type="checkbox" id="enable_uptime_monitoring" name="rankolab_monitoring_settings[enable_uptime_monitoring]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_uptime_monitoring">Monitor website uptime and receive notifications for downtime</label>';
    }

    /**
     * Enable broken link check callback.
     *
     * @since    1.0.0
     */
    public function enable_broken_link_check_callback() {
        $options = get_option('rankolab_monitoring_settings');
        $value = isset($options['enable_broken_link_check']) ? $options['enable_broken_link_check'] : 1;
        
        echo '<input type="checkbox" id="enable_broken_link_check" name="rankolab_monitoring_settings[enable_broken_link_check]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_broken_link_check">Regularly scan for broken links on your website</label>';
    }

    /**
     * Enable security scan callback.
     *
     * @since    1.0.0
     */
    public function enable_security_scan_callback() {
        $options = get_option('rankolab_monitoring_settings');
        $value = isset($options['enable_security_scan']) ? $options['enable_security_scan'] : 1;
        
        echo '<input type="checkbox" id="enable_security_scan" name="rankolab_monitoring_settings[enable_security_scan]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_security_scan">Scan for security vulnerabilities and malware</label>';
    }

    /**
     * Enable performance monitoring callback.
     *
     * @since    1.0.0
     */
    public function enable_performance_monitoring_callback() {
        $options = get_option('rankolab_monitoring_settings');
        $value = isset($options['enable_performance_monitoring']) ? $options['enable_performance_monitoring'] : 1;
        
        echo '<input type="checkbox" id="enable_performance_monitoring" name="rankolab_monitoring_settings[enable_performance_monitoring]" value="1" ' . checked(1, $value, false) . '>';
        echo '<label for="enable_performance_monitoring">Monitor website performance metrics</label>';
    }

    /**
     * Notification email callback.
     *
     * @since    1.0.0
     */
    public function notification_email_callback() {
        $options = get_option('rankolab_monitoring_settings');
        $value = isset($options['notification_email']) ? $options['notification_email'] : get_option('admin_email');
        
        echo '<input type="email" id="notification_email" name="rankolab_monitoring_settings[notification_email]" value="' . esc_attr($value) . '" class="regular-text">';
        echo '<p class="description">Email address to receive monitoring notifications</p>';
    }

    /**
     * Monitoring frequency callback.
     *
     * @since    1.0.0
     */
    public function monitoring_frequency_callback() {
        $options = get_option('rankolab_monitoring_settings');
        $value = isset($options['monitoring_frequency']) ? $options['monitoring_frequency'] : 'daily';
        
        echo '<select id="monitoring_frequency" name="rankolab_monitoring_settings[monitoring_frequency]">';
        echo '<option value="hourly" ' . selected('hourly', $value, false) . '>Hourly</option>';
        echo '<option value="daily" ' . selected('daily', $value, false) . '>Daily</option>';
        echo '<option value="weekly" ' . selected('weekly', $value, false) . '>Weekly</option>';
        echo '</select>';
        echo '<p class="description">How often to run monitoring checks</p>';
    }

    /**
     * AJAX handler for running site audit.
     *
     * @since    1.0.0
     */
    public function ajax_run_site_audit() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_monitoring_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Run site audit
        $result = $this->run_site_audit();
        
        if ($result['success']) {
            wp_send_json_success(array(
                'audit_results' => $result['audit_results']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for getting uptime data.
     *
     * @since    1.0.0
     */
    public function ajax_get_uptime_data() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_monitoring_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $period = isset($_POST['period']) ? sanitize_text_field($_POST['period']) : '30d';
        
        // Get uptime data
        $result = $this->get_uptime_data($period);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'uptime_data' => $result['uptime_data']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for checking broken links.
     *
     * @since    1.0.0
     */
    public function ajax_check_broken_links() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_monitoring_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $post_types = isset($_POST['post_types']) ? array_map('sanitize_text_field', $_POST['post_types']) : array('post', 'page');
        $max_pages = isset($_POST['max_pages']) ? intval($_POST['max_pages']) : 10;
        
        // Check broken links
        $result = $this->check_broken_links($post_types, $max_pages);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'broken_links' => $result['broken_links'],
                'total_links' => $result['total_links'],
                'scanned_pages' => $result['scanned_pages']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for optimizing database.
     *
     * @since    1.0.0
     */
    public function ajax_optimize_database() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_monitoring_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $options = isset($_POST['options']) ? array_map('sanitize_text_field', $_POST['options']) : array('revisions', 'trash', 'spam', 'transients');
        
        // Optimize database
        $result = $this->optimize_database($options);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'optimization_results' => $result['optimization_results']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for checking security.
     *
     * @since    1.0.0
     */
    public function ajax_check_security() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_monitoring_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Check security
        $result = $this->check_security();
        
        if ($result['success']) {
            wp_send_json_success(array(
                'security_results' => $result['security_results']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * AJAX handler for getting performance data.
     *
     * @since    1.0.0
     */
    public function ajax_get_performance_data() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'rankolab_monitoring_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get parameters
        $period = isset($_POST['period']) ? sanitize_text_field($_POST['period']) : '30d';
        
        // Get performance data
        $result = $this->get_performance_data($period);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'performance_data' => $result['performance_data']
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * Scheduled monitoring check.
     *
     * @since    1.0.0
     */
    public function scheduled_monitoring_check() {
        // Get monitoring settings
        $options = get_option('rankolab_monitoring_settings');
        
        // Check if monitoring is enabled
        $enable_uptime = isset($options['enable_uptime_monitoring']) ? $options['enable_uptime_monitoring'] : 1;
        $enable_broken_links = isset($options['enable_broken_link_check']) ? $options['enable_broken_link_check'] : 1;
        $enable_security = isset($options['enable_security_scan']) ? $options['enable_security_scan'] : 1;
        $enable_performance = isset($options['enable_performance_monitoring']) ? $options['enable_performance_monitoring'] : 1;
        
        // Get notification email
        $notification_email = isset($options['notification_email']) ? $options['notification_email'] : get_option('admin_email');
        
        // Run checks
        $issues = array();
        
        if ($enable_uptime) {
            // Check uptime
            $uptime_result = $this->check_uptime();
            
            if (!$uptime_result['success']) {
                $issues[] = 'Uptime check failed: ' . $uptime_result['message'];
            } else if (!$uptime_result['is_up']) {
                $issues[] = 'Website is down: ' . $uptime_result['message'];
            }
        }
        
        if ($enable_broken_links) {
            // Check broken links
            $broken_links_result = $this->check_broken_links(array('post', 'page'), 10);
            
            if (!$broken_links_result['success']) {
                $issues[] = 'Broken link check failed: ' . $broken_links_result['message'];
            } else if (!empty($broken_links_result['broken_links'])) {
                $issues[] = 'Found ' . count($broken_links_result['broken_links']) . ' broken links on your website.';
            }
        }
        
        if ($enable_security) {
           
(Content truncated due to size limit. Use line ranges to read in chunks)