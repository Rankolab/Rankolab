<?php
/**
 * Partial template for displaying the Weekly Newsletter settings page.
 *
 * @package    Rankolab
 * @subpackage Rankolab/admin/partials
 * @since      1.1.0
 */

if (!defined(\'WPINC\')) {
    die;
}

// Get schedule info for display
$cron_hook = \'rankolab_send_newsletter_cron\'; // Make sure this matches the class
$next_scheduled = wp_next_scheduled($cron_hook);
$settings = get_option(\'rankolab_newsletter_settings\'); // Fetch settings directly
$is_enabled = isset($settings[\'enabled\']) && $settings[\'enabled\'];

?>
<div class="wrap rankolab-admin-page">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php if ($is_enabled && $next_scheduled): ?>
        <div class="notice notice-info inline">
            <p><?php 
                // Display time in site\s timezone
                $date_format = get_option(\'date_format\');
                $time_format = get_option(\'time_format\');
                $datetime_format = $date_format . \' \' . $time_format;
                $next_run_local = get_date_from_gmt(date(\'Y-m-d H:i:s\', $next_scheduled), $datetime_format);
                printf(__(\'Next newsletter scheduled for: %s (%s)\
            ?></p>
        </div>
    <?php elseif ($is_enabled): ?>
         <div class="notice notice-warning inline">
            <p><?php _e(\'Newsletter is enabled but the schedule might not be set correctly. Please save settings again to ensure it runs.\', \'rankolab\'); ?></p>
        </div>
    <?php endif; ?>

    <form method="post" action="options.php">
        <?php
        settings_fields(\'rankolab_newsletter_options\'); // Must match register_setting group
        do_settings_sections(\'rankolab-newsletter\'); // Must match add_settings_section page slug
        submit_button();
        ?>
    </form>

    <hr>

    <h2><?php _e(\'Test Newsletter\
    <p><?php _e(\'Send a test version of the newsletter to an email address. This uses the currently saved settings.\', \'rankolab\'); ?></p>
    <div class="rankolab-form-inline">
        <input type="email" id="rankolab-test-email" class="regular-text" placeholder="<?php echo esc_attr(get_option(\'admin_email\')); ?>" />
        <button id="rankolab-send-test-newsletter" class="button button-secondary">
            <?php _e(\'Send Test\
        </button>
        <span id="rankolab-test-newsletter-status" style="margin-left: 10px;"></span>
    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        // Show/hide post count based on checkbox
        function togglePostCount() {
            if ($(\'#rankolab_newsletter_include_posts\
                $(\'#rankolab_newsletter_posts_count\
            } else {
                $(\'#rankolab_newsletter_posts_count\
            }
        }
        // Need to ensure the field IDs match those rendered by the class
        // Assuming IDs are like: rankolab_newsletter_include_posts, rankolab_newsletter_posts_count
        var includePostsCheckbox = $(\'input[name*="[include_posts]"]\
        var postsCountInput = $(\'input[name*="[posts_count]"]\
        if (includePostsCheckbox.length && postsCountInput.length) {
             togglePostCount(); // Initial check
             includePostsCheckbox.on(\'change\
        }

        // Send test newsletter AJAX
        $(\'#rankolab-send-test-newsletter\
            var button = $(this);
            var statusSpan = $(\'#rankolab-test-newsletter-status\
            var testEmailInput = $(\'#rankolab-test-email\
            var testEmail = testEmailInput.val();
            if (!testEmail) {
                testEmail = testEmailInput.attr(\'placeholder\
            }

            button.prop(\'disabled\
            statusSpan.text(\'<?php echo esc_js(__("Sending...\")); ?>\

            $.post(ajaxurl, {
                action: \'rankolab_send_test_newsletter\
                _ajax_nonce: \'<?php echo wp_create_nonce("rankolab_send_test_newsletter_nonce"); ?>\
                test_email: testEmail
            }, function(response) {
                button.prop(\'disabled\
                if (response.success) {
                    statusSpan.text(response.data.message).css(\'color\
                } else {
                    statusSpan.text(response.data.message).css(\'color\
                }
                // Clear status message after 5 seconds
                setTimeout(function() {
                    statusSpan.text(\'\
                }, 5000);
            });
        });
    });
</script>

