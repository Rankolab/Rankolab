<?php
/**
 * The Setup Wizard module for Rankolab.
 *
 * This module provides a step-by-step setup wizard for initial plugin configuration.
 *
 * @since      1.0.0
 * @package    Rankolab
 * @subpackage Rankolab/modules
 * @author     Rankolab Development Team
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * The Setup Wizard module class.
 */
class Rankolab_Setup_Wizard {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * The wizard steps.
     *
     * @since    1.0.0
     * @access   private
     * @var      array    $steps    The wizard steps.
     */
    private $steps = array();

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    string    $plugin_name       The name of this plugin.
     * @param    string    $version           The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        // Define wizard steps
        $this->steps = array(
            'welcome' => array(
                'name' => __('Welcome', 'rankolab'),
                'view' => array($this, 'welcome_step'),
                'handler' => array($this, 'welcome_step_handler'),
            ),
            'license' => array(
                'name' => __('License', 'rankolab'),
                'view' => array($this, 'license_step'),
                'handler' => array($this, 'license_step_handler'),
            ),
            'subscription' => array(
                'name' => __('Subscription', 'rankolab'),
                'view' => array($this, 'subscription_step'),
                'handler' => array($this, 'subscription_step_handler'),
            ),
            'website' => array(
                'name' => __('Website Details', 'rankolab'),
                'view' => array($this, 'website_step'),
                'handler' => array($this, 'website_step_handler'),
            ),
            'api' => array(
                'name' => __('API Connections', 'rankolab'),
                'view' => array($this, 'api_step'),
                'handler' => array($this, 'api_step_handler'),
            ),
            'complete' => array(
                'name' => __('Complete', 'rankolab'),
                'view' => array($this, 'complete_step'),
                'handler' => array($this, 'complete_step_handler'),
            ),
        );

        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     *
     * @since    1.0.0
     */
    private function init_hooks() {
        // Add admin menu item
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Add admin scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Add AJAX handlers
        add_action('wp_ajax_rankolab_verify_license', array($this, 'ajax_verify_license'));
        add_action('wp_ajax_rankolab_select_subscription', array($this, 'ajax_select_subscription'));
        
        // Check if wizard should be shown on activation
        add_action('admin_init', array($this, 'maybe_show_wizard'));
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        $screen = get_current_screen();
        if (strpos($screen->id, 'rankolab-setup-wizard') !== false) {
            wp_enqueue_style('rankolab-setup-wizard', plugin_dir_url(__FILE__) . '../assets/css/rankolab-setup-wizard.css', array(), $this->version, 'all');
        }
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        $screen = get_current_screen();
        if (strpos($screen->id, 'rankolab-setup-wizard') !== false) {
            wp_enqueue_script('rankolab-setup-wizard', plugin_dir_url(__FILE__) . '../assets/js/rankolab-setup-wizard.js', array('jquery'), $this->version, false);
            
            // Localize script with AJAX URL and nonce
            wp_localize_script('rankolab-setup-wizard', 'rankolab_wizard', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('rankolab_setup_wizard'),
                'api_base_url' => 'https://rankolab.com/wp-json/rankolab/v1/',
            ));
        }
    }

    /**
     * Add admin menu item for the setup wizard.
     *
     * @since    1.0.0
     */
    public function add_admin_menu() {
        add_submenu_page(
            'rankolab',
            __('Setup Wizard', 'rankolab'),
            __('Setup Wizard', 'rankolab'),
            'manage_options',
            'rankolab-setup-wizard',
            array($this, 'display_wizard')
        );
    }

    /**
     * Check if the wizard should be shown on activation.
     *
     * @since    1.0.0
     */
    public function maybe_show_wizard() {
        // Check if we should show the wizard
        if (get_option('rankolab_show_wizard', false)) {
            // Delete the option so the wizard doesn't show again
            delete_option('rankolab_show_wizard');
            
            // Redirect to the wizard
            wp_redirect(admin_url('admin.php?page=rankolab-setup-wizard'));
            exit;
        }
    }

    /**
     * Display the setup wizard.
     *
     * @since    1.0.0
     */
    public function display_wizard() {
        // Get current step
        $current_step = isset($_GET['step']) ? sanitize_key($_GET['step']) : 'welcome';
        
        // Ensure step is valid
        if (!isset($this->steps[$current_step])) {
            $current_step = 'welcome';
        }
        
        // Process step handler if form was submitted
        if (isset($_POST['rankolab_wizard_submit']) && check_admin_referer('rankolab_wizard_' . $current_step)) {
            call_user_func($this->steps[$current_step]['handler']);
        }
        
        // Display header
        $this->display_wizard_header($current_step);
        
        // Display current step
        call_user_func($this->steps[$current_step]['view']);
        
        // Display footer
        $this->display_wizard_footer($current_step);
    }

    /**
     * Display the wizard header.
     *
     * @since    1.0.0
     * @param    string    $current_step    The current step.
     */
    private function display_wizard_header($current_step) {
        ?>
        <div class="rankolab-setup-wizard-wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="rankolab-setup-wizard-steps">
                <ul class="step-indicator">
                    <?php foreach ($this->steps as $step_key => $step) : ?>
                        <li class="<?php echo $step_key === $current_step ? 'active' : ''; ?>">
                            <div class="step"><?php echo esc_html($step['name']); ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <div class="rankolab-setup-wizard-content">
        <?php
    }

    /**
     * Display the wizard footer.
     *
     * @since    1.0.0
     * @param    string    $current_step    The current step.
     */
    private function display_wizard_footer($current_step) {
        ?>
            </div><!-- .rankolab-setup-wizard-content -->
            
            <div class="rankolab-setup-wizard-footer">
                <?php if ($current_step !== 'welcome') : ?>
                    <?php
                    $prev_step = $this->get_prev_step($current_step);
                    if ($prev_step) :
                    ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=rankolab-setup-wizard&step=' . $prev_step)); ?>" class="button button-secondary"><?php esc_html_e('Back', 'rankolab'); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if ($current_step !== 'complete') : ?>
                    <?php
                    $next_step = $this->get_next_step($current_step);
                    if ($next_step) :
                    ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=rankolab-setup-wizard&step=' . $next_step)); ?>" class="button button-secondary"><?php esc_html_e('Skip', 'rankolab'); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if ($current_step === 'complete') : ?>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=rankolab')); ?>" class="button button-primary"><?php esc_html_e('Finish', 'rankolab'); ?></a>
                <?php endif; ?>
            </div>
        </div><!-- .rankolab-setup-wizard-wrap -->
        <?php
    }

    /**
     * Get the previous step.
     *
     * @since    1.0.0
     * @param    string    $current_step    The current step.
     * @return   string|false               The previous step or false if there is no previous step.
     */
    private function get_prev_step($current_step) {
        $steps = array_keys($this->steps);
        $current_index = array_search($current_step, $steps);
        
        if ($current_index > 0) {
            return $steps[$current_index - 1];
        }
        
        return false;
    }

    /**
     * Get the next step.
     *
     * @since    1.0.0
     * @param    string    $current_step    The current step.
     * @return   string|false               The next step or false if there is no next step.
     */
    private function get_next_step($current_step) {
        $steps = array_keys($this->steps);
        $current_index = array_search($current_step, $steps);
        
        if ($current_index < count($steps) - 1) {
            return $steps[$current_index + 1];
        }
        
        return false;
    }

    /**
     * Welcome step view.
     *
     * @since    1.0.0
     */
    public function welcome_step() {
        ?>
        <h2><?php esc_html_e('Welcome to Rankolab!', 'rankolab'); ?></h2>
        
        <p><?php esc_html_e('Thank you for choosing Rankolab - the complete SEO & Content Optimization Suite for WordPress.', 'rankolab'); ?></p>
        
        <p><?php esc_html_e('This setup wizard will guide you through the initial configuration of the plugin. It will only take a few minutes.', 'rankolab'); ?></p>
        
        <div class="rankolab-video-container">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/placeholder" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <p class="description"><?php esc_html_e('Watch the video to understand Rankolab\'s features, then click Next.', 'rankolab'); ?></p>
        </div>
        
        <form method="post">
            <?php wp_nonce_field('rankolab_wizard_welcome'); ?>
            <p class="rankolab-setup-actions step">
                <input type="submit" class="button-primary button button-large button-next" value="<?php esc_attr_e('Next', 'rankolab'); ?>" name="rankolab_wizard_submit" />
            </p>
        </form>
        <?php
    }

    /**
     * Welcome step handler.
     *
     * @since    1.0.0
     */
    public function welcome_step_handler() {
        wp_redirect(admin_url('admin.php?page=rankolab-setup-wizard&step=license'));
        exit;
    }

    /**
     * License step view.
     *
     * @since    1.0.0
     */
    public function license_step() {
        $license_key = get_option('rankolab_license_key', '');
        $license_status = get_option('rankolab_license_status', '');
        ?>
        <h2><?php esc_html_e('License Activation', 'rankolab'); ?></h2>
        
        <p><?php esc_html_e('Enter your license key to activate Rankolab and unlock all features.', 'rankolab'); ?></p>
        
        <form method="post" id="rankolab-license-form">
            <?php wp_nonce_field('rankolab_wizard_license'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="rankolab_license_key"><?php esc_html_e('License Key', 'rankolab'); ?></label></th>
                    <td>
                        <input type="text" id="rankolab_license_key" name="rankolab_license_key" class="regular-text" value="<?php echo esc_attr($license_key); ?>" />
                        <p class="description">
                            <?php 
                            echo wp_kses(
                                __('Enter your license key from <a href="https://rankolab.com/dashboard" target="_blank">Rankolab Dashboard</a>. Don\'t have one? <a href="https://rankolab.com/register" target="_blank">Register here</a>.', 'rankolab'),
                                array(
                                    'a' => array(
                                        'href' => array(),
                                        'target' => array(),
                                    ),
                                )
                            ); 
                            ?>
                        </p>
                        
                        <div id="rankolab-license-status" class="<?php echo esc_attr($license_status); ?>">
                            <?php if ($license_status === 'valid') : ?>
                                <p class="rankolab-license-valid"><?php esc_html_e('License is active and valid.', 'rankolab'); ?></p>
                            <?php elseif ($license_status === 'invalid') : ?>
                                <p class="rankolab-license-invalid"><?php esc_html_e('License is invalid. Please check your key and try again.', 'rankolab'); ?></p>
                            <?php elseif ($license_status === 'expired') : ?>
                                <p class="rankolab-license-expired"><?php esc_html_e('License has expired. Please renew your license.', 'rankolab'); ?></p>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            </table>
            
            <p class="rankolab-setup-actions step">
                <button type="button" id="rankolab-verify-license" class="button-secondary"><?php esc_html_e('Verify License', 'rankolab'); ?></button>
                <input type="submit" class="button-primary button button-large button-next" value="<?php esc_attr_e('Next', 'rankolab'); ?>" name="rankolab_wizard_submit" />
            </p>
        </form>
        
        <script>
            jQuery(document).ready(function($) {
                $('#rankolab-verify-license').on('click', function() {
                    var license_key = $('#rankolab_license_key').val();
                    
                    if (!license_key) {
                        alert('<?php esc_html_e('Please enter a license key.', 'rankolab'); ?>');
                        return;
                    }
                    
                    $(this).prop('disabled', true).text('<?php esc_html_e('Verifying...', 'rankolab'); ?>');
                    
                    $.ajax({
                        url: rankolab_wizard.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'rankolab_verify_license',
                            license_key: license_key,
                            nonce: rankolab
(Content truncated due to size limit. Use line ranges to read in chunks)